package com.varcore.engine.particles;

import java.util.ArrayDeque;
import java.util.Deque;

public final class ObjectPool<T> {
    private final Deque<T> pool = new ArrayDeque<>();
    private final PoolFactory<T> factory;

    public ObjectPool(PoolFactory<T> factory, int initialSize) {
        this.factory = factory;
        for (int i = 0; i < initialSize; i++) {
            pool.push(factory.create());
        }
    }

    public T acquire() {
        return pool.isEmpty() ? factory.create() : pool.pop();
    }

    public void release(T object) {
        pool.push(object);
    }

    @FunctionalInterface
    public interface PoolFactory<T> {
        T create();
    }
}
