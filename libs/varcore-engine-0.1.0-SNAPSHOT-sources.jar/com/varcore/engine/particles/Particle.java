package com.varcore.engine.particles;

import com.varcore.engine.math.Vector2;
import java.awt.Color;

public final class Particle {
    boolean active;
    final Vector2 position = new Vector2();
    final Vector2 velocity = new Vector2();
    float lifetime;
    float maxLifetime;
    float size;
    float startSize = 4f;
    Color color = Color.WHITE;
    float alpha = 1f;

    void reset() {
        active = false;
        lifetime = 0;
        alpha = 1f;
        color = Color.WHITE;
        size = 4;
        startSize = 4;
        position.set(0, 0);
        velocity.set(0, 0);
    }
}
