package com.varcore.engine.particles;

import com.varcore.engine.render.Renderer;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public final class ParticleSystem {
    private final ObjectPool<Particle> pool = new ObjectPool<>(Particle::new, 256);
    private final List<Particle> active = new ArrayList<>();
    private float gravityY;
    private float drag;

    public Particle emit(float x, float y, float vx, float vy, float lifetime, float size, Color color) {
        Particle particle = pool.acquire();
        particle.reset();
        particle.active = true;
        particle.position.set(x, y);
        particle.velocity.set(vx, vy);
        particle.lifetime = lifetime;
        particle.maxLifetime = lifetime;
        particle.size = size;
        particle.startSize = size;
        particle.color = color;
        active.add(particle);
        return particle;
    }

    public void burst(float x, float y, int count, float speedMin, float speedMax,
                      float lifetimeMin, float lifetimeMax, float size, Color color) {
        for (int i = 0; i < count; i++) {
            float angle = (float) (Math.random() * Math.PI * 2);
            float speed = speedMin + (float) Math.random() * (speedMax - speedMin);
            float lifetime = lifetimeMin + (float) Math.random() * (lifetimeMax - lifetimeMin);
            float vx = (float) Math.cos(angle) * speed;
            float vy = (float) Math.sin(angle) * speed;
            emit(x, y, vx, vy, lifetime, size, color);
        }
    }

    public void setGravity(float gravityY) {
        this.gravityY = gravityY;
    }

    public void setDrag(float drag) {
        this.drag = Math.max(0f, Math.min(1f, drag));
    }

    public void update(float dt) {
        Iterator<Particle> it = active.iterator();
        while (it.hasNext()) {
            Particle p = it.next();
            p.lifetime -= dt;
            if (p.lifetime <= 0) {
                p.active = false;
                pool.release(p);
                it.remove();
                continue;
            }

            p.velocity.y += gravityY * dt;
            if (drag > 0f) {
                float damp = (float) Math.pow(1f - drag, dt * 60f);
                p.velocity.x *= damp;
                p.velocity.y *= damp;
            }

            p.position.add(p.velocity.x * dt, p.velocity.y * dt);
            float lifeRatio = p.lifetime / p.maxLifetime;
            p.alpha = lifeRatio;
            p.size = p.startSize * (0.35f + 0.65f * lifeRatio);
        }
    }

    public void render(Renderer renderer, int layer) {
        for (Particle p : active) {
            Color c = new Color(p.color.getRed(), p.color.getGreen(), p.color.getBlue(),
                    (int) (255 * p.alpha));
            renderer.drawCircle(p.position.x, p.position.y, p.size, c, true, layer);
        }
    }

    public int getActiveCount() {
        return active.size();
    }
}
