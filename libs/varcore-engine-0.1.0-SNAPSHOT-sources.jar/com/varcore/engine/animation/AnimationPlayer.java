package com.varcore.engine.animation;

import com.varcore.engine.apack.APack;
import com.varcore.engine.apack.APackFrame;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

public final class AnimationPlayer {
    private APack apack;
    private AnimationState state = AnimationState.STOPPED;
    private int currentFrame;
    private float frameTimer;
    private boolean reverse;
    private boolean pingPongForward = true;
    private float speedMultiplier = 1f;
    private final List<Consumer<String>> eventListeners = new ArrayList<>();

    public void setAPack(APack apack) {
        this.apack = apack;
        currentFrame = 0;
        frameTimer = 0;
        pingPongForward = true;
    }

    public void play() {
        if (apack == null) {
            return;
        }
        state = AnimationState.PLAYING;
    }

    public void pause() {
        state = AnimationState.PAUSED;
    }

    public void stop() {
        state = AnimationState.STOPPED;
        currentFrame = 0;
        frameTimer = 0;
        reverse = false;
        pingPongForward = true;
    }

    public void setReverse(boolean reverse) {
        this.reverse = reverse;
    }

    public void setSpeedMultiplier(float speedMultiplier) {
        this.speedMultiplier = Math.max(0.01f, speedMultiplier);
    }

    public void addFrameEventListener(Consumer<String> listener) {
        eventListeners.add(listener);
    }

    public void update(float dt) {
        if (apack == null || state != AnimationState.PLAYING) {
            return;
        }

        float effectiveSpeed = speedMultiplier * apack.getSpeedMultiplier();
        float frameDuration = 1f / (apack.getFps() * effectiveSpeed);
        frameTimer += dt;

        while (frameTimer >= frameDuration) {
            frameTimer -= frameDuration;
            advanceFrame();
            fireFrameEvents();
        }
    }

    private void advanceFrame() {
        int frameCount = apack.getFrames().size();
        if (frameCount == 0) {
            return;
        }

        PlaybackMode mode = apack.getPlaybackMode();

        if (mode == PlaybackMode.PING_PONG) {
            if (pingPongForward) {
                currentFrame++;
                if (currentFrame >= frameCount - 1) {
                    currentFrame = frameCount - 1;
                    pingPongForward = false;
                }
            } else {
                currentFrame--;
                if (currentFrame <= 0) {
                    currentFrame = 0;
                    pingPongForward = true;
                }
            }
            return;
        }

        if (reverse) {
            currentFrame--;
            if (currentFrame < 0) {
                if (mode == PlaybackMode.LOOP) {
                    currentFrame = frameCount - 1;
                } else {
                    currentFrame = 0;
                    state = AnimationState.STOPPED;
                }
            }
            return;
        }

        currentFrame++;
        if (currentFrame >= frameCount) {
            switch (mode) {
                case LOOP -> currentFrame = 0;
                case STOP_AT_END -> {
                    currentFrame = frameCount - 1;
                    state = AnimationState.STOPPED;
                }
                case RESET -> {
                    currentFrame = 0;
                    state = AnimationState.STOPPED;
                }
                default -> {
                    currentFrame = frameCount - 1;
                    state = AnimationState.STOPPED;
                }
            }
        }
    }

    private void fireFrameEvents() {
        APackFrame frame = getCurrentFrameData();
        if (frame == null) {
            return;
        }
        for (String event : frame.getEvents()) {
            for (Consumer<String> listener : eventListeners) {
                listener.accept(event);
            }
        }
    }

    public APackFrame getCurrentFrameData() {
        if (apack == null || apack.getFrames().isEmpty()) {
            return null;
        }
        int index = Math.max(0, Math.min(currentFrame, apack.getFrames().size() - 1));
        return apack.getFrames().get(index);
    }

    public APack getAPack() {
        return apack;
    }

    public AnimationState getState() {
        return state;
    }

    public int getCurrentFrame() {
        return currentFrame;
    }
}
