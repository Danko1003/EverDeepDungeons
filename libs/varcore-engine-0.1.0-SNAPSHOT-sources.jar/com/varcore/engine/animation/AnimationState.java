package com.varcore.engine.animation;

public enum AnimationState {
    STOPPED,
    PLAYING,
    PAUSED
}
