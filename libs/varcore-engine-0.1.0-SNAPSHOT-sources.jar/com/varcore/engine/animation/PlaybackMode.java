package com.varcore.engine.animation;

public enum PlaybackMode {
    LOOP,
    PING_PONG,
    STOP_AT_END,
    RESET;

    public static PlaybackMode fromJson(String value, boolean loop, boolean pingPong) {
        if (value != null && !value.isBlank()) {
            return switch (value.toUpperCase()) {
                case "PING_PONG", "PINGPONG" -> PING_PONG;
                case "STOP_AT_END", "STOP" -> STOP_AT_END;
                case "RESET" -> RESET;
                default -> LOOP;
            };
        }
        if (pingPong) {
            return PING_PONG;
        }
        return loop ? LOOP : STOP_AT_END;
    }

    public String toJson() {
        return name();
    }
}
