package com.varcore.engine.debug;

import com.varcore.engine.render.Renderer;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;

public final class DebugOverlay {
    private boolean visible;
    private long fps;
    private float lastFrameMs;
    private int entityCount;

    public void toggle() {
        visible = !visible;
    }

    public void setVisible(boolean visible) {
        this.visible = visible;
    }

    public void setFps(long fps) {
        this.fps = fps;
    }

    public void recordFrame(float dt) {
        lastFrameMs = dt * 1000f;
    }

    public void setEntityCount(int entityCount) {
        this.entityCount = entityCount;
    }

    public void render(Renderer renderer, Graphics2D g) {
        if (!visible) {
            return;
        }
        Runtime runtime = Runtime.getRuntime();
        long usedMb = (runtime.totalMemory() - runtime.freeMemory()) / (1024 * 1024);
        Font font = new Font("Consolas", Font.PLAIN, 12);
        Color color = new Color(0xE6, 0xE6, 0xE6);
        float y = 16;
        renderer.drawTextScreen("FPS: " + fps, 8, y, font, color);
        y += 16;
        renderer.drawTextScreen(String.format("Frame: %.2f ms", lastFrameMs), 8, y, font, color);
        y += 16;
        renderer.drawTextScreen("Draw calls: " + renderer.getDrawCallCount(), 8, y, font, color);
        y += 16;
        renderer.drawTextScreen("Entities: " + entityCount, 8, y, font, color);
        y += 16;
        renderer.drawTextScreen("Memory: " + usedMb + " MB", 8, y, font, color);
        y += 16;
        for (var entry : Profiler.snapshot().entrySet()) {
            renderer.drawTextScreen(entry.getKey() + ": " + String.format("%.2f ms", entry.getValue()), 8, y, font, color);
            y += 16;
        }
    }
}
