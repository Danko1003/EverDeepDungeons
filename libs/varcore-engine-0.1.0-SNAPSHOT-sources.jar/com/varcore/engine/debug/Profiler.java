package com.varcore.engine.debug;

import java.util.HashMap;
import java.util.Map;

public final class Profiler {
    private static final Map<String, Long> starts = new HashMap<>();
    private static final Map<String, Float> lastMs = new HashMap<>();

    private Profiler() {}

    public static void begin(String name) {
        starts.put(name, System.nanoTime());
    }

    public static void end(String name) {
        Long start = starts.remove(name);
        if (start != null) {
            lastMs.put(name, (System.nanoTime() - start) / 1_000_000f);
        }
    }

    public static float getLastMs(String name) {
        return lastMs.getOrDefault(name, 0f);
    }

    public static Map<String, Float> snapshot() {
        return Map.copyOf(lastMs);
    }
}
