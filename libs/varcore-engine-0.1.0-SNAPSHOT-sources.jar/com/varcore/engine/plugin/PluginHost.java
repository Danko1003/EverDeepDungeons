package com.varcore.engine.plugin;

import com.varcore.engine.core.Game;
import java.io.IOException;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.ServiceLoader;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

public final class PluginHost {
    private final List<Plugin> loaded = new ArrayList<>();
    private final List<URLClassLoader> classLoaders = new ArrayList<>();
    private Path pluginsDir = Path.of("plugins");

    public void setPluginsDir(Path pluginsDir) {
        this.pluginsDir = pluginsDir;
    }

    public void loadPlugins(Game game) {
        if (!Files.isDirectory(pluginsDir)) {
            return;
        }
        try (var stream = Files.list(pluginsDir)) {
            for (Path jar : stream.filter(p -> p.toString().endsWith(".jar")).toList()) {
                loadPluginJar(jar, game);
            }
        } catch (IOException e) {
            System.err.println("Failed to load plugins: " + e.getMessage());
        }
    }

    private void loadPluginJar(Path jar, Game game) {
        try {
            URLClassLoader loader = new URLClassLoader(new URL[]{jar.toUri().toURL()}, getClass().getClassLoader());
            classLoaders.add(loader);
            ServiceLoader<Plugin> serviceLoader = ServiceLoader.load(Plugin.class, loader);
            for (Plugin plugin : serviceLoader) {
                PluginContext context = new PluginContext(game);
                plugin.onLoad(context);
                loaded.add(plugin);
                System.out.println("Loaded plugin: " + plugin.getName() + " v" + plugin.getVersion());
            }
        } catch (Exception e) {
            System.err.println("Failed to load plugin jar " + jar + ": " + e.getMessage());
        }
    }

    public void unloadAll() {
        for (Plugin plugin : loaded) {
            try {
                plugin.onUnload();
            } catch (Exception e) {
                System.err.println("Error unloading plugin " + plugin.getId() + ": " + e.getMessage());
            }
        }
        loaded.clear();
        for (URLClassLoader loader : classLoaders) {
            try {
                loader.close();
            } catch (IOException ignored) {}
        }
        classLoaders.clear();
    }

    public List<Plugin> getLoadedPlugins() {
        return List.copyOf(loaded);
    }
}
