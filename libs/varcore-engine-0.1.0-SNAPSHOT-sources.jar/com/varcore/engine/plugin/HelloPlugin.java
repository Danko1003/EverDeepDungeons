package com.varcore.engine.plugin;

import com.varcore.engine.core.Game;

public final class HelloPlugin implements Plugin {
    @Override
    public String getId() {
        return "hello";
    }

    @Override
    public String getName() {
        return "Hello Plugin";
    }

    @Override
    public String getVersion() {
        return "0.1.0";
    }

    @Override
    public void onLoad(PluginContext context) {
        context.registerMenuItem("Hello from plugin");
        System.out.println("HelloPlugin loaded for game: " + context.getGame().getWindow().getFrame().getTitle());
    }

    @Override
    public void onUnload() {
        System.out.println("HelloPlugin unloaded");
    }
}
