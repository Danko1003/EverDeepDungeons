package com.varcore.engine.plugin;

import com.varcore.engine.core.Game;

public interface Plugin {
    String getId();
    String getName();
    String getVersion();
    void onLoad(PluginContext context);
    void onUnload();
}
