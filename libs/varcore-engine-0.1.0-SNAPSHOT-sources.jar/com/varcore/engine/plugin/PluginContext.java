package com.varcore.engine.plugin;

import com.varcore.engine.core.Game;
import java.util.ArrayList;
import java.util.List;

public final class PluginContext {
    private final Game game;
    private final List<String> menuRegistrations = new ArrayList<>();

    public PluginContext(Game game) {
        this.game = game;
    }

    public Game getGame() {
        return game;
    }

    public void registerMenuItem(String label) {
        menuRegistrations.add(label);
    }

    public List<String> getMenuRegistrations() {
        return menuRegistrations;
    }
}
