package com.varcore.engine.assets;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.varcore.engine.apack.APack;
import com.varcore.engine.apack.APackLoader;
import com.varcore.engine.varobject.VarObjectDefinition;
import com.varcore.engine.varobject.VarObjectLoader;
import java.awt.Font;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import javax.imageio.ImageIO;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;

public final class AssetManager {
    private Path root = Path.of("assets");
    private final Map<String, Asset> cache = new HashMap<>();
    private final APackLoader apackLoader = new APackLoader();
    private final VarObjectLoader varObjectLoader = new VarObjectLoader();

    public AssetManager(Path root) {
        this.root = root;
    }

    public void setRoot(Path root) {
        this.root = root;
    }

    public Path getRoot() {
        return root;
    }

    public BufferedImage loadImage(String path) {
        return getOrLoad(path, () -> {
            Path file = resolve(path);
            try {
                return ImageIO.read(file.toFile());
            } catch (IOException e) {
                throw new AssetLoadException("Failed to load image: " + path, e);
            }
        });
    }

    public Font loadFont(String path, float size) {
        String key = path + "@" + size;
        return getOrLoad(key, () -> {
            Path file = resolve(path);
            try (InputStream in = Files.newInputStream(file)) {
                Font base = Font.createFont(Font.TRUETYPE_FONT, in);
                return base.deriveFont(size);
            } catch (Exception e) {
                throw new AssetLoadException("Failed to load font: " + path, e);
            }
        });
    }

    public Clip loadSound(String path) {
        return getOrLoad(path, () -> {
            Path file = resolve(path);
            try {
                AudioInputStream stream = AudioSystem.getAudioInputStream(file.toFile());
                Clip clip = AudioSystem.getClip();
                clip.open(stream);
                return clip;
            } catch (Exception e) {
                throw new AssetLoadException("Failed to load sound: " + path, e);
            }
        });
    }

    public JsonObject loadJson(String path) {
        return getOrLoad(path, () -> {
            try {
                String content = Files.readString(resolve(path));
                return JsonParser.parseString(content).getAsJsonObject();
            } catch (IOException e) {
                throw new AssetLoadException("Failed to load json: " + path, e);
            }
        });
    }

    public APack loadAPack(String folderPath) {
        return getOrLoad(folderPath, () -> apackLoader.load(resolve(folderPath)));
    }

    public VarObjectDefinition loadVarObject(String folderPath) {
        return getOrLoad(folderPath, () -> varObjectLoader.load(resolve(folderPath)));
    }

    public void unload(String id) {
        cache.remove(id);
    }

    public void unloadUnused() {
        Iterator<Map.Entry<String, Asset>> it = cache.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<String, Asset> entry = it.next();
            if (entry.getValue().getReferenceCount() <= 0) {
                it.remove();
            }
        }
    }

    public void dispose() {
        cache.clear();
    }

    private Path resolve(String path) {
        Path resolved = root.resolve(path);
        if (!Files.exists(resolved)) {
            throw new AssetLoadException("Asset not found: " + resolved, null);
        }
        return resolved;
    }

    @SuppressWarnings("unchecked")
    private <T> T getOrLoad(String key, Loader<T> loader) {
        Asset existing = cache.get(key);
        if (existing != null) {
            existing.retain();
            return ((AssetHandle<T>) existing).get();
        }
        T loaded = loader.load();
        AssetHandle<T> handle = new AssetHandle<>(key, loaded) {};
        cache.put(key, handle);
        return loaded;
    }

    @FunctionalInterface
    private interface Loader<T> {
        T load();
    }
}
