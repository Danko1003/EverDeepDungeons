package com.varcore.engine.assets;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.varcore.engine.render.SpriteDraw;
import com.varcore.engine.apack.APack;
import com.varcore.engine.apack.APackLoader;
import com.varcore.engine.varobject.VarObjectAlphaMask;
import com.varcore.engine.varobject.VarObjectDefinition;
import com.varcore.engine.varobject.VarObjectLoader;
import java.awt.Font;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import javax.imageio.ImageIO;
import javax.sound.sampled.Clip;

public final class AssetManager {
    private Path root = Path.of("assets");
    private final Map<String, Asset> cache = new HashMap<>();
    private final APackLoader apackLoader = new APackLoader();
    private final VarObjectLoader varObjectLoader = new VarObjectLoader();

    public AssetManager(Path root) {
        this.root = root;
    }

    public void setRoot(Path root) {
        this.root = root;
    }

    public Path getRoot() {
        return root;
    }

    public BufferedImage loadImage(String path) {
        return getOrLoad(path, true, () -> {
            Path file = resolve(path);
            try {
                BufferedImage loaded = ImageIO.read(file.toFile());
                return SpriteDraw.toArgb(loaded);
            } catch (IOException e) {
                throw new AssetLoadException("Failed to load image: " + path, e);
            }
        });
    }

    /** Returns a cached image without bumping the retain count (safe for per-frame draws). */
    public BufferedImage getImage(String path) {
        return getOrLoad(path, false, () -> {
            Path file = resolve(path);
            try {
                BufferedImage loaded = ImageIO.read(file.toFile());
                return SpriteDraw.toArgb(loaded);
            } catch (IOException e) {
                throw new AssetLoadException("Failed to load image: " + path, e);
            }
        });
    }

    public Font loadFont(String path, float size) {
        String key = path + "@" + size;
        return getOrLoad(key, true, () -> {
            Path file = resolve(path);
            try (InputStream in = Files.newInputStream(file)) {
                Font base = Font.createFont(Font.TRUETYPE_FONT, in);
                return base.deriveFont(size);
            } catch (Exception e) {
                throw new AssetLoadException("Failed to load font: " + path, e);
            }
        });
    }

    public Clip loadSound(String path) {
        return getOrLoad(path, true, () -> {
            Path file = resolve(path);
            try {
                return com.varcore.engine.audio.SoundLoader.loadClip(file);
            } catch (Exception e) {
                throw new AssetLoadException("Failed to load sound: " + path, e);
            }
        });
    }

    public JsonObject loadJson(String path) {
        return getOrLoad(path, true, () -> {
            try {
                String content = Files.readString(resolve(path));
                return JsonParser.parseString(content).getAsJsonObject();
            } catch (IOException e) {
                throw new AssetLoadException("Failed to load json: " + path, e);
            }
        });
    }

    public APack loadAPack(String folderPath) {
        return getOrLoad(folderPath, true, () -> apackLoader.load(resolve(folderPath)));
    }

    /** Returns a cached APack without bumping the retain count (safe for per-frame draws). */
    public APack getAPack(String folderPath) {
        return getOrLoad(folderPath, false, () -> apackLoader.load(resolve(folderPath)));
    }

    public VarObjectDefinition loadVarObject(String folderPath) {
        return getOrLoad(folderPath, true, () -> varObjectLoader.load(resolve(folderPath)));
    }

    public void unload(String id) {
        cache.remove(id);
    }

    public void unloadUnused() {
        Iterator<Map.Entry<String, Asset>> it = cache.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<String, Asset> entry = it.next();
            if (entry.getValue().getReferenceCount() <= 0) {
                it.remove();
            }
        }
    }

    public void dispose() {
        for (Asset asset : cache.values()) {
            if (asset instanceof AssetHandle<?> handle) {
                Object data = handle.get();
                if (data instanceof Clip clip) {
                    try {
                        clip.stop();
                        clip.close();
                    } catch (Exception ignored) {
                    }
                }
            }
        }
        cache.clear();
        VarObjectAlphaMask.clearCache();
    }

    private Path resolve(String path) {
        Path resolved = root.resolve(path);
        if (!Files.exists(resolved)) {
            throw new AssetLoadException("Asset not found: " + resolved, null);
        }
        return resolved;
    }

    @SuppressWarnings("unchecked")
    private <T> T getOrLoad(String key, boolean retainOnHit, Loader<T> loader) {
        Asset existing = cache.get(key);
        if (existing != null) {
            if (retainOnHit) {
                existing.retain();
            }
            return ((AssetHandle<T>) existing).get();
        }
        T loaded = loader.load();
        AssetHandle<T> handle = new AssetHandle<>(key, loaded) {};
        cache.put(key, handle);
        return loaded;
    }

    @FunctionalInterface
    private interface Loader<T> {
        T load();
    }
}
