package com.varcore.engine.assets;

public abstract class AssetHandle<T> implements Asset {
    private final String id;
    private final T data;
    private int referenceCount = 1;

    protected AssetHandle(String id, T data) {
        this.id = id;
        this.data = data;
    }

    @Override
    public String getId() {
        return id;
    }

    public T get() {
        return data;
    }

    @Override
    public int getReferenceCount() {
        return referenceCount;
    }

    @Override
    public void retain() {
        referenceCount++;
    }

    @Override
    public void release() {
        referenceCount = Math.max(0, referenceCount - 1);
    }
}
