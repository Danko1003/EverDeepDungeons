package com.varcore.engine.assets;

public interface Asset {
    String getId();
    int getReferenceCount();
    void retain();
    void release();
}
