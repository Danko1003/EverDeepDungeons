package com.varcore.engine.assets;

public class AssetLoadException extends RuntimeException {
    public AssetLoadException(String message, Throwable cause) {
        super(message, cause);
    }
}
