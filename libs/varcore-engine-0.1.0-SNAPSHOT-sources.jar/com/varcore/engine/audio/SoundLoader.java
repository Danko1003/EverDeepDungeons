package com.varcore.engine.audio;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.file.Path;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.UnsupportedAudioFileException;

/**
 * Loads WAVs into a Clip using a Java-supported PCM format (16-bit signed LE).
 * Many game assets are 24-bit; DirectAudio Clip cannot open those natively.
 */
public final class SoundLoader {
    private SoundLoader() {
    }

    public static Clip loadClip(Path file) throws Exception {
        try (AudioInputStream source = AudioSystem.getAudioInputStream(file.toFile())) {
            AudioInputStream pcm = toSupportedPcm(source);
            try {
                AudioFormat format = pcm.getFormat();
                DataLine.Info info = new DataLine.Info(Clip.class, format);
                Clip clip = (Clip) AudioSystem.getLine(info);
                clip.open(pcm);
                return clip;
            } finally {
                pcm.close();
            }
        }
    }

    static AudioInputStream toSupportedPcm(AudioInputStream source)
            throws IOException, UnsupportedAudioFileException {
        AudioFormat src = source.getFormat();
        AudioFormat target = new AudioFormat(
                AudioFormat.Encoding.PCM_SIGNED,
                src.getSampleRate() > 0 ? src.getSampleRate() : 44100f,
                16,
                Math.max(1, src.getChannels()),
                Math.max(1, src.getChannels()) * 2,
                src.getSampleRate() > 0 ? src.getSampleRate() : 44100f,
                false);

        if (isCompatible(src, target)) {
            return source;
        }

        if (AudioSystem.isConversionSupported(target, src)) {
            return AudioSystem.getAudioInputStream(target, source);
        }

        // Manual path for 24-bit (and other) PCM that Java won't convert.
        byte[] raw = readAll(source);
        byte[] converted = convertPcmTo16Le(raw, src, target);
        return new AudioInputStream(new ByteArrayInputStream(converted), target, converted.length / target.getFrameSize());
    }

    private static boolean isCompatible(AudioFormat src, AudioFormat target) {
        return src.getEncoding() == AudioFormat.Encoding.PCM_SIGNED
                && src.getSampleSizeInBits() == 16
                && !src.isBigEndian()
                && src.getChannels() == target.getChannels()
                && Float.compare(src.getSampleRate(), target.getSampleRate()) == 0;
    }

    private static byte[] readAll(AudioInputStream stream) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = stream.read(buf)) >= 0) {
            out.write(buf, 0, n);
        }
        return out.toByteArray();
    }

    private static byte[] convertPcmTo16Le(byte[] raw, AudioFormat src, AudioFormat target) {
        int srcBits = src.getSampleSizeInBits();
        int srcChannels = Math.max(1, src.getChannels());
        int srcFrame = src.getFrameSize() > 0 ? src.getFrameSize() : (srcBits / 8) * srcChannels;
        boolean big = src.isBigEndian();
        int frames = raw.length / Math.max(1, srcFrame);
        int dstChannels = target.getChannels();
        byte[] out = new byte[frames * dstChannels * 2];

        for (int f = 0; f < frames; f++) {
            int srcOff = f * srcFrame;
            for (int c = 0; c < dstChannels; c++) {
                int sample;
                int ch = Math.min(c, srcChannels - 1);
                if (srcBits == 8) {
                    sample = (raw[srcOff + ch] & 0xFF) - 128;
                    sample <<= 8;
                } else if (srcBits == 16) {
                    int i = srcOff + ch * 2;
                    if (big) {
                        sample = (raw[i] << 8) | (raw[i + 1] & 0xFF);
                    } else {
                        sample = (raw[i] & 0xFF) | (raw[i + 1] << 8);
                    }
                    sample = (short) sample;
                } else if (srcBits == 24) {
                    int i = srcOff + ch * 3;
                    int b0;
                    int b1;
                    int b2;
                    if (big) {
                        b0 = raw[i] & 0xFF;
                        b1 = raw[i + 1] & 0xFF;
                        b2 = raw[i + 2] & 0xFF;
                        sample = (b0 << 16) | (b1 << 8) | b2;
                    } else {
                        b0 = raw[i] & 0xFF;
                        b1 = raw[i + 1] & 0xFF;
                        b2 = raw[i + 2] & 0xFF;
                        sample = (b2 << 16) | (b1 << 8) | b0;
                    }
                    if ((sample & 0x800000) != 0) {
                        sample |= 0xFF000000;
                    }
                    sample >>= 8; // 24 -> 16
                } else if (srcBits == 32) {
                    int i = srcOff + ch * 4;
                    int bits;
                    if (big) {
                        bits = (raw[i] << 24) | ((raw[i + 1] & 0xFF) << 16)
                                | ((raw[i + 2] & 0xFF) << 8) | (raw[i + 3] & 0xFF);
                    } else {
                        bits = (raw[i] & 0xFF) | ((raw[i + 1] & 0xFF) << 8)
                                | ((raw[i + 2] & 0xFF) << 16) | (raw[i + 3] << 24);
                    }
                    if (src.getEncoding() == AudioFormat.Encoding.PCM_FLOAT
                            || src.toString().contains("float")) {
                        sample = (int) (Float.intBitsToFloat(bits) * 32767f);
                    } else {
                        sample = bits >> 16;
                    }
                } else {
                    sample = 0;
                }
                sample = Math.max(-32768, Math.min(32767, sample));
                int dst = (f * dstChannels + c) * 2;
                out[dst] = (byte) (sample & 0xFF);
                out[dst + 1] = (byte) ((sample >> 8) & 0xFF);
            }
        }
        return out;
    }
}
