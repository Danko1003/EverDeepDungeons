package com.varcore.engine.audio;

import com.varcore.engine.assets.AssetManager;
import java.util.HashMap;
import java.util.Map;
import javax.sound.sampled.Clip;
import javax.sound.sampled.FloatControl;

public final class AudioManager {
    private static AudioManager instance;
    private final AssetManager assets;
    private final Map<String, Clip> activeClips = new HashMap<>();
    private float masterVolume = 1f;
    private boolean muted;
    private boolean disposed;

    public AudioManager(AssetManager assets) {
        this.assets = assets;
        instance = this;
    }

    public static AudioManager getInstance() {
        return instance;
    }

    public void play(String path, boolean loop, float volume) {
        if (disposed) {
            return;
        }
        try {
            stop(path);
            Clip clip = assets.loadSound(path);
            if (loop) {
                clip.loop(Clip.LOOP_CONTINUOUSLY);
            }
            setClipVolume(clip, (muted ? 0f : volume) * masterVolume);
            clip.setFramePosition(0);
            clip.start();
            activeClips.put(path, clip);
        } catch (Exception e) {
            System.err.println("[Audio] Failed to play " + path + ": " + e.getMessage());
        }
    }

    public void stop(String path) {
        Clip clip = activeClips.remove(path);
        if (clip != null) {
            try {
                clip.stop();
            } catch (Exception ignored) {
            }
        }
    }

    public void stopAll() {
        for (Clip clip : activeClips.values()) {
            try {
                clip.stop();
            } catch (Exception ignored) {
            }
        }
        activeClips.clear();
    }

    public void setMasterVolume(float masterVolume) {
        this.masterVolume = Math.max(0, Math.min(1, masterVolume));
        for (Map.Entry<String, Clip> entry : activeClips.entrySet()) {
            setClipVolume(entry.getValue(), muted ? 0f : masterVolume);
        }
    }

    public void setMuted(boolean muted) {
        this.muted = muted;
        for (Clip clip : activeClips.values()) {
            setClipVolume(clip, muted ? 0f : masterVolume);
        }
    }

    private void setClipVolume(Clip clip, float volume) {
        if (!clip.isControlSupported(FloatControl.Type.MASTER_GAIN)) {
            return;
        }
        FloatControl control = (FloatControl) clip.getControl(FloatControl.Type.MASTER_GAIN);
        float dB = (float) (20 * Math.log10(Math.max(0.0001, volume)));
        control.setValue(Math.max(control.getMinimum(), Math.min(control.getMaximum(), dB)));
    }

    public void dispose() {
        if (disposed) {
            return;
        }
        disposed = true;
        for (Clip clip : activeClips.values()) {
            try {
                clip.stop();
                clip.flush();
                clip.close();
            } catch (Exception ignored) {
            }
        }
        activeClips.clear();
        if (instance == this) {
            instance = null;
        }
    }
}
