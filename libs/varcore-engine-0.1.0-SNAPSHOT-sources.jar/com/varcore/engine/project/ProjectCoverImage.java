package com.varcore.engine.project;

import java.nio.file.Files;
import java.nio.file.Path;

/** Paths for per-project cover art shown in Studio and copied into exports. */
public final class ProjectCoverImage {
    public static final String PROJECT_RELATIVE_PATH = ".varcore/cover.png";
    public static final String EXPORT_FILE_NAME = "cover.png";

    private ProjectCoverImage() {
    }

    public static Path inProject(Path projectRoot) {
        return projectRoot.resolve(PROJECT_RELATIVE_PATH);
    }

    public static Path inExport(Path exportRoot) {
        return exportRoot.resolve(EXPORT_FILE_NAME);
    }

    public static boolean existsInProject(Path projectRoot) {
        return Files.isRegularFile(inProject(projectRoot));
    }

    public static boolean existsInExport(Path exportRoot) {
        return Files.isRegularFile(inExport(exportRoot));
    }
}
