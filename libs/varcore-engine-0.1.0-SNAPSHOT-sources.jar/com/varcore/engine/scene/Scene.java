package com.varcore.engine.scene;

import com.varcore.engine.entity.GameObject;
import com.varcore.engine.render.Renderer;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class Scene {
    private final String name;
    private final List<GameObject> gameObjects = new ArrayList<>();

    public Scene(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public GameObject add(GameObject gameObject) {
        gameObjects.add(gameObject);
        return gameObject;
    }

    public void remove(GameObject gameObject) {
        gameObject.destroy();
        gameObjects.remove(gameObject);
    }

    public Optional<GameObject> findByName(String name) {
        return gameObjects.stream().filter(go -> go.getName().equals(name)).findFirst();
    }

    public Optional<GameObject> findByTag(String tag) {
        if (tag == null) {
            return Optional.empty();
        }
        return gameObjects.stream().filter(go -> tag.equals(go.getTag())).findFirst();
    }

    public List<GameObject> findAllByTag(String tag) {
        if (tag == null) {
            return List.of();
        }
        return gameObjects.stream().filter(go -> tag.equals(go.getTag())).toList();
    }

    public List<GameObject> getGameObjects() {
        return List.copyOf(gameObjects);
    }

    public void updateAll(float dt) {
        for (GameObject gameObject : new ArrayList<>(gameObjects)) {
            gameObject.update(dt);
        }
    }

    public void renderAll(Renderer renderer) {
        for (GameObject gameObject : gameObjects) {
            gameObject.render(renderer);
        }
    }

    public void clear() {
        for (GameObject gameObject : gameObjects) {
            gameObject.destroy();
        }
        gameObjects.clear();
    }
}
