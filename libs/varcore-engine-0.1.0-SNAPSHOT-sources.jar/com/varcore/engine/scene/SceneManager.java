package com.varcore.engine.scene;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

public final class SceneManager {
    private final Map<String, Scene> scenes = new HashMap<>();
    private Scene activeScene;

    public Scene createScene(String name) {
        Scene scene = new Scene(name);
        scenes.put(name, scene);
        if (activeScene == null) {
            activeScene = scene;
        }
        return scene;
    }

    public void setActiveScene(String name) {
        activeScene = scenes.get(name);
    }

    public Scene getActiveScene() {
        return activeScene;
    }

    public Optional<Scene> getScene(String name) {
        return Optional.ofNullable(scenes.get(name));
    }
}
