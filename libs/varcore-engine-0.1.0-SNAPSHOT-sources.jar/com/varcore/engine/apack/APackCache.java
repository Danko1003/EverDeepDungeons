package com.varcore.engine.apack;

import java.util.HashMap;
import java.util.Map;

public final class APackCache {
    private final Map<String, APack> cache = new HashMap<>();

    public APack get(String key) {
        return cache.get(key);
    }

    public void put(String key, APack apack) {
        cache.put(key, apack);
    }

    public void clear() {
        cache.clear();
    }
}
