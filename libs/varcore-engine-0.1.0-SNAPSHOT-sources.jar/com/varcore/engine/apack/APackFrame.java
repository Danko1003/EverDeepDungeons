package com.varcore.engine.apack;

import java.util.List;

public final class APackFrame {
    private final int sheet;
    private final int x;
    private final int y;
    private final int width;
    private final int height;
    private final int duration;
    private final List<String> events;

    public APackFrame(int sheet, int x, int y, int width, int height, int duration, List<String> events) {
        this.sheet = sheet;
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.duration = duration;
        this.events = List.copyOf(events);
    }

    public int getSheet() { return sheet; }
    public int getX() { return x; }
    public int getY() { return y; }
    public int getWidth() { return width; }
    public int getHeight() { return height; }
    public int getDuration() { return duration; }
    public List<String> getEvents() { return events; }
}
