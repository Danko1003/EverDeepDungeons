package com.varcore.engine.apack;

import com.varcore.engine.animation.PlaybackMode;
import java.awt.image.BufferedImage;
import java.util.List;

public final class APack {
    private final String name;
    private final float fps;
    private final float speedMultiplier;
    private final PlaybackMode playbackMode;
    private final boolean loop;
    private final boolean pingPong;
    private final List<APackFrame> frames;
    private final BufferedImage[] sheets;

    public APack(String name, float fps, float speedMultiplier, PlaybackMode playbackMode,
                 List<APackFrame> frames, BufferedImage[] sheets) {
        this.name = name;
        this.fps = fps;
        this.speedMultiplier = speedMultiplier;
        this.playbackMode = playbackMode;
        this.loop = playbackMode == PlaybackMode.LOOP;
        this.pingPong = playbackMode == PlaybackMode.PING_PONG;
        this.frames = List.copyOf(frames);
        this.sheets = sheets;
    }

    public String getName() {
        return name;
    }

    public float getFps() {
        return fps;
    }

    public float getSpeedMultiplier() {
        return speedMultiplier;
    }

    public PlaybackMode getPlaybackMode() {
        return playbackMode;
    }

    public boolean isLoop() {
        return loop;
    }

    public boolean isPingPong() {
        return pingPong;
    }

    public List<APackFrame> getFrames() {
        return frames;
    }

    public BufferedImage[] getSheets() {
        return sheets;
    }
}
