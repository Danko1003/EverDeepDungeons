package com.varcore.engine.apack;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.varcore.engine.animation.PlaybackMode;
import com.varcore.engine.assets.AssetLoadException;
import com.varcore.engine.render.SpriteDraw;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Stream;
import javax.imageio.ImageIO;

/**
 * Loads APack folders. Caching is owned by {@link com.varcore.engine.assets.AssetManager}
 * so sheets are not retained twice.
 */
public final class APackLoader {
    public APack load(Path apackFolder) {
        Path animationFile = apackFolder.resolve("animation.json");
        if (!Files.exists(animationFile)) {
            throw new AssetLoadException("Missing animation.json in " + apackFolder, null);
        }

        JsonObject root;
        try {
            root = JsonParser.parseString(Files.readString(animationFile)).getAsJsonObject();
        } catch (IOException e) {
            throw new AssetLoadException("Failed to read animation.json", e);
        }

        String name = root.has("name") ? root.get("name").getAsString() : apackFolder.getFileName().toString();
        float fps = root.has("fps") ? root.get("fps").getAsFloat() : 12f;
        float speedMultiplier = root.has("speedMultiplier") ? root.get("speedMultiplier").getAsFloat() : 1f;
        boolean loop = !root.has("loop") || root.get("loop").getAsBoolean();
        boolean pingPong = root.has("pingPong") && root.get("pingPong").getAsBoolean();
        String playbackModeValue = root.has("playbackMode") ? root.get("playbackMode").getAsString() : null;
        PlaybackMode playbackMode = PlaybackMode.fromJson(playbackModeValue, loop, pingPong);

        Path sheetsDir = apackFolder.resolve("spritesheets");
        BufferedImage[] sheets = loadSheets(sheetsDir);
        List<APackFrame> frames = parseFrames(root.getAsJsonArray("frames"));

        return new APack(name, fps, speedMultiplier, playbackMode, frames, sheets);
    }

    private BufferedImage[] loadSheets(Path sheetsDir) {
        if (!Files.isDirectory(sheetsDir)) {
            throw new AssetLoadException("Missing spritesheets folder: " + sheetsDir, null);
        }
        try (Stream<Path> paths = Files.list(sheetsDir)) {
            List<Path> sheetFiles = paths
                    .filter(p -> p.toString().endsWith(".png"))
                    .sorted(Comparator.comparing(p -> p.getFileName().toString()))
                    .toList();
            BufferedImage[] sheets = new BufferedImage[sheetFiles.size()];
            for (int i = 0; i < sheetFiles.size(); i++) {
                BufferedImage loaded = ImageIO.read(sheetFiles.get(i).toFile());
                sheets[i] = SpriteDraw.toArgb(loaded);
            }
            return sheets;
        } catch (IOException e) {
            throw new AssetLoadException("Failed to load spritesheets", e);
        }
    }

    private List<APackFrame> parseFrames(JsonArray array) {
        List<APackFrame> frames = new ArrayList<>();
        for (JsonElement element : array) {
            JsonObject frame = element.getAsJsonObject();
            List<String> events = new ArrayList<>();
            if (frame.has("events")) {
                for (JsonElement ev : frame.getAsJsonArray("events")) {
                    events.add(ev.getAsString());
                }
            }
            frames.add(new APackFrame(
                    frame.get("sheet").getAsInt(),
                    frame.get("x").getAsInt(),
                    frame.get("y").getAsInt(),
                    frame.get("w").getAsInt(),
                    frame.get("h").getAsInt(),
                    frame.has("duration") ? frame.get("duration").getAsInt() : 1,
                    events
            ));
        }
        return frames;
    }
}
