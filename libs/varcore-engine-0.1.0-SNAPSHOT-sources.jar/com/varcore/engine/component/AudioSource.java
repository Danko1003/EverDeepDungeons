package com.varcore.engine.component;

import com.varcore.engine.audio.AudioManager;

public class AudioSource extends Component {
    private String soundPath;
    private boolean loop;
    private float volume = 1f;
    private boolean playOnStart;
    private boolean started;

    public void setSound(String path) {
        this.soundPath = path;
    }

    public void setLoop(boolean loop) {
        this.loop = loop;
    }

    public void setVolume(float volume) {
        this.volume = volume;
    }

    public void setPlayOnStart(boolean playOnStart) {
        this.playOnStart = playOnStart;
    }

    @Override
    public void onAttach() {
        if (playOnStart) {
            play();
        }
    }

    public void play() {
        AudioManager manager = AudioManager.getInstance();
        if (manager != null && soundPath != null) {
            manager.play(soundPath, loop, volume);
            started = true;
        }
    }

    public void stop() {
        AudioManager manager = AudioManager.getInstance();
        if (manager != null && soundPath != null) {
            manager.stop(soundPath);
            started = false;
        }
    }

    public boolean isStarted() {
        return started;
    }
}
