package com.varcore.engine.component;

import com.varcore.engine.particles.ParticleSystem;
import com.varcore.engine.render.Renderer;
import java.awt.Color;

public class ParticleEmitter extends Component {
    private final ParticleSystem system = new ParticleSystem();
    private float rate = 20f;
    private float accumulator;
    private float lifetime = 1f;
    private float speed = 50f;
    private float size = 4f;
    private Color color = Color.ORANGE;
    private int layer = 10;
    private boolean emitting = true;

    public void setRate(float rate) {
        this.rate = rate;
    }

    public void setLifetime(float lifetime) {
        this.lifetime = lifetime;
    }

    public void setSpeed(float speed) {
        this.speed = speed;
    }

    public void setSize(float size) {
        this.size = size;
    }

    public void setColor(Color color) {
        this.color = color;
    }

    public void setLayer(int layer) {
        this.layer = layer;
    }

    public void setGravity(float gravityY) {
        system.setGravity(gravityY);
    }

    public void setDrag(float drag) {
        system.setDrag(drag);
    }

    public void setEmitting(boolean emitting) {
        this.emitting = emitting;
    }

    public void burst(int count) {
        burst(count, 1f);
    }

    public void burst(int count, float speedMultiplier) {
        var pos = getGameObject().getTransform().getPosition();
        float scaledSpeed = speed * speedMultiplier;
        system.burst(
                pos.x,
                pos.y,
                count,
                scaledSpeed * 0.65f,
                scaledSpeed,
                lifetime * 0.75f,
                lifetime * 1.15f,
                size,
                color);
    }

    @Override
    public void update(float dt) {
        if (emitting && rate > 0f) {
            accumulator += rate * dt;
            while (accumulator >= 1f) {
                accumulator -= 1f;
                var pos = getGameObject().getTransform().getPosition();
                float angle = (float) (Math.random() * Math.PI * 2);
                float vx = (float) Math.cos(angle) * speed;
                float vy = (float) Math.sin(angle) * speed;
                system.emit(pos.x, pos.y, vx, vy, lifetime, size, color);
            }
        }
        system.update(dt);
    }

    @Override
    public void render(Renderer renderer) {
        system.render(renderer, layer);
    }

    public ParticleSystem getSystem() {
        return system;
    }
}
