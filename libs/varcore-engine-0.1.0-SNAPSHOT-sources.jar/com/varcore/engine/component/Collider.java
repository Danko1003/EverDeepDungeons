package com.varcore.engine.component;

import com.varcore.engine.collision.AABB;
import com.varcore.engine.collision.CollisionLayers;
import com.varcore.engine.math.Vector2;

public class Collider extends Component {
    private final AABB bounds = new AABB(0, 0, 32, 32);
    private float width = 32;
    private float height = 32;
    private float offsetX;
    private float offsetY;
    private boolean solid;
    private boolean trigger;
    private boolean staticBody;
    private int layer = CollisionLayers.DEFAULT;
    private int mask = CollisionLayers.ALL;

    public void setSize(float width, float height) {
        this.width = width;
        this.height = height;
        bounds.setSize(width, height);
    }

    public float getWidth() {
        return width;
    }

    public float getHeight() {
        return height;
    }

    public void setOffset(float offsetX, float offsetY) {
        this.offsetX = offsetX;
        this.offsetY = offsetY;
    }

    public void setSolid(boolean solid) {
        this.solid = solid;
    }

    public boolean isSolid() {
        return solid;
    }

    public void setTrigger(boolean trigger) {
        this.trigger = trigger;
    }

    public boolean isTrigger() {
        return trigger;
    }

    public void setStatic(boolean staticBody) {
        this.staticBody = staticBody;
    }

    public boolean isStatic() {
        return staticBody;
    }

    public void setLayer(int layer) {
        this.layer = layer;
    }

    public int getLayer() {
        return layer;
    }

    public void setMask(int mask) {
        this.mask = mask;
    }

    public int getMask() {
        return mask;
    }

    public boolean canCollideWith(Collider other) {
        return CollisionLayers.canInteract(layer, mask, other.layer, other.mask);
    }

    public boolean blocksMovement() {
        return solid && !trigger;
    }

    public AABB getBounds() {
        return bounds;
    }

    public void syncBounds() {
        Vector2 pos = getGameObject().getTransform().getPosition();
        bounds.setPosition(pos.x + offsetX, pos.y + offsetY);
        bounds.setSize(width, height);
    }

    public void onCollisionEnter(Collider other) {}

    public void onCollisionStay(Collider other) {}

    public void onCollisionExit(Collider other) {}
}
