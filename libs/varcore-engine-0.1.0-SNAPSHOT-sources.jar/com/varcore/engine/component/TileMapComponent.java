package com.varcore.engine.component;

import com.varcore.engine.camera.Camera;
import com.varcore.engine.tile.TileAnchorBinding;
import com.varcore.engine.tile.TileLibrary;
import com.varcore.engine.tile.TileMap;
import com.varcore.engine.tile.TileQueryResult;
import com.varcore.engine.tile.WorldGenerator;
import com.varcore.engine.render.Renderer;
import java.awt.Color;
import java.awt.image.BufferedImage;

/** Scene component that owns a {@link TileMap} and renders it each frame. */
public class TileMapComponent extends Component {
    private final TileMap map = new TileMap(1, 1);
    private TileLibrary library;
    private BufferedImage tileset;
    private boolean showAnchorMarkers;
    private boolean showGrid;

    public TileMap map() {
        return map;
    }

    public void setLibrary(TileLibrary library) {
        this.library = library;
        if (library != null) {
            map.setTileSize(library.defaultTileSize(), library.defaultTileSize());
        }
    }

    public TileLibrary library() {
        return library;
    }

    public void setTileset(BufferedImage tileset) {
        this.tileset = tileset;
    }

    public void setShowAnchorMarkers(boolean showAnchorMarkers) {
        this.showAnchorMarkers = showAnchorMarkers;
    }

    public void setShowGrid(boolean showGrid) {
        this.showGrid = showGrid;
    }

    public void resizeMap(int width, int height) {
        if (map.layer(TileMap.LAYER_PROPS).isEmpty()) {
            map.addLayer(TileMap.LAYER_PROPS, width, height);
        }
        if (map.layer(TileMap.LAYER_META).isEmpty()) {
            map.addLayer(TileMap.LAYER_META, width, height);
        }
        map.resize(width, height);
    }

    public void generate(WorldGenerator generator, long seed) {
        if (library == null) {
            throw new IllegalStateException("TileLibrary must be set before generate()");
        }
        generator.generate(map, library, seed);
    }

    public TileQueryResult queryWorld(float worldX, float worldY) {
        requireLibrary();
        return map.queryWorld(worldX, worldY, library);
    }

    public void addAnchor(TileAnchorBinding binding) {
        map.addAnchor(binding);
    }

    /** Places a tile using its anchor cell. Compound tiles render across their footprint. */
    public void placeTile(String layerName, int anchorCol, int anchorRow, String tileId) {
        requireLibrary();
        map.placeTile(layerName, anchorCol, anchorRow, tileId, library);
    }

    public void placeTile(int anchorCol, int anchorRow, String tileId) {
        placeTile(TileMap.LAYER_PROPS, anchorCol, anchorRow, tileId);
    }

    @Override
    public void render(Renderer renderer) {
        if (library == null || getGameObject() == null) {
            return;
        }
        var pos = getGameObject().getTransform().getPosition();
        map.setOrigin(pos.x, pos.y);

        Camera camera = renderer.getCamera();
        map.render(renderer, library, tileset, camera);

        if (showGrid) {
            renderGrid(renderer, camera);
        }
        if (showAnchorMarkers) {
            map.renderAnchors(renderer, new Color(0xFF, 0xD9, 0x3D));
        }
    }

    private void renderGrid(Renderer renderer, Camera camera) {
        var view = camera.getViewBounds();
        int minCol = (int) Math.floor((view.x - map.originX()) / map.tileWidth());
        int maxCol = (int) Math.ceil((view.right() - map.originX()) / map.tileWidth());
        int minRow = (int) Math.floor((view.y - map.originY()) / map.tileHeight());
        int maxRow = (int) Math.ceil((view.bottom() - map.originY()) / map.tileHeight());
        Color grid = new Color(0x3D, 0xDC, 0x84, 60);
        for (int col = minCol; col <= maxCol; col++) {
            float x = map.originX() + col * map.tileWidth();
            renderer.drawLine(x, view.y, x, view.bottom(), grid, 1f, 0);
        }
        for (int row = minRow; row <= maxRow; row++) {
            float y = map.originY() + row * map.tileHeight();
            renderer.drawLine(view.x, y, view.right(), y, grid, 1f, 0);
        }
    }

    private void requireLibrary() {
        if (library == null) {
            throw new IllegalStateException("TileLibrary not assigned to TileMapComponent");
        }
    }
}
