package com.varcore.engine.component;

import com.varcore.engine.render.Renderer;
import java.awt.Color;

/** Draws a filled rectangle or circle at the owning GameObject's transform. */
public class ShapeRenderer extends Component {
    public enum Shape {
        RECT,
        CIRCLE
    }

    private Shape shape = Shape.RECT;
    private Color color = Color.WHITE;
    private float width = 32f;
    private float height = 32f;
    private int layer;

    public ShapeRenderer rect(float width, float height, Color color) {
        this.shape = Shape.RECT;
        this.width = width;
        this.height = height;
        this.color = color == null ? Color.WHITE : color;
        return this;
    }

    public ShapeRenderer circle(float radius, Color color) {
        this.shape = Shape.CIRCLE;
        this.width = radius * 2f;
        this.height = radius * 2f;
        this.color = color == null ? Color.WHITE : color;
        return this;
    }

    public ShapeRenderer setColor(Color color) {
        this.color = color == null ? Color.WHITE : color;
        return this;
    }

    public ShapeRenderer setSize(float width, float height) {
        this.width = width;
        this.height = height;
        return this;
    }

    public ShapeRenderer setLayer(int layer) {
        this.layer = layer;
        return this;
    }

    public Shape shape() {
        return shape;
    }

    public Color color() {
        return color;
    }

    public float width() {
        return width;
    }

    public float height() {
        return height;
    }

    public int layer() {
        return layer;
    }

    @Override
    public void render(Renderer renderer) {
        if (getGameObject() == null) {
            return;
        }
        var pos = getGameObject().getTransform().getPosition();
        if (shape == Shape.CIRCLE) {
            float radius = Math.max(width, height) / 2f;
            renderer.drawCircle(pos.x, pos.y, radius, color, true, layer);
        } else {
            renderer.drawRect(pos.x, pos.y, width, height, color, true, layer);
        }
    }
}
