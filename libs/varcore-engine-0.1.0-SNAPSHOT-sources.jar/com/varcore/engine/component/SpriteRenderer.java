package com.varcore.engine.component;

import com.varcore.engine.render.Renderer;
import java.awt.image.BufferedImage;

public class SpriteRenderer extends Component {
    private BufferedImage image;
    private int layer;
    private float width;
    private float height;

    public void setImage(BufferedImage image) {
        this.image = image;
        if (image != null && width == 0 && height == 0) {
            width = image.getWidth();
            height = image.getHeight();
        }
    }

    public void setSize(float width, float height) {
        this.width = width;
        this.height = height;
    }

    public void setLayer(int layer) {
        this.layer = layer;
    }

    @Override
    public void render(Renderer renderer) {
        if (image == null || getGameObject() == null) {
            return;
        }
        var pos = getGameObject().getTransform().getPosition();
        renderer.drawSprite(image, pos.x, pos.y, width, height, layer);
    }
}
