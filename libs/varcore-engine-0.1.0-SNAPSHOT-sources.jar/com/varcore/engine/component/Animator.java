package com.varcore.engine.component;

import com.varcore.engine.animation.AnimationPlayer;
import com.varcore.engine.apack.APack;
import com.varcore.engine.apack.APackFrame;
import com.varcore.engine.render.Renderer;

public class Animator extends Component {
    private final AnimationPlayer player = new AnimationPlayer();
    private int layer;
    private float width = 64;
    private float height = 64;

    public void setAPack(APack apack) {
        player.setAPack(apack);
    }

    public AnimationPlayer getPlayer() {
        return player;
    }

    public void setSize(float width, float height) {
        this.width = width;
        this.height = height;
    }

    public void setLayer(int layer) {
        this.layer = layer;
    }

    @Override
    public void update(float dt) {
        player.update(dt);
    }

    @Override
    public void render(Renderer renderer) {
        APackFrame frame = player.getCurrentFrameData();
        APack pack = player.getAPack();
        if (frame == null || pack == null || getGameObject() == null) {
            return;
        }
        var pos = getGameObject().getTransform().getPosition();
        renderer.drawSpriteRegion(
                pack.getSheets()[frame.getSheet()],
                frame.getX(), frame.getY(), frame.getWidth(), frame.getHeight(),
                pos.x, pos.y, width, height, layer);
    }
}
