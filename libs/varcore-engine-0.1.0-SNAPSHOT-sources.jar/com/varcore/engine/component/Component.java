package com.varcore.engine.component;

import com.varcore.engine.entity.GameObject;
import com.varcore.engine.render.Renderer;

public abstract class Component {
    private GameObject gameObject;
    private boolean enabled = true;

    public void onAttach() {}

    public void onDestroy() {}

    public void update(float dt) {}

    public void render(Renderer renderer) {}

    public GameObject getGameObject() {
        return gameObject;
    }

    public void setGameObject(GameObject gameObject) {
        this.gameObject = gameObject;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }
}
