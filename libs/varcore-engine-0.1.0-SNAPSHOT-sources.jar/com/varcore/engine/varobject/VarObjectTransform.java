package com.varcore.engine.varobject;

import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;

/** Pivot and rotation helpers for VarObject layer trees. */
public final class VarObjectTransform {
    public static final float DEFAULT_ANCHOR = 0.5f;

    private VarObjectTransform() {
    }

    public static float pivotX(VarObjectNode node) {
        return node.anchorX() * node.width();
    }

    public static float pivotY(VarObjectNode node) {
        return node.anchorY() * node.height();
    }

    public static void appendLocalRotation(AffineTransform transform, VarObjectNode node) {
        if (Math.abs(node.rotation()) < 1e-6f) {
            return;
        }
        float ax = pivotX(node);
        float ay = pivotY(node);
        transform.translate(ax, ay);
        transform.rotate(Math.toRadians(node.rotation()));
        transform.translate(-ax, -ay);
    }

    public static void applyLocalRotation(Graphics2D graphics, VarObjectNode node) {
        if (Math.abs(node.rotation()) < 1e-6f) {
            return;
        }
        float ax = pivotX(node);
        float ay = pivotY(node);
        graphics.translate(ax, ay);
        graphics.rotate(Math.toRadians(node.rotation()));
        graphics.translate(-ax, -ay);
    }

    public static Rectangle2D.Float rotatedBounds(float x, float y, float width, float height,
                                                  float anchorX, float anchorY, float rotationDegrees) {
        if (Math.abs(rotationDegrees) < 1e-6f) {
            return new Rectangle2D.Float(x, y, width, height);
        }
        AffineTransform tx = new AffineTransform();
        tx.translate(x, y);
        appendLocalRotation(tx, anchorX, anchorY, width, height, rotationDegrees);
        Rectangle2D bounds = tx.createTransformedShape(
                new Rectangle2D.Float(0f, 0f, width, height)).getBounds2D();
        return new Rectangle2D.Float(
                (float) bounds.getX(), (float) bounds.getY(),
                (float) bounds.getWidth(), (float) bounds.getHeight());
    }

    public static void appendLocalRotation(AffineTransform transform, float anchorX, float anchorY,
                                           float width, float height, float rotationDegrees) {
        if (Math.abs(rotationDegrees) < 1e-6f) {
            return;
        }
        float ax = anchorX * width;
        float ay = anchorY * height;
        transform.translate(ax, ay);
        transform.rotate(Math.toRadians(rotationDegrees));
        transform.translate(-ax, -ay);
    }

    public static boolean containsLocalPoint(VarObjectNode node, double localX, double localY) {
        return localX >= 0 && localX <= node.width() && localY >= 0 && localY <= node.height();
    }

    public static Point2D worldToLocal(AffineTransform nodeTransform, double worldX, double worldY) {
        try {
            AffineTransform inverse = nodeTransform.createInverse();
            double[] pt = {worldX, worldY};
            inverse.transform(pt, 0, pt, 0, 1);
            return new Point2D.Double(pt[0], pt[1]);
        } catch (Exception ex) {
            return null;
        }
    }

    public static float[] boundsOfTree(VarObjectNode root, float originX, float originY) {
        BoundsAcc acc = new BoundsAcc();
        AffineTransform origin = new AffineTransform();
        origin.translate(originX, originY);
        accumulateBounds(root, origin, acc);
        if (!acc.found) {
            return new float[]{originX, originY, root.width(), root.height()};
        }
        return new float[]{acc.minX, acc.minY, acc.maxX - acc.minX, acc.maxY - acc.minY};
    }

    private static void accumulateBounds(VarObjectNode node, AffineTransform parentTransform, BoundsAcc acc) {
        AffineTransform nodeTransform = new AffineTransform(parentTransform);
        nodeTransform.translate(node.x(), node.y());
        appendLocalRotation(nodeTransform, node);

        if (node.parent().isPresent()) {
            includeTransformedRect(nodeTransform, 0f, 0f, node.width(), node.height(), acc);
        }

        for (VarObjectNode child : node.children()) {
            accumulateBounds(child, nodeTransform, acc);
        }
    }

    private static void includeTransformedRect(AffineTransform transform, float x, float y,
                                               float width, float height, BoundsAcc acc) {
        Point2D.Float[] corners = {
                transformPoint(transform, x, y),
                transformPoint(transform, x + width, y),
                transformPoint(transform, x, y + height),
                transformPoint(transform, x + width, y + height)
        };
        for (Point2D.Float corner : corners) {
            acc.include(corner.x, corner.y);
        }
    }

    private static Point2D.Float transformPoint(AffineTransform transform, float x, float y) {
        float[] pt = {x, y};
        transform.transform(pt, 0, pt, 0, 1);
        return new Point2D.Float(pt[0], pt[1]);
    }

    private static final class BoundsAcc {
        private boolean found;
        private float minX = Float.MAX_VALUE;
        private float minY = Float.MAX_VALUE;
        private float maxX = -Float.MAX_VALUE;
        private float maxY = -Float.MAX_VALUE;

        private void include(float x, float y) {
            found = true;
            minX = Math.min(minX, x);
            minY = Math.min(minY, y);
            maxX = Math.max(maxX, x);
            maxY = Math.max(maxY, y);
        }
    }
}
