package com.varcore.engine.varobject;

import java.util.UUID;

/** Authorable visual effect on a {@link VarObjectNode}. */
public final class VarObjectEffect {
    private String id;
    private VarObjectEffectType type = VarObjectEffectType.TINT;
    private boolean enabled = true;
    private String color = "#FFFFFF";
    private float intensity = 0.75f;
    private float speed = 1.5f;
    private float width = 2f;
    private VarObjectOutlineMode outlineMode = VarObjectOutlineMode.AUTO;
    private float outlineShapeWidth = 1f;
    private float outlineShapeHeight = 1f;

    public static VarObjectEffect create(VarObjectEffectType type) {
        VarObjectEffect effect = new VarObjectEffect();
        effect.id = type.name().toLowerCase() + "_" + UUID.randomUUID().toString().substring(0, 8);
        effect.type = type;
        switch (type) {
            case TINT -> {
                effect.color = "#FF6B6B";
                effect.intensity = 0.45f;
                effect.speed = 1f;
            }
            case FLASH -> {
                effect.color = "#FFFFFF";
                effect.intensity = 0.85f;
                effect.speed = 4f;
            }
            case OUTLINE -> {
                effect.color = "#FFD93D";
                effect.intensity = 1f;
                effect.width = 2f;
                effect.speed = 1f;
            }
            case GLOW -> {
                effect.color = "#3DDC84";
                effect.intensity = 0.65f;
                effect.speed = 1.2f;
            }
            case PULSE -> {
                effect.intensity = 1f;
                effect.speed = 1.5f;
            }
            case SHIMMER -> {
                effect.color = "#5B8CFF";
                effect.intensity = 0.5f;
                effect.speed = 2f;
            }
            case FADE -> {
                effect.intensity = 1f;
                effect.speed = 0.8f;
            }
        }
        return effect;
    }

    public String id() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? "" : id;
    }

    public VarObjectEffectType type() {
        return type;
    }

    public void setType(VarObjectEffectType type) {
        this.type = type == null ? VarObjectEffectType.TINT : type;
    }

    public boolean enabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public String color() {
        return color;
    }

    public void setColor(String color) {
        this.color = color == null || color.isBlank() ? "#FFFFFF" : color;
    }

    public float intensity() {
        return intensity;
    }

    public void setIntensity(float intensity) {
        this.intensity = Math.max(0f, Math.min(1f, intensity));
    }

    public float speed() {
        return speed;
    }

    public void setSpeed(float speed) {
        this.speed = Math.max(0.05f, speed);
    }

    public float width() {
        return width;
    }

    public void setWidth(float width) {
        this.width = Math.max(0.5f, width);
    }

    public VarObjectOutlineMode outlineMode() {
        return outlineMode;
    }

    public void setOutlineMode(VarObjectOutlineMode outlineMode) {
        this.outlineMode = outlineMode == null ? VarObjectOutlineMode.AUTO : outlineMode;
    }

    public float outlineShapeWidth() {
        return outlineShapeWidth;
    }

    public void setOutlineShapeWidth(float outlineShapeWidth) {
        this.outlineShapeWidth = Math.max(0.05f, Math.min(1f, outlineShapeWidth));
    }

    public float outlineShapeHeight() {
        return outlineShapeHeight;
    }

    public void setOutlineShapeHeight(float outlineShapeHeight) {
        this.outlineShapeHeight = Math.max(0.05f, Math.min(1f, outlineShapeHeight));
    }

    public VarObjectEffect copy() {
        VarObjectEffect copy = new VarObjectEffect();
        copy.id = id;
        copy.type = type;
        copy.enabled = enabled;
        copy.color = color;
        copy.intensity = intensity;
        copy.speed = speed;
        copy.width = width;
        copy.outlineMode = outlineMode;
        copy.outlineShapeWidth = outlineShapeWidth;
        copy.outlineShapeHeight = outlineShapeHeight;
        return copy;
    }
}
