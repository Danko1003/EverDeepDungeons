package com.varcore.engine.varobject;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.List;

/** JSON serialization for {@link VarObjectDefinition}. */
public final class VarObjectCodec {
    private VarObjectCodec() {
    }

    public static JsonObject toJson(VarObjectDefinition definition) {
        JsonObject root = new JsonObject();
        root.addProperty("id", definition.id());
        root.addProperty("name", definition.name());
        root.addProperty("defaultOpacity", definition.defaultOpacity());
        root.add("collision", collisionToJson(definition.collision()));
        root.add("root", nodeToJson(definition.root()));
        return root;
    }

    public static VarObjectDefinition fromJson(JsonObject root) {
        VarObjectDefinition definition = VarObjectDefinition.createNew();
        if (root.has("id")) {
            definition.setId(root.get("id").getAsString());
        }
        if (root.has("name")) {
            definition.setName(root.get("name").getAsString());
        }
        if (root.has("defaultOpacity")) {
            definition.setDefaultOpacity(root.get("defaultOpacity").getAsFloat());
        }
        if (root.has("collision") && root.get("collision").isJsonObject()) {
            collisionFromJson(definition.collision(), root.getAsJsonObject("collision"));
        }
        if (root.has("root") && root.get("root").isJsonObject()) {
            definition.setRoot(nodeFromJson(root.getAsJsonObject("root"), null));
        }
        return definition;
    }

    private static JsonObject collisionToJson(VarObjectCollision collision) {
        JsonObject json = new JsonObject();
        json.addProperty("enabled", collision.enabled());
        json.addProperty("x", collision.x());
        json.addProperty("y", collision.y());
        json.addProperty("width", collision.width());
        json.addProperty("height", collision.height());
        json.addProperty("solid", collision.solid());
        json.addProperty("trigger", collision.trigger());
        json.addProperty("layer", collision.layer());
        json.addProperty("mask", collision.mask());
        return json;
    }

    private static void collisionFromJson(VarObjectCollision collision, JsonObject json) {
        if (json.has("enabled")) {
            collision.setEnabled(json.get("enabled").getAsBoolean());
        }
        if (json.has("x")) {
            collision.setX(json.get("x").getAsFloat());
        }
        if (json.has("y")) {
            collision.setY(json.get("y").getAsFloat());
        }
        if (json.has("width")) {
            collision.setWidth(json.get("width").getAsFloat());
        }
        if (json.has("height")) {
            collision.setHeight(json.get("height").getAsFloat());
        }
        if (json.has("solid")) {
            collision.setSolid(json.get("solid").getAsBoolean());
        }
        if (json.has("trigger")) {
            collision.setTrigger(json.get("trigger").getAsBoolean());
        }
        if (json.has("layer")) {
            collision.setLayer(json.get("layer").getAsInt());
        }
        if (json.has("mask")) {
            collision.setMask(json.get("mask").getAsInt());
        }
    }

    private static JsonObject nodeToJson(VarObjectNode node) {
        JsonObject json = new JsonObject();
        json.addProperty("id", node.id());
        json.addProperty("name", node.name());
        json.addProperty("type", node.type().name());
        json.addProperty("x", node.x());
        json.addProperty("y", node.y());
        json.addProperty("width", node.width());
        json.addProperty("height", node.height());
        json.addProperty("opacity", node.opacity());
        if (Math.abs(node.rotation()) > 1e-6f) {
            json.addProperty("rotation", node.rotation());
        }
        if (Math.abs(node.anchorX() - VarObjectTransform.DEFAULT_ANCHOR) > 1e-6f) {
            json.addProperty("anchorX", node.anchorX());
        }
        if (Math.abs(node.anchorY() - VarObjectTransform.DEFAULT_ANCHOR) > 1e-6f) {
            json.addProperty("anchorY", node.anchorY());
        }
        if (node.type() == VarObjectNodeType.RECT || node.type() == VarObjectNodeType.ELLIPSE
                || node.type() == VarObjectNodeType.GROUP) {
            json.addProperty("color", node.color());
        }
        if (node.type() == VarObjectNodeType.IMAGE && !node.imagePath().isBlank()) {
            json.addProperty("image", node.imagePath());
        }
        if (node.type() == VarObjectNodeType.APACK && !node.apackPath().isBlank()) {
            json.addProperty("apack", node.apackPath());
            json.addProperty("lockAspectRatio", node.lockAspectRatio());
            if (node.intrinsicWidth() > 0f && node.intrinsicHeight() > 0f) {
                json.addProperty("intrinsicWidth", node.intrinsicWidth());
                json.addProperty("intrinsicHeight", node.intrinsicHeight());
            }
        }
        if (!node.effects().isEmpty()) {
            JsonArray effectArray = new JsonArray();
            for (VarObjectEffect effect : node.effects()) {
                effectArray.add(effectToJson(effect));
            }
            json.add("effects", effectArray);
        }
        JsonArray children = new JsonArray();
        for (VarObjectNode child : node.children()) {
            children.add(nodeToJson(child));
        }
        json.add("children", children);
        return json;
    }

    private static VarObjectNode nodeFromJson(JsonObject json, VarObjectNode parent) {
        String id = json.has("id") ? json.get("id").getAsString() : "node";
        String name = json.has("name") ? json.get("name").getAsString() : id;
        VarObjectNodeType type = VarObjectNodeType.fromString(
                json.has("type") ? json.get("type").getAsString() : "GROUP");
        VarObjectNode node = new VarObjectNode(id, name, type);
        if (json.has("x")) {
            node.setX(json.get("x").getAsFloat());
        }
        if (json.has("y")) {
            node.setY(json.get("y").getAsFloat());
        }
        if (json.has("width")) {
            node.setWidth(json.get("width").getAsFloat());
        }
        if (json.has("height")) {
            node.setHeight(json.get("height").getAsFloat());
        }
        if (json.has("opacity")) {
            node.setOpacity(json.get("opacity").getAsFloat());
        }
        if (json.has("rotation")) {
            node.setRotation(json.get("rotation").getAsFloat());
        }
        if (json.has("anchorX") && json.has("anchorY")) {
            node.setAnchor(json.get("anchorX").getAsFloat(), json.get("anchorY").getAsFloat());
        } else {
            if (json.has("anchorX")) {
                node.setAnchor(json.get("anchorX").getAsFloat(), node.anchorY());
            }
            if (json.has("anchorY")) {
                node.setAnchor(node.anchorX(), json.get("anchorY").getAsFloat());
            }
        }
        if (json.has("color")) {
            node.setColor(json.get("color").getAsString());
        }
        if (json.has("image")) {
            node.setImagePath(json.get("image").getAsString());
        }
        if (json.has("apack")) {
            node.setApackPath(json.get("apack").getAsString());
        }
        if (json.has("lockAspectRatio")) {
            node.setLockAspectRatio(json.get("lockAspectRatio").getAsBoolean());
        }
        if (json.has("intrinsicWidth") && json.has("intrinsicHeight")) {
            node.setIntrinsicSize(
                    json.get("intrinsicWidth").getAsFloat(),
                    json.get("intrinsicHeight").getAsFloat());
        }
        if (json.has("effects") && json.get("effects").isJsonArray()) {
            for (JsonElement effectEl : json.getAsJsonArray("effects")) {
                if (effectEl.isJsonObject()) {
                    node.addEffect(effectFromJson(effectEl.getAsJsonObject()));
                }
            }
        }
        if (parent != null) {
            parent.addChild(node);
        }
        if (json.has("children") && json.get("children").isJsonArray()) {
            for (JsonElement childEl : json.getAsJsonArray("children")) {
                nodeFromJson(childEl.getAsJsonObject(), node);
            }
        }
        return node;
    }

    private static JsonObject effectToJson(VarObjectEffect effect) {
        JsonObject json = new JsonObject();
        json.addProperty("id", effect.id());
        json.addProperty("type", effect.type().name());
        json.addProperty("enabled", effect.enabled());
        json.addProperty("color", effect.color());
        json.addProperty("intensity", effect.intensity());
        json.addProperty("speed", effect.speed());
        if (effect.type() == VarObjectEffectType.OUTLINE) {
            json.addProperty("width", effect.width());
            json.addProperty("outlineMode", effect.outlineMode().name());
            json.addProperty("outlineShapeWidth", effect.outlineShapeWidth());
            json.addProperty("outlineShapeHeight", effect.outlineShapeHeight());
        }
        return json;
    }

    private static VarObjectEffect effectFromJson(JsonObject json) {
        VarObjectEffectType type = VarObjectEffectType.fromString(
                json.has("type") ? json.get("type").getAsString() : "TINT");
        VarObjectEffect effect = VarObjectEffect.create(type);
        if (json.has("id")) {
            effect.setId(json.get("id").getAsString());
        }
        if (json.has("enabled")) {
            effect.setEnabled(json.get("enabled").getAsBoolean());
        }
        if (json.has("color")) {
            effect.setColor(json.get("color").getAsString());
        }
        if (json.has("intensity")) {
            effect.setIntensity(json.get("intensity").getAsFloat());
        }
        if (json.has("speed")) {
            effect.setSpeed(json.get("speed").getAsFloat());
        }
        if (json.has("width")) {
            effect.setWidth(json.get("width").getAsFloat());
        }
        if (json.has("outlineMode")) {
            effect.setOutlineMode(VarObjectOutlineMode.fromString(json.get("outlineMode").getAsString()));
        }
        if (json.has("outlineShapeWidth")) {
            effect.setOutlineShapeWidth(json.get("outlineShapeWidth").getAsFloat());
        }
        if (json.has("outlineShapeHeight")) {
            effect.setOutlineShapeHeight(json.get("outlineShapeHeight").getAsFloat());
        }
        return effect;
    }

    public static List<String> collectImagePaths(VarObjectNode node) {
        List<String> paths = new ArrayList<>();
        collectImagePaths(node, paths);
        return paths;
    }

    private static void collectImagePaths(VarObjectNode node, List<String> paths) {
        if (node.type() == VarObjectNodeType.IMAGE && !node.imagePath().isBlank()) {
            paths.add(node.imagePath());
        }
        for (VarObjectNode child : node.children()) {
            collectImagePaths(child, paths);
        }
    }
}
