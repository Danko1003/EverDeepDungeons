package com.varcore.engine.varobject;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.varcore.engine.assets.AssetLoadException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public final class VarObjectLoader {
    public VarObjectDefinition load(Path varObjectFolder) {
        Path objectFile = varObjectFolder.resolve("object.json");
        if (!Files.exists(objectFile)) {
            throw new AssetLoadException("Missing object.json in " + varObjectFolder, null);
        }
        try {
            JsonObject root = JsonParser.parseString(Files.readString(objectFile)).getAsJsonObject();
            VarObjectDefinition definition = VarObjectCodec.fromJson(root);
            if (definition.id().isBlank()) {
                definition.setId(varObjectFolder.getFileName().toString().replace(".varobject", ""));
            }
            return definition;
        } catch (IOException e) {
            throw new AssetLoadException("Failed to read object.json", e);
        }
    }
}
