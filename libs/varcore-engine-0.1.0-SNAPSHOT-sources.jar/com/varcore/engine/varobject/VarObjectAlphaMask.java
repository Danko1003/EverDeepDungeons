package com.varcore.engine.varobject;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferInt;
import java.lang.ref.SoftReference;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Builds alpha-respecting masks from sprite regions for effects.
 * Masks are created at source-region resolution (not destination size) and cached
 * with soft references so large on-screen scales do not allocate huge bitmaps every frame.
 */
public final class VarObjectAlphaMask {
    private static final int ALPHA_CUTOFF = 2;
    private static final int MAX_CACHE_ENTRIES = 96;

    private static final Map<Long, SoftReference<BufferedImage>> SILHOUETTE_CACHE =
            new LinkedHashMap<>(64, 0.75f, true) {
                @Override
                protected boolean removeEldestEntry(Map.Entry<Long, SoftReference<BufferedImage>> eldest) {
                    return size() > MAX_CACHE_ENTRIES;
                }
            };

    private VarObjectAlphaMask() {
    }

    /** Source-resolution silhouette; draw it scaled to the destination. */
    public static BufferedImage createSilhouette(BufferedImage source, VarObjectEffectDraw.SpriteRegion region,
                                                 Color color) {
        if (source == null || source.getWidth() <= 0 || source.getHeight() <= 0 || region == null) {
            return empty(1, 1);
        }
        int rw = Math.max(1, region.sw());
        int rh = Math.max(1, region.sh());
        long key = cacheKey(source, region, color.getRGB());
        synchronized (SILHOUETTE_CACHE) {
            SoftReference<BufferedImage> ref = SILHOUETTE_CACHE.get(key);
            BufferedImage cached = ref != null ? ref.get() : null;
            if (cached != null) {
                return cached;
            }
        }

        BufferedImage out = buildSilhouette(source, region, rw, rh, color);
        synchronized (SILHOUETTE_CACHE) {
            SILHOUETTE_CACHE.put(key, new SoftReference<>(out));
        }
        return out;
    }

    /**
     * @deprecated Prefer {@link #createSilhouette(BufferedImage, VarObjectEffectDraw.SpriteRegion, Color)}
     * and scale at draw time. Kept for callers that pass destination size; ignores dest size.
     */
    @Deprecated
    public static BufferedImage createSilhouette(BufferedImage source, VarObjectEffectDraw.SpriteRegion region,
                                                 int width, int height, Color color) {
        return createSilhouette(source, region, color);
    }

    public static BufferedImage applyTint(BufferedImage source, VarObjectEffectDraw.SpriteRegion region,
                                          int width, int height, Color tint, float strength) {
        int rw = Math.max(1, region != null ? region.sw() : width);
        int rh = Math.max(1, region != null ? region.sh() : height);
        BufferedImage out = new BufferedImage(rw, rh, BufferedImage.TYPE_INT_ARGB);
        if (source == null || source.getWidth() <= 0 || source.getHeight() <= 0 || region == null) {
            return out;
        }
        float s = Math.max(0f, Math.min(1f, strength));
        int tr = tint.getRed();
        int tg = tint.getGreen();
        int tb = tint.getBlue();
        int[] pixels = ((DataBufferInt) out.getRaster().getDataBuffer()).getData();
        for (int py = 0; py < rh; py++) {
            int sy = sampleY(region, py, rh, source.getHeight());
            int row = py * rw;
            for (int px = 0; px < rw; px++) {
                int sx = sampleX(region, px, rw, source.getWidth());
                int sample = source.getRGB(sx, sy);
                int sa = (sample >>> 24) & 0xFF;
                if (sa < ALPHA_CUTOFF) {
                    continue;
                }
                int sr = (sample >> 16) & 0xFF;
                int sg = (sample >> 8) & 0xFF;
                int sb = sample & 0xFF;
                int or = Math.round(sr * (1f - s) + tr * s);
                int og = Math.round(sg * (1f - s) + tg * s);
                int ob = Math.round(sb * (1f - s) + tb * s);
                pixels[row + px] = (sa << 24) | (or << 16) | (og << 8) | ob;
            }
        }
        return out;
    }

    public static void clearCache() {
        synchronized (SILHOUETTE_CACHE) {
            SILHOUETTE_CACHE.clear();
        }
    }

    private static BufferedImage buildSilhouette(BufferedImage source, VarObjectEffectDraw.SpriteRegion region,
                                                 int rw, int rh, Color color) {
        BufferedImage out = new BufferedImage(rw, rh, BufferedImage.TYPE_INT_ARGB);
        int cr = color.getRed();
        int cg = color.getGreen();
        int cb = color.getBlue();
        float colorAlpha = color.getAlpha() / 255f;
        int[] pixels = ((DataBufferInt) out.getRaster().getDataBuffer()).getData();
        int srcW = source.getWidth();
        int srcH = source.getHeight();

        // Prefer bulk read of the source region when possible.
        int[] srcRow = new int[Math.max(1, region.sw())];
        for (int py = 0; py < rh; py++) {
            int sy = sampleY(region, py, rh, srcH);
            int row = py * rw;
            if (region.sw() == rw && region.sx() >= 0 && region.sx() + rw <= srcW) {
                source.getRGB(region.sx(), sy, rw, 1, srcRow, 0, rw);
                for (int px = 0; px < rw; px++) {
                    int sample = srcRow[px];
                    int sa = (sample >>> 24) & 0xFF;
                    if (sa < ALPHA_CUTOFF) {
                        continue;
                    }
                    int outA = Math.min(255, Math.round((sa / 255f) * colorAlpha * 255f));
                    pixels[row + px] = (outA << 24) | (cr << 16) | (cg << 8) | cb;
                }
            } else {
                for (int px = 0; px < rw; px++) {
                    int sx = sampleX(region, px, rw, srcW);
                    int sample = source.getRGB(sx, sy);
                    int sa = (sample >>> 24) & 0xFF;
                    if (sa < ALPHA_CUTOFF) {
                        continue;
                    }
                    int outA = Math.min(255, Math.round((sa / 255f) * colorAlpha * 255f));
                    pixels[row + px] = (outA << 24) | (cr << 16) | (cg << 8) | cb;
                }
            }
        }
        return out;
    }

    private static BufferedImage empty(int w, int h) {
        return new BufferedImage(Math.max(1, w), Math.max(1, h), BufferedImage.TYPE_INT_ARGB);
    }

    private static long cacheKey(BufferedImage source, VarObjectEffectDraw.SpriteRegion region, int rgb) {
        long h = System.identityHashCode(source);
        h = h * 31L + region.sx();
        h = h * 31L + region.sy();
        h = h * 31L + region.sw();
        h = h * 31L + region.sh();
        h = h * 31L + (rgb & 0xFFFFFFFFL);
        return h;
    }

    private static int sampleX(VarObjectEffectDraw.SpriteRegion region, int px, int width, int srcW) {
        if (region.sw() <= 0 || width <= 0) {
            return 0;
        }
        double u = (px + 0.5) / width;
        int sx = region.sx() + (int) (u * region.sw());
        return Math.max(0, Math.min(srcW - 1, sx));
    }

    private static int sampleY(VarObjectEffectDraw.SpriteRegion region, int py, int height, int srcH) {
        if (region.sh() <= 0 || height <= 0) {
            return 0;
        }
        double v = (py + 0.5) / height;
        int sy = region.sy() + (int) (v * region.sh());
        return Math.max(0, Math.min(srcH - 1, sy));
    }
}
