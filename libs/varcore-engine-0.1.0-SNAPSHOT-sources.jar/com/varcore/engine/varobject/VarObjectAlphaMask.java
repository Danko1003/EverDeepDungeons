package com.varcore.engine.varobject;

import java.awt.Color;
import java.awt.image.BufferedImage;

/** Builds alpha-respecting masks from sprite regions for effects. */
public final class VarObjectAlphaMask {
    private static final int ALPHA_CUTOFF = 2;

    private VarObjectAlphaMask() {
    }

    public static BufferedImage createSilhouette(BufferedImage source, VarObjectEffectDraw.SpriteRegion region,
                                                   int width, int height, Color color) {
        BufferedImage out = new BufferedImage(Math.max(1, width), Math.max(1, height), BufferedImage.TYPE_INT_ARGB);
        if (source == null || source.getWidth() <= 0 || source.getHeight() <= 0) {
            return out;
        }
        int srcW = source.getWidth();
        int srcH = source.getHeight();
        int cr = color.getRed();
        int cg = color.getGreen();
        int cb = color.getBlue();
        float colorAlpha = color.getAlpha() / 255f;
        int rw = Math.max(1, width);
        int rh = Math.max(1, height);

        for (int py = 0; py < rh; py++) {
            int sy = sampleY(region, py, rh, srcH);
            for (int px = 0; px < rw; px++) {
                int sx = sampleX(region, px, rw, srcW);
                int sample = source.getRGB(sx, sy);
                int sa = (sample >>> 24) & 0xFF;
                if (sa < ALPHA_CUTOFF) {
                    continue;
                }
                int outA = Math.min(255, Math.round((sa / 255f) * colorAlpha * 255f));
                out.setRGB(px, py, (outA << 24) | (cr << 16) | (cg << 8) | cb);
            }
        }
        return out;
    }

    public static BufferedImage applyTint(BufferedImage source, VarObjectEffectDraw.SpriteRegion region,
                                          int width, int height, Color tint, float strength) {
        BufferedImage out = new BufferedImage(Math.max(1, width), Math.max(1, height), BufferedImage.TYPE_INT_ARGB);
        if (source == null || source.getWidth() <= 0 || source.getHeight() <= 0) {
            return out;
        }
        int srcW = source.getWidth();
        int srcH = source.getHeight();
        float s = Math.max(0f, Math.min(1f, strength));
        int tr = tint.getRed();
        int tg = tint.getGreen();
        int tb = tint.getBlue();
        int rw = Math.max(1, width);
        int rh = Math.max(1, height);

        for (int py = 0; py < rh; py++) {
            int sy = sampleY(region, py, rh, srcH);
            for (int px = 0; px < rw; px++) {
                int sx = sampleX(region, px, rw, srcW);
                int sample = source.getRGB(sx, sy);
                int sa = (sample >>> 24) & 0xFF;
                if (sa < ALPHA_CUTOFF) {
                    continue;
                }
                int sr = (sample >> 16) & 0xFF;
                int sg = (sample >> 8) & 0xFF;
                int sb = sample & 0xFF;
                int or = Math.round(sr * (1f - s) + tr * s);
                int og = Math.round(sg * (1f - s) + tg * s);
                int ob = Math.round(sb * (1f - s) + tb * s);
                out.setRGB(px, py, (sa << 24) | (or << 16) | (og << 8) | ob);
            }
        }
        return out;
    }

    private static int sampleX(VarObjectEffectDraw.SpriteRegion region, int px, int width, int srcW) {
        if (region.sw() <= 0 || width <= 0) {
            return 0;
        }
        double u = (px + 0.5) / width;
        int sx = region.sx() + (int) (u * region.sw());
        return Math.max(0, Math.min(srcW - 1, sx));
    }

    private static int sampleY(VarObjectEffectDraw.SpriteRegion region, int py, int height, int srcH) {
        if (region.sh() <= 0 || height <= 0) {
            return 0;
        }
        double v = (py + 0.5) / height;
        int sy = region.sy() + (int) (v * region.sh());
        return Math.max(0, Math.min(srcH - 1, sy));
    }
}
