package com.varcore.engine.varobject;

/** Optional axis-aligned hitbox for a VarObject. */
public final class VarObjectCollision {
    private boolean enabled;
    private float x;
    private float y;
    private float width = 32f;
    private float height = 32f;
    private boolean solid = true;
    private boolean trigger;
    private int layer = 1;
    private int mask = 0xFF;

    public boolean enabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public float x() {
        return x;
    }

    public void setX(float x) {
        this.x = x;
    }

    public float y() {
        return y;
    }

    public void setY(float y) {
        this.y = y;
    }

    public float width() {
        return width;
    }

    public void setWidth(float width) {
        this.width = width;
    }

    public float height() {
        return height;
    }

    public void setHeight(float height) {
        this.height = height;
    }

    public boolean solid() {
        return solid;
    }

    public void setSolid(boolean solid) {
        this.solid = solid;
    }

    public boolean trigger() {
        return trigger;
    }

    public void setTrigger(boolean trigger) {
        this.trigger = trigger;
    }

    public int layer() {
        return layer;
    }

    public void setLayer(int layer) {
        this.layer = layer;
    }

    public int mask() {
        return mask;
    }

    public void setMask(int mask) {
        this.mask = mask;
    }

    public VarObjectCollision copy() {
        VarObjectCollision copy = new VarObjectCollision();
        copy.enabled = enabled;
        copy.x = x;
        copy.y = y;
        copy.width = width;
        copy.height = height;
        copy.solid = solid;
        copy.trigger = trigger;
        copy.layer = layer;
        copy.mask = mask;
        return copy;
    }
}
