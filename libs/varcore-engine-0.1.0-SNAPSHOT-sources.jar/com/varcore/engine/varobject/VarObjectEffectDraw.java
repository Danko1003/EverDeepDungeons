package com.varcore.engine.varobject;

import com.varcore.engine.render.Renderer;
import java.awt.AlphaComposite;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Composite;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.util.List;

/** Applies {@link VarObjectEffectEvaluator} output through the engine {@link Renderer}. */
public final class VarObjectEffectDraw {
    private static final int[][] OFFSET_DIRS = {
            {-1, 0}, {1, 0}, {0, -1}, {0, 1},
            {-1, -1}, {1, -1}, {-1, 1}, {1, 1}
    };

    private VarObjectEffectDraw() {
    }

    public record SpriteRegion(int sx, int sy, int sw, int sh) {
        public static SpriteRegion full(BufferedImage image) {
            return new SpriteRegion(0, 0, image.getWidth(), image.getHeight());
        }
    }

    public static VarObjectEffectEvaluator.Sample sample(List<VarObjectEffect> effects, double timeSeconds) {
        return VarObjectEffectEvaluator.evaluate(effects, timeSeconds);
    }

    public static boolean isSpriteLayer(VarObjectNodeType type) {
        return type == VarObjectNodeType.IMAGE || type == VarObjectNodeType.APACK;
    }

    public static void applyPrePasses(Graphics2D g, float x, float y, float w, float h,
                                      List<VarObjectEffectEvaluator.DrawPass> passes) {
        for (VarObjectEffectEvaluator.DrawPass pass : passes) {
            if (pass.kind() == VarObjectEffectEvaluator.PassKind.GLOW) {
                g.setColor(pass.color());
                g.fillRect((int) (x - pass.expand()), (int) (y - pass.expand()),
                        (int) (w + pass.expand() * 2f), (int) (h + pass.expand() * 2f));
            }
        }
    }

    public static void applyPostPasses(Graphics2D g, float x, float y, float w, float h,
                                       List<VarObjectEffectEvaluator.DrawPass> passes,
                                       VarObjectNodeType layerType) {
        for (VarObjectEffectEvaluator.DrawPass pass : passes) {
            switch (pass.kind()) {
                case OUTLINE -> drawShapeOutline(g, x, y, w, h, pass,
                        VarObjectOutlineMode.resolve(pass.outlineMode(), layerType));
                case OVERLAY -> {
                    g.setColor(pass.color());
                    g.fillRect((int) x, (int) y, (int) w, (int) h);
                }
                case GLOW -> { /* pre-pass */ }
            }
        }
    }

    public static void drawSpriteWithEffects(Graphics2D g, BufferedImage image, SpriteRegion region,
                                             float x, float y, float w, float h,
                                             float alpha, VarObjectNodeType layerType,
                                             VarObjectEffectEvaluator.Sample sample) {
        if (image == null || image.getWidth() <= 0 || image.getHeight() <= 0) {
            return;
        }
        drawSpriteEffects(g, image, region, x, y, w, h, alpha, layerType, sample);
    }

    public static void applyPrePasses(Renderer renderer, float x, float y, float w, float h,
                                      List<VarObjectEffectEvaluator.DrawPass> passes, int baseLayer) {
        for (VarObjectEffectEvaluator.DrawPass pass : passes) {
            if (pass.kind() == VarObjectEffectEvaluator.PassKind.GLOW) {
                renderer.drawRect(x - pass.expand(), y - pass.expand(), w + pass.expand() * 2f, h + pass.expand() * 2f,
                        pass.color(), true, baseLayer - 1);
            }
        }
    }

    public static void applyPostPasses(Renderer renderer, float x, float y, float w, float h,
                                       List<VarObjectEffectEvaluator.DrawPass> passes, int baseLayer,
                                       VarObjectNodeType layerType) {
        for (VarObjectEffectEvaluator.DrawPass pass : passes) {
            switch (pass.kind()) {
                case OUTLINE -> drawShapeOutline(renderer, x, y, w, h, pass, layerType, baseLayer + 1);
                case OVERLAY -> renderer.drawRect(x, y, w, h, pass.color(), true, baseLayer + 2);
                case GLOW -> { /* pre-pass */ }
            }
        }
    }

    public static void drawSpriteWithEffects(Renderer renderer, BufferedImage image, SpriteRegion region,
                                             float x, float y, float w, float h,
                                             float alpha, VarObjectNodeType layerType,
                                             VarObjectEffectEvaluator.Sample sample, int layer) {
        if (image == null || image.getWidth() <= 0 || image.getHeight() <= 0) {
            return;
        }
        float margin = effectMargin(sample.passes());
        renderer.drawLayered(layer, x - margin, y - margin, w + margin * 2f, h + margin * 2f,
                g -> drawSpriteEffects(g, image, region, x, y, w, h, alpha, layerType, sample));
    }

    public static void drawSpriteEffects(Graphics2D g, BufferedImage image, SpriteRegion region,
                                         float x, float y, float w, float h,
                                         float alpha, VarObjectNodeType layerType,
                                         VarObjectEffectEvaluator.Sample sample) {
        Composite saved = g.getComposite();
        int iw = Math.max(1, Math.round(w));
        int ih = Math.max(1, Math.round(h));

        for (VarObjectEffectEvaluator.DrawPass pass : sample.passes()) {
            if (pass.kind() == VarObjectEffectEvaluator.PassKind.GLOW) {
                drawAlphaGlow(g, image, region, x, y, w, h, iw, ih, pass);
            }
        }
        for (VarObjectEffectEvaluator.DrawPass pass : sample.passes()) {
            if (pass.kind() == VarObjectEffectEvaluator.PassKind.OUTLINE) {
                drawOutlinePass(g, image, region, x, y, w, h, iw, ih, pass, layerType);
            }
        }

        g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, Math.max(0f, Math.min(1f, alpha))));
        drawImageRegion(g, image, region, x, y, w, h);
        g.setComposite(AlphaComposite.SrcOver);

        for (VarObjectEffectEvaluator.DrawPass pass : sample.passes()) {
            if (pass.kind() == VarObjectEffectEvaluator.PassKind.OVERLAY) {
                drawOverlayOnSprite(g, image, region, x, y, w, h, iw, ih, pass);
            }
        }
        g.setComposite(saved);
    }

    private static void drawOverlayOnSprite(Graphics2D g, BufferedImage image, SpriteRegion region,
                                            float x, float y, float w, float h, int iw, int ih,
                                            VarObjectEffectEvaluator.DrawPass pass) {
        int overlayAlpha = pass.color().getAlpha();
        if (overlayAlpha <= 2) {
            return;
        }
        Color tint = new Color(pass.color().getRed(), pass.color().getGreen(), pass.color().getBlue(), 255);
        BufferedImage silhouette = VarObjectAlphaMask.createSilhouette(image, region, iw, ih, tint);
        g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, overlayAlpha / 255f));
        g.drawImage(silhouette, (int) x, (int) y, (int) (x + w), (int) (y + h), 0, 0, iw, ih, null);
        g.setComposite(AlphaComposite.SrcOver);
    }

    private static void drawOutlinePass(Graphics2D g, BufferedImage image, SpriteRegion region,
                                        float x, float y, float w, float h, int iw, int ih,
                                        VarObjectEffectEvaluator.DrawPass pass, VarObjectNodeType layerType) {
        VarObjectOutlineMode mode = VarObjectOutlineMode.resolve(pass.outlineMode(), layerType);
        if (mode == VarObjectOutlineMode.ALPHA) {
            drawAlphaOutline(g, image, region, x, y, w, h, iw, ih, pass);
        } else {
            drawShapeOutline(g, x, y, w, h, pass, mode);
        }
    }

    private static void drawShapeOutline(Graphics2D g, float x, float y, float w, float h,
                                         VarObjectEffectEvaluator.DrawPass pass, VarObjectOutlineMode mode) {
        float[] box = shapeBox(x, y, w, h, pass.shapeWidth(), pass.shapeHeight());
        float stroke = Math.max(1f, pass.strokeWidth());
        g.setColor(pass.color());
        g.setStroke(new BasicStroke(stroke));
        if (mode == VarObjectOutlineMode.SHAPE_ELLIPSE) {
            g.drawOval(Math.round(box[0] - stroke), Math.round(box[1] - stroke),
                    Math.round(box[2] + stroke * 2), Math.round(box[3] + stroke * 2));
        } else {
            g.drawRect(Math.round(box[0] - stroke), Math.round(box[1] - stroke),
                    Math.round(box[2] + stroke * 2), Math.round(box[3] + stroke * 2));
        }
    }

    private static void drawShapeOutline(Renderer renderer, float x, float y, float w, float h,
                                         VarObjectEffectEvaluator.DrawPass pass, VarObjectNodeType layerType, int layer) {
        VarObjectOutlineMode mode = VarObjectOutlineMode.resolve(pass.outlineMode(), layerType);
        if (mode == VarObjectOutlineMode.ALPHA) {
            mode = VarObjectOutlineMode.SHAPE_RECT;
        }
        float[] box = shapeBox(x, y, w, h, pass.shapeWidth(), pass.shapeHeight());
        float stroke = Math.max(1f, pass.strokeWidth());
        if (mode == VarObjectOutlineMode.SHAPE_ELLIPSE) {
            float cx = box[0] + box[2] / 2f;
            float cy = box[1] + box[3] / 2f;
            renderer.drawCircle(cx, cy, Math.min(box[2], box[3]) / 2f + stroke, pass.color(), false, layer);
        } else {
            renderer.drawRect(box[0] - stroke, box[1] - stroke, box[2] + stroke * 2, box[3] + stroke * 2,
                    pass.color(), false, layer);
        }
    }

    public static float[] shapeBox(float x, float y, float w, float h, float shapeWidth, float shapeHeight) {
        float sw = w * Math.max(0.05f, Math.min(1f, shapeWidth));
        float sh = h * Math.max(0.05f, Math.min(1f, shapeHeight));
        float ox = x + (w - sw) / 2f;
        float oy = y + (h - sh) / 2f;
        return new float[]{ox, oy, sw, sh};
    }

    private static void drawAlphaGlow(Graphics2D g, BufferedImage image, SpriteRegion region,
                                      float x, float y, float w, float h, int iw, int ih,
                                      VarObjectEffectEvaluator.DrawPass pass) {
        float expand = Math.max(1f, pass.expand());
        Color color = new Color(pass.color().getRed(), pass.color().getGreen(), pass.color().getBlue(), 255);
        float baseAlpha = pass.color().getAlpha() / 255f;
        BufferedImage silhouette = VarObjectAlphaMask.createSilhouette(image, region, iw, ih, color);
        int rings = Math.max(2, (int) (expand / 2f));
        for (int ring = rings; ring >= 1; ring--) {
            float dist = expand * ring / rings;
            float ringAlpha = baseAlpha * (1f - (float) ring / (rings + 1f)) * 0.35f;
            g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, Math.min(1f, ringAlpha)));
            for (int[] dir : OFFSET_DIRS) {
                float ox = dir[0] * dist;
                float oy = dir[1] * dist;
                g.drawImage(silhouette, (int) (x + ox), (int) (y + oy), (int) (x + ox + w), (int) (y + oy + h),
                        0, 0, iw, ih, null);
            }
        }
        g.setComposite(AlphaComposite.SrcOver);
    }

    private static void drawAlphaOutline(Graphics2D g, BufferedImage image, SpriteRegion region,
                                         float x, float y, float w, float h, int iw, int ih,
                                         VarObjectEffectEvaluator.DrawPass pass) {
        int thickness = Math.max(1, Math.round(pass.strokeWidth()));
        Color color = new Color(pass.color().getRed(), pass.color().getGreen(), pass.color().getBlue(), 255);
        BufferedImage silhouette = VarObjectAlphaMask.createSilhouette(image, region, iw, ih, color);
        for (int step = 1; step <= thickness; step++) {
            for (int[] dir : OFFSET_DIRS) {
                float ox = dir[0] * step;
                float oy = dir[1] * step;
                g.drawImage(silhouette, (int) (x + ox), (int) (y + oy), (int) (x + ox + w), (int) (y + oy + h),
                        0, 0, iw, ih, null);
            }
        }
    }

    private static void drawImageRegion(Graphics2D g, BufferedImage image, SpriteRegion region,
                                        float x, float y, float w, float h) {
        g.drawImage(image,
                (int) x, (int) y, (int) (x + w), (int) (y + h),
                region.sx(), region.sy(), region.sx() + region.sw(), region.sy() + region.sh(),
                null);
    }

    private static float effectMargin(List<VarObjectEffectEvaluator.DrawPass> passes) {
        float expand = 0f;
        float outline = 0f;
        for (VarObjectEffectEvaluator.DrawPass pass : passes) {
            if (pass.kind() == VarObjectEffectEvaluator.PassKind.GLOW) {
                expand = Math.max(expand, pass.expand());
            } else if (pass.kind() == VarObjectEffectEvaluator.PassKind.OUTLINE) {
                outline = Math.max(outline, pass.strokeWidth());
            }
        }
        return expand + outline + 4f;
    }
}
