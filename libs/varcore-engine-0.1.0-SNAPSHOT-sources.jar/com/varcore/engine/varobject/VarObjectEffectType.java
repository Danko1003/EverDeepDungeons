package com.varcore.engine.varobject;

/** Visual post-process style applied to a single VarObject layer. */
public enum VarObjectEffectType {
    TINT("Color tint overlay"),
    FLASH("Pulsing hit-flash"),
    OUTLINE("Stroked border"),
    GLOW("Soft outer halo"),
    PULSE("Opacity pulse"),
    SHIMMER("Hue-shifting shimmer"),
    FADE("Slow opacity breathe");

    private final String label;

    VarObjectEffectType(String label) {
        this.label = label;
    }

    public String label() {
        return label;
    }

    public static VarObjectEffectType fromString(String value) {
        if (value == null || value.isBlank()) {
            return TINT;
        }
        try {
            return valueOf(value.trim().toUpperCase());
        } catch (IllegalArgumentException ex) {
            return TINT;
        }
    }
}
