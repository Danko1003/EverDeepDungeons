package com.varcore.engine.varobject;

import com.varcore.engine.assets.AssetManager;
import com.varcore.engine.collision.CollisionLayers;
import com.varcore.engine.component.Collider;
import com.varcore.engine.entity.GameObject;

public final class VarObjectSpawner {
    private VarObjectSpawner() {
    }

    public static GameObject spawn(VarObjectDefinition definition, AssetManager assets) {
        return spawn(definition, assets, definition.name());
    }

    public static GameObject spawn(VarObjectDefinition definition, AssetManager assets, String objectName) {
        GameObject object = new GameObject(objectName);
        VarObjectRenderer renderer = object.addComponent(new VarObjectRenderer());
        renderer.setDefinition(definition);
        renderer.setAssets(assets);
        object.addComponent(new VarObjectEffectPlayer());

        VarObjectCollision collision = definition.collision();
        if (collision.enabled()) {
            Collider collider = object.addComponent(new Collider());
            collider.setSize(collision.width(), collision.height());
            collider.setOffset(collision.x(), collision.y());
            collider.setSolid(collision.solid());
            collider.setTrigger(collision.trigger());
            collider.setLayer(collision.layer());
            collider.setMask(collision.mask() == 0 ? CollisionLayers.ALL : collision.mask());
        }
        return object;
    }
}
