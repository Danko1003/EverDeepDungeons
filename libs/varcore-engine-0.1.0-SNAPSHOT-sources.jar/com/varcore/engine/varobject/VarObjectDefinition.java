package com.varcore.engine.varobject;

/** Full VarObject document — metadata, collision, and hierarchical visuals. */
public final class VarObjectDefinition {
    private String id = "new_object";
    private String name = "New Object";
    private float defaultOpacity = 1f;
    private final VarObjectCollision collision = new VarObjectCollision();
    private VarObjectNode root = VarObjectNode.createRoot();

    public static VarObjectDefinition createNew() {
        VarObjectDefinition def = new VarObjectDefinition();
        def.root = VarObjectNode.createRoot();
        return def;
    }

    public String id() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null || id.isBlank() ? "new_object" : id;
    }

    public String name() {
        return name;
    }

    public void setName(String name) {
        this.name = name == null || name.isBlank() ? "New Object" : name;
    }

    public float defaultOpacity() {
        return defaultOpacity;
    }

    public void setDefaultOpacity(float defaultOpacity) {
        this.defaultOpacity = Math.max(0f, Math.min(1f, defaultOpacity));
    }

    public VarObjectCollision collision() {
        return collision;
    }

    public VarObjectNode root() {
        return root;
    }

    public void setRoot(VarObjectNode root) {
        this.root = root == null ? VarObjectNode.createRoot() : root;
    }

    public VarObjectDefinition deepCopy() {
        VarObjectDefinition copy = new VarObjectDefinition();
        copy.id = id;
        copy.name = name;
        copy.defaultOpacity = defaultOpacity;
        copy.collision.setEnabled(collision.enabled());
        copy.collision.setX(collision.x());
        copy.collision.setY(collision.y());
        copy.collision.setWidth(collision.width());
        copy.collision.setHeight(collision.height());
        copy.collision.setSolid(collision.solid());
        copy.collision.setTrigger(collision.trigger());
        copy.collision.setLayer(collision.layer());
        copy.collision.setMask(collision.mask());
        copy.root = root.deepCopy();
        return copy;
    }
}
