package com.varcore.engine.varobject;

/** Normalized anchor presets within a layer's width and height (0 = left/top, 1 = right/bottom). */
public enum VarObjectAnchor {
    TOP_LEFT(0f, 0f),
    TOP_CENTER(0.5f, 0f),
    TOP_RIGHT(1f, 0f),
    CENTER(0.5f, 0.5f),
    BOTTOM_LEFT(0f, 1f),
    BOTTOM_CENTER(0.5f, 1f),
    BOTTOM_RIGHT(1f, 1f);

    private final float u;
    private final float v;

    VarObjectAnchor(float u, float v) {
        this.u = u;
        this.v = v;
    }

    public float u() {
        return u;
    }

    public float v() {
        return v;
    }

    public static VarObjectAnchor nearest(float anchorX, float anchorY) {
        VarObjectAnchor best = CENTER;
        float bestDist = Float.MAX_VALUE;
        for (VarObjectAnchor anchor : values()) {
            float du = anchor.u - anchorX;
            float dv = anchor.v - anchorY;
            float dist = du * du + dv * dv;
            if (dist < bestDist) {
                bestDist = dist;
                best = anchor;
            }
        }
        return best;
    }
}
