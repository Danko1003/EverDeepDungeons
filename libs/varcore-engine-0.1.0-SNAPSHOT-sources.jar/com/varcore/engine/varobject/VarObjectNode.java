package com.varcore.engine.varobject;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

/** Hierarchical visual node — groups behave like folders; children move with parents. */
public final class VarObjectNode {
    private String id;
    private String name;
    private VarObjectNodeType type = VarObjectNodeType.GROUP;
    private float x;
    private float y;
    private float width = 32f;
    private float height = 32f;
    private float opacity = 1f;
    private String color = "#3DDC84";
    private String imagePath = "";
    private String apackPath = "";
    private boolean lockAspectRatio;
    private float intrinsicWidth;
    private float intrinsicHeight;
    private float rotation;
    private float anchorX = VarObjectTransform.DEFAULT_ANCHOR;
    private float anchorY = VarObjectTransform.DEFAULT_ANCHOR;
    private final List<VarObjectEffect> effects = new ArrayList<>();
    private final List<VarObjectNode> children = new ArrayList<>();
    private VarObjectNode parent;

    public static VarObjectNode createRoot() {
        VarObjectNode root = new VarObjectNode("root", "Root", VarObjectNodeType.GROUP);
        root.setWidth(64);
        root.setHeight(64);
        return root;
    }

    public static VarObjectNode create(String name, VarObjectNodeType type) {
        String id = type.name().toLowerCase() + "_" + UUID.randomUUID().toString().substring(0, 8);
        return new VarObjectNode(id, name, type);
    }

    public VarObjectNode(String id, String name, VarObjectNodeType type) {
        this.id = id;
        this.name = name;
        this.type = type;
    }

    public String id() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String name() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public VarObjectNodeType type() {
        return type;
    }

    public void setType(VarObjectNodeType type) {
        this.type = type;
    }

    public float x() {
        return x;
    }

    public void setX(float x) {
        this.x = x;
    }

    public float y() {
        return y;
    }

    public void setY(float y) {
        this.y = y;
    }

    public float width() {
        return width;
    }

    public void setWidth(float width) {
        this.width = Math.max(1f, width);
    }

    public float height() {
        return height;
    }

    public void setHeight(float height) {
        this.height = Math.max(1f, height);
    }

    public float opacity() {
        return opacity;
    }

    public void setOpacity(float opacity) {
        this.opacity = Math.max(0f, Math.min(1f, opacity));
    }

    public String color() {
        return color;
    }

    public void setColor(String color) {
        this.color = color == null ? "#FFFFFF" : color;
    }

    public String imagePath() {
        return imagePath;
    }

    public void setImagePath(String imagePath) {
        this.imagePath = imagePath == null ? "" : imagePath;
    }

    public String apackPath() {
        return apackPath;
    }

    public void setApackPath(String apackPath) {
        this.apackPath = apackPath == null ? "" : apackPath;
    }

    public boolean lockAspectRatio() {
        return lockAspectRatio;
    }

    public void setLockAspectRatio(boolean lockAspectRatio) {
        this.lockAspectRatio = lockAspectRatio;
    }

    public float intrinsicWidth() {
        return intrinsicWidth;
    }

    public float intrinsicHeight() {
        return intrinsicHeight;
    }

    public void setIntrinsicSize(float width, float height) {
        this.intrinsicWidth = Math.max(0f, width);
        this.intrinsicHeight = Math.max(0f, height);
    }

    public float rotation() {
        return rotation;
    }

    public void setRotation(float rotation) {
        this.rotation = rotation;
    }

    public float anchorX() {
        return anchorX;
    }

    public float anchorY() {
        return anchorY;
    }

    public void setAnchor(float anchorX, float anchorY) {
        this.anchorX = clampAnchor(anchorX);
        this.anchorY = clampAnchor(anchorY);
    }

    public void setAnchor(VarObjectAnchor anchor) {
        if (anchor != null) {
            setAnchor(anchor.u(), anchor.v());
        }
    }

    public void centerAnchor() {
        setAnchor(VarObjectAnchor.CENTER);
    }

    private static float clampAnchor(float value) {
        return Math.max(0f, Math.min(1f, value));
    }

    /** Width divided by height for aspect-locked resizing. */
    public float aspectRatio() {
        if (intrinsicWidth > 0f && intrinsicHeight > 0f) {
            return intrinsicWidth / intrinsicHeight;
        }
        return width / Math.max(1f, height);
    }

    public List<VarObjectEffect> effects() {
        return effects;
    }

    public void addEffect(VarObjectEffect effect) {
        if (effect != null) {
            effects.add(effect);
        }
    }

    public boolean removeEffect(VarObjectEffect effect) {
        return effects.remove(effect);
    }

    public List<VarObjectNode> children() {
        return children;
    }

    public Optional<VarObjectNode> parent() {
        return Optional.ofNullable(parent);
    }

    public void addChild(VarObjectNode child) {
        if (child == this) {
            return;
        }
        detach(child);
        children.add(child);
        child.parent = this;
    }

    public void insertChild(int index, VarObjectNode child) {
        if (child == this) {
            return;
        }
        detach(child);
        int clamped = Math.max(0, Math.min(index, children.size()));
        children.add(clamped, child);
        child.parent = this;
    }

    public boolean removeChild(VarObjectNode child) {
        if (children.remove(child)) {
            child.parent = null;
            return true;
        }
        return false;
    }

    public void clearChildren() {
        for (VarObjectNode child : children) {
            child.parent = null;
        }
        children.clear();
    }

    public Optional<VarObjectNode> findById(String nodeId) {
        if (id.equals(nodeId)) {
            return Optional.of(this);
        }
        for (VarObjectNode child : children) {
            Optional<VarObjectNode> found = child.findById(nodeId);
            if (found.isPresent()) {
                return found;
            }
        }
        return Optional.empty();
    }

    public VarObjectNode deepCopy() {
        VarObjectNode copy = new VarObjectNode(id, name, type);
        copy.x = x;
        copy.y = y;
        copy.width = width;
        copy.height = height;
        copy.opacity = opacity;
        copy.color = color;
        copy.imagePath = imagePath;
        copy.apackPath = apackPath;
        copy.lockAspectRatio = lockAspectRatio;
        copy.intrinsicWidth = intrinsicWidth;
        copy.intrinsicHeight = intrinsicHeight;
        copy.rotation = rotation;
        copy.anchorX = anchorX;
        copy.anchorY = anchorY;
        for (VarObjectEffect effect : effects) {
            copy.effects.add(effect.copy());
        }
        for (VarObjectNode child : children) {
            copy.addChild(child.deepCopy());
        }
        return copy;
    }

    public VarObjectNode duplicateSubtree() {
        VarObjectNode copy = deepCopy();
        copy.id = type.name().toLowerCase() + "_" + UUID.randomUUID().toString().substring(0, 8);
        copy.name = name + " Copy";
        reassignIds(copy);
        return copy;
    }

    private static void reassignIds(VarObjectNode node) {
        node.id = node.type().name().toLowerCase() + "_" + UUID.randomUUID().toString().substring(0, 8);
        for (VarObjectNode child : node.children()) {
            reassignIds(child);
        }
    }

    private static void detach(VarObjectNode child) {
        if (child.parent != null) {
            child.parent.children.remove(child);
            child.parent = null;
        }
    }

    public float worldX() {
        float wx = x;
        VarObjectNode p = parent;
        while (p != null && p.parent != null) {
            wx += p.x;
            p = p.parent;
        }
        return wx;
    }

    public float worldY() {
        float wy = y;
        VarObjectNode p = parent;
        while (p != null && p.parent != null) {
            wy += p.y;
            p = p.parent;
        }
        return wy;
    }
}
