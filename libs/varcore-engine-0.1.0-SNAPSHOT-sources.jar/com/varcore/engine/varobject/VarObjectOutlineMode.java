package com.varcore.engine.varobject;

/** How {@link VarObjectEffectType#OUTLINE} follows layer geometry. */
public enum VarObjectOutlineMode {
    AUTO("Auto"),
    ALPHA("Sprite alpha"),
    SHAPE_RECT("Rectangle"),
    SHAPE_ELLIPSE("Ellipse");

    private final String label;

    VarObjectOutlineMode(String label) {
        this.label = label;
    }

    public String label() {
        return label;
    }

    public static VarObjectOutlineMode fromString(String value) {
        if (value == null || value.isBlank()) {
            return AUTO;
        }
        try {
            return valueOf(value.trim().toUpperCase());
        } catch (IllegalArgumentException ex) {
            return AUTO;
        }
    }

    public static VarObjectOutlineMode resolve(VarObjectOutlineMode mode, VarObjectNodeType layerType) {
        if (mode != AUTO) {
            return mode;
        }
        if (layerType == VarObjectNodeType.IMAGE || layerType == VarObjectNodeType.APACK) {
            return ALPHA;
        }
        if (layerType == VarObjectNodeType.ELLIPSE) {
            return SHAPE_ELLIPSE;
        }
        return SHAPE_RECT;
    }
}
