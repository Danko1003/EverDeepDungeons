package com.varcore.engine.varobject;

import com.varcore.engine.component.Component;
import com.varcore.engine.render.Renderer;
import java.awt.Color;

/**
 * Runtime one-shot effects for spawned VarObjects — damage flash, screen shake on the sprite, etc.
 * Pair with {@link VarObjectRenderer} on the same {@link com.varcore.engine.entity.GameObject}.
 */
public final class VarObjectEffectPlayer extends Component {
    private float flashRemaining;
    private float flashDuration;
    private Color flashColor = Color.WHITE;

    private float shakeRemaining;
    private float shakeDuration;
    private float shakeMagnitude;
    private float shakePhase;
    private float offsetX;
    private float offsetY;

    public void flash(Color color, float durationSeconds) {
        flashColor = color == null ? Color.WHITE : color;
        flashDuration = Math.max(0.05f, durationSeconds);
        flashRemaining = flashDuration;
    }

    public void flash(float durationSeconds) {
        flash(Color.WHITE, durationSeconds);
    }

    public void shake(float magnitudePixels, float durationSeconds) {
        shakeMagnitude = Math.max(0f, magnitudePixels);
        shakeDuration = Math.max(0.05f, durationSeconds);
        shakeRemaining = shakeDuration;
        shakePhase = 0f;
    }

    public float renderOffsetX() {
        return offsetX;
    }

    public float renderOffsetY() {
        return offsetY;
    }

    public float flashAlpha() {
        if (flashRemaining <= 0f || flashDuration <= 0f) {
            return 0f;
        }
        float t = flashRemaining / flashDuration;
        return Math.min(1f, t * 1.4f);
    }

    public Color flashColor() {
        return flashColor;
    }

    @Override
    public void update(float dt) {
        if (flashRemaining > 0f) {
            flashRemaining = Math.max(0f, flashRemaining - dt);
        }
        if (shakeRemaining > 0f) {
            shakeRemaining = Math.max(0f, shakeRemaining - dt);
            shakePhase += dt * 42f;
            float falloff = shakeRemaining / shakeDuration;
            offsetX = (float) (Math.sin(shakePhase * 1.7) * shakeMagnitude * falloff);
            offsetY = (float) (Math.cos(shakePhase * 2.3) * shakeMagnitude * falloff);
        } else {
            offsetX = 0f;
            offsetY = 0f;
        }
    }

    /** Optional full-object flash drawn on top of the VarObject tree. */
    public void renderOverlay(Renderer renderer, float x, float y, float width, float height, int layer) {
        float alpha = flashAlpha();
        if (alpha <= 0f) {
            return;
        }
        Color overlay = VarObjectEffectEvaluator.withAlpha(flashColor, alpha * 0.75f);
        renderer.drawRect(x, y, width, height, overlay, true, layer + 64);
    }
}
