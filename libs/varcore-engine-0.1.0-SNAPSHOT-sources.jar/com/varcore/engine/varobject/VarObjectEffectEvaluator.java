package com.varcore.engine.varobject;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

/** Evaluates layered visual effects at a point in time (Java2D-friendly output). */
public final class VarObjectEffectEvaluator {
    public enum PassKind {
        GLOW,
        OUTLINE,
        OVERLAY
    }

    public record DrawPass(
            PassKind kind,
            Color color,
            float expand,
            float strokeWidth,
            VarObjectOutlineMode outlineMode,
            float shapeWidth,
            float shapeHeight) {

        public DrawPass(PassKind kind, Color color, float expand, float strokeWidth) {
            this(kind, color, expand, strokeWidth, VarObjectOutlineMode.AUTO, 1f, 1f);
        }
    }

    public record Sample(float opacityMultiplier, List<DrawPass> passes) {
        public static Sample identity() {
            return new Sample(1f, List.of());
        }
    }

    private VarObjectEffectEvaluator() {
    }

    public static Sample evaluate(List<VarObjectEffect> effects, double timeSeconds) {
        if (effects == null || effects.isEmpty()) {
            return Sample.identity();
        }
        float opacityMul = 1f;
        List<DrawPass> passes = new ArrayList<>();
        for (VarObjectEffect effect : effects) {
            if (!effect.enabled()) {
                continue;
            }
            double phase = timeSeconds * effect.speed() * Math.PI * 2.0;
            switch (effect.type()) {
                case PULSE -> opacityMul *= 0.5f + 0.5f * (float) (0.5 + 0.5 * Math.sin(phase));
                case FADE -> opacityMul *= 0.35f + 0.65f * (float) (0.5 + 0.5 * Math.sin(phase * 0.5));
                case GLOW -> {
                    float pulse = (float) (0.5 + 0.5 * Math.sin(phase));
                    float expand = 3f + 7f * pulse;
                    Color glow = withAlpha(parseColor(effect.color()), effect.intensity() * 0.4f * pulse);
                    passes.add(new DrawPass(PassKind.GLOW, glow, expand, 0f));
                }
                case OUTLINE -> passes.add(new DrawPass(
                        PassKind.OUTLINE,
                        withAlpha(parseColor(effect.color()), effect.intensity()),
                        0f,
                        effect.width(),
                        effect.outlineMode(),
                        effect.outlineShapeWidth(),
                        effect.outlineShapeHeight()));
                case TINT -> passes.add(new DrawPass(
                        PassKind.OVERLAY,
                        withAlpha(parseColor(effect.color()), effect.intensity() * 0.55f),
                        0f,
                        0f));
                case FLASH -> {
                    float spike = (float) Math.pow(Math.max(0, Math.sin(phase)), 6.0);
                    passes.add(new DrawPass(
                            PassKind.OVERLAY,
                            withAlpha(parseColor(effect.color()), effect.intensity() * spike),
                            0f,
                            0f));
                }
                case SHIMMER -> {
                    float hueShift = (float) ((Math.sin(phase) + 1.0) * 0.5);
                    Color base = parseColor(effect.color());
                    Color shifted = shiftHue(base, hueShift * 0.35f);
                    passes.add(new DrawPass(
                            PassKind.OVERLAY,
                            withAlpha(shifted, effect.intensity() * 0.45f),
                            0f,
                            0f));
                }
            }
        }
        opacityMul = Math.max(0.05f, Math.min(1f, opacityMul));
        return new Sample(opacityMul, List.copyOf(passes));
    }

    public static Color parseColor(String hex) {
        if (hex == null || hex.isBlank()) {
            return Color.WHITE;
        }
        String value = hex.startsWith("#") ? hex.substring(1) : hex;
        try {
            if (value.length() == 6) {
                int rgb = Integer.parseInt(value, 16);
                return new Color((rgb >> 16) & 0xFF, (rgb >> 8) & 0xFF, rgb & 0xFF);
            }
        } catch (NumberFormatException ignored) {
        }
        return Color.WHITE;
    }

    public static Color withAlpha(Color color, float alpha) {
        int a = Math.max(0, Math.min(255, (int) (alpha * 255)));
        return new Color(color.getRed(), color.getGreen(), color.getBlue(), a);
    }

    private static Color shiftHue(Color color, float amount) {
        float[] hsb = Color.RGBtoHSB(color.getRed(), color.getGreen(), color.getBlue(), null);
        hsb[0] = (hsb[0] + amount) % 1f;
        int rgb = Color.HSBtoRGB(hsb[0], hsb[1], hsb[2]);
        return new Color(rgb);
    }
}
