package com.varcore.engine.varobject;

/** Visual node kind inside a {@link VarObjectDefinition}. */
public enum VarObjectNodeType {
    GROUP,
    IMAGE,
    APACK,
    RECT,
    ELLIPSE;

    public static VarObjectNodeType fromString(String value) {
        if (value == null || value.isBlank()) {
            return GROUP;
        }
        try {
            return VarObjectNodeType.valueOf(value.toUpperCase());
        } catch (IllegalArgumentException ex) {
            return GROUP;
        }
    }
}
