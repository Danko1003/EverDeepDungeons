package com.varcore.engine.varobject;

import com.varcore.engine.apack.APack;
import com.varcore.engine.apack.APackFrame;
import com.varcore.engine.assets.AssetManager;
import com.varcore.engine.component.Component;
import com.varcore.engine.render.Renderer;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;

/** Renders a {@link VarObjectDefinition} tree relative to the host GameObject. */
public final class VarObjectRenderer extends Component {
    private VarObjectDefinition definition;
    private AssetManager assets;
    private int layer;
    private double effectTime;

    public void setDefinition(VarObjectDefinition definition) {
        this.definition = definition;
    }

    public VarObjectDefinition getDefinition() {
        return definition;
    }

    public void setAssets(AssetManager assets) {
        this.assets = assets;
    }

    public void setLayer(int layer) {
        this.layer = layer;
    }

    @Override
    public void update(float dt) {
        effectTime += dt;
    }

    @Override
    public void render(Renderer renderer) {
        if (definition == null || getGameObject() == null) {
            return;
        }
        float offsetX = 0f;
        float offsetY = 0f;
        VarObjectEffectPlayer player = getGameObject().getComponent(VarObjectEffectPlayer.class);
        if (player != null) {
            offsetX = player.renderOffsetX();
            offsetY = player.renderOffsetY();
        }
        var pos = getGameObject().getTransform().getPosition();
        float originX = pos.x + offsetX;
        float originY = pos.y + offsetY;
        float[] bounds = VarObjectTransform.boundsOfTree(definition.root(), originX, originY);
        renderer.drawLayered(layer, bounds[0], bounds[1], bounds[2], bounds[3],
                g -> {
                    g.translate(originX, originY);
                    renderNode(g, definition.root(), definition.defaultOpacity(), layer);
                });

        if (player != null && definition.collision().enabled()) {
            VarObjectCollision collision = definition.collision();
            player.renderOverlay(renderer, originX + collision.x(), originY + collision.y(),
                    collision.width(), collision.height(), layer);
        } else if (player != null && player.flashAlpha() > 0f) {
            player.renderOverlay(renderer, bounds[0], bounds[1], bounds[2], bounds[3], layer);
        }
    }

    private void renderNode(Graphics2D g, VarObjectNode node, float parentAlpha, int baseLayer) {
        AffineTransform saved = g.getTransform();
        g.translate(node.x(), node.y());
        VarObjectTransform.applyLocalRotation(g, node);

        VarObjectEffectEvaluator.Sample sample = VarObjectEffectDraw.sample(node.effects(), effectTime);
        float alpha = parentAlpha * node.opacity() * sample.opacityMultiplier();
        boolean spriteLayer = VarObjectEffectDraw.isSpriteLayer(node.type());
        float w = node.width();
        float h = node.height();

        if (node.type() != VarObjectNodeType.GROUP && !spriteLayer) {
            VarObjectEffectDraw.applyPrePasses(g, 0f, 0f, w, h, sample.passes());
        }

        switch (node.type()) {
            case RECT -> drawRect(g, node, alpha);
            case ELLIPSE -> drawEllipse(g, node, alpha);
            case IMAGE -> drawImage(g, node, alpha, sample);
            case APACK -> drawApack(g, node, alpha, sample);
            case GROUP -> { /* container only */ }
        }

        if (node.type() != VarObjectNodeType.GROUP && !spriteLayer) {
            VarObjectEffectDraw.applyPostPasses(g, 0f, 0f, w, h, sample.passes(), node.type());
        }

        for (VarObjectNode child : node.children()) {
            renderNode(g, child, alpha, baseLayer + 1);
        }
        g.setTransform(saved);
    }

    private void drawRect(Graphics2D g, VarObjectNode node, float alpha) {
        g.setColor(withAlpha(parseColor(node.color()), alpha));
        g.fillRect(0, 0, Math.round(node.width()), Math.round(node.height()));
    }

    private void drawEllipse(Graphics2D g, VarObjectNode node, float alpha) {
        g.setColor(withAlpha(parseColor(node.color()), alpha));
        g.fillOval(0, 0, Math.round(node.width()), Math.round(node.height()));
    }

    private void drawImage(Graphics2D g, VarObjectNode node, float alpha,
                           VarObjectEffectEvaluator.Sample sample) {
        float w = node.width();
        float h = node.height();
        if (assets == null || node.imagePath().isBlank()) {
            g.setColor(withAlpha(Color.LIGHT_GRAY, alpha));
            g.fillRect(0, 0, Math.round(w), Math.round(h));
            return;
        }
        try {
            // getImage does not retain each frame (avoids unbounded refcounts).
            BufferedImage image = assets.getImage(node.imagePath());
            VarObjectEffectDraw.drawSpriteWithEffects(g, image, VarObjectEffectDraw.SpriteRegion.full(image),
                    0f, 0f, w, h, alpha, node.type(), sample);
        } catch (Exception ex) {
            g.setColor(withAlpha(Color.PINK, alpha));
            g.fillRect(0, 0, Math.round(w), Math.round(h));
        }
    }

    private void drawApack(Graphics2D g, VarObjectNode node, float alpha,
                           VarObjectEffectEvaluator.Sample sample) {
        float w = node.width();
        float h = node.height();
        if (assets == null || node.apackPath().isBlank()) {
            g.setColor(withAlpha(new Color(0x5B, 0x8C, 0xFF), alpha));
            g.fillRect(0, 0, Math.round(w), Math.round(h));
            return;
        }
        try {
            APack pack = assets.getAPack(node.apackPath());
            if (pack.getFrames().isEmpty()) {
                return;
            }
            APackFrame frame = pack.getFrames().get(0);
            BufferedImage[] sheets = pack.getSheets();
            if (frame.getSheet() < 0 || frame.getSheet() >= sheets.length) {
                return;
            }
            BufferedImage sheet = sheets[frame.getSheet()];
            VarObjectEffectDraw.drawSpriteWithEffects(g, sheet,
                    new VarObjectEffectDraw.SpriteRegion(frame.getX(), frame.getY(), frame.getWidth(), frame.getHeight()),
                    0f, 0f, w, h, alpha, node.type(), sample);
        } catch (Exception ex) {
            g.setColor(withAlpha(Color.ORANGE, alpha));
            g.fillRect(0, 0, Math.round(w), Math.round(h));
        }
    }

    private static Color withAlpha(Color color, float alpha) {
        int a = Math.max(0, Math.min(255, (int) (alpha * 255)));
        return new Color(color.getRed(), color.getGreen(), color.getBlue(), a);
    }

    private static Color parseColor(String hex) {
        return VarObjectEffectEvaluator.parseColor(hex);
    }
}
