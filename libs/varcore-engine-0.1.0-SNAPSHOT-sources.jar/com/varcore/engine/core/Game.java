package com.varcore.engine.core;

import com.varcore.engine.assets.AssetManager;
import com.varcore.engine.audio.AudioManager;
import com.varcore.engine.camera.Camera;
import com.varcore.engine.collision.CollisionWorld;
import com.varcore.engine.debug.DebugOverlay;
import com.varcore.engine.input.InputManager;
import com.varcore.engine.plugin.PluginHost;
import com.varcore.engine.render.Renderer;
import com.varcore.engine.save.SaveManager;
import com.varcore.engine.scene.Scene;
import com.varcore.engine.scene.SceneManager;
import java.nio.file.Path;

public abstract class Game {
    private final GameWindow window;
    private final InputManager input;
    private final Renderer renderer;
    private final Camera camera;
    private final AssetManager assets;
    private final AudioManager audio;
    private final SceneManager sceneManager;
    private final CollisionWorld collisionWorld;
    private final DebugOverlay debugOverlay;
    private final SaveManager saveManager;
    private final PluginHost pluginHost;
    private Path assetsRoot = Path.of("assets");

    protected Game(String title, int width, int height) {
        window = new GameWindow(title, width, height);
        input = new InputManager(window.getCanvas());
        camera = new Camera(width, height);
        renderer = new Renderer(window, camera);
        assets = new AssetManager(assetsRoot);
        audio = new AudioManager(assets);
        sceneManager = new SceneManager();
        collisionWorld = new CollisionWorld();
        debugOverlay = new DebugOverlay();
        saveManager = new SaveManager();
        pluginHost = new PluginHost();
    }

    public void run() {
        new GameLoop(this).start();
    }

    protected abstract void update(float dt);

    protected void onStart() {
        input.setCamera(camera);
        camera.centerOnWorld();
    }

    protected void centerCamera() {
        camera.centerOnWorld();
    }

    protected void render(Renderer renderer) {
        Scene scene = sceneManager.getActiveScene();
        if (scene != null) {
            scene.renderAll(renderer);
        }
    }

    protected void fixedUpdate(float dt) {
        Scene scene = sceneManager.getActiveScene();
        if (scene != null) {
            scene.updateAll(dt);
            collisionWorld.update(scene, dt);
            debugOverlay.setEntityCount(scene.getGameObjects().size());
        }
    }

    protected void onStop() {
        assets.dispose();
        audio.dispose();
    }

    public GameWindow getWindow() { return window; }
    public InputManager getInput() { return input; }
    public Renderer getRenderer() { return renderer; }
    public Camera getCamera() { return camera; }
    public AssetManager getAssets() { return assets; }
    public AudioManager getAudio() { return audio; }
    public SceneManager getScenes() { return sceneManager; }
    public CollisionWorld getCollision() { return collisionWorld; }
    public DebugOverlay getDebugOverlay() { return debugOverlay; }
    public SaveManager getSaveManager() { return saveManager; }
    public PluginHost getPluginHost() { return pluginHost; }

    public void setAssetsRoot(Path assetsRoot) {
        this.assetsRoot = assetsRoot;
        assets.setRoot(assetsRoot);
    }

    public Path getAssetsRoot() {
        return assetsRoot;
    }
}
