package com.varcore.engine.core;

public final class Time {
    private static float deltaTime;
    private static float totalTime;
    private static float unscaledDeltaTime;

    private Time() {}

    public static float deltaTime() {
        return deltaTime;
    }

    public static float totalTime() {
        return totalTime;
    }

    public static float unscaledDeltaTime() {
        return unscaledDeltaTime;
    }

    static void update(float dt, float unscaledDt) {
        deltaTime = dt;
        unscaledDeltaTime = unscaledDt;
        totalTime += dt;
    }
}
