package com.varcore.engine.core;

import com.varcore.engine.debug.DebugOverlay;
import com.varcore.engine.debug.Profiler;
import com.varcore.engine.input.InputManager;
import com.varcore.engine.net.NetworkManager;
import com.varcore.engine.plugin.PluginHost;
import com.varcore.engine.render.Renderer;
import java.awt.Canvas;
import java.awt.Graphics2D;
import java.awt.image.BufferStrategy;

public final class GameLoop {
    private final Game game;
    private final GameWindow window;
    private final InputManager input;
    private final Renderer renderer;
    private final DebugOverlay debugOverlay;
    private final PluginHost pluginHost;
    private final NetworkManager network;
    private boolean running;
    private int targetFps = 60;
    private float timeScale = 1f;

    public GameLoop(Game game) {
        this.game = game;
        this.window = game.getWindow();
        this.input = game.getInput();
        this.renderer = game.getRenderer();
        this.debugOverlay = game.getDebugOverlay();
        this.pluginHost = game.getPluginHost();
        this.network = game.getNetwork();
    }

    public void start() {
        window.show();
        Canvas canvas = window.getCanvas();
        canvas.createBufferStrategy(3);
        running = true;
        window.setOnCloseRequest(() -> {
            running = false;
            var audio = com.varcore.engine.audio.AudioManager.getInstance();
            if (audio != null) {
                audio.stopAll();
                audio.dispose();
            }
        });
        game.onStart();
        pluginHost.loadPlugins(game);

        long lastTime = System.nanoTime();
        long frameCount = 0;
        long fpsTimer = lastTime;

        while (running && !window.isCloseRequested() && window.getFrame().isVisible()) {
            long now = System.nanoTime();
            float unscaledDt = (now - lastTime) / 1_000_000_000f;
            lastTime = now;
            float dt = unscaledDt * timeScale;
            Time.update(dt, unscaledDt);

            Profiler.begin("input");
            renderer.updatePresentationTransform();
            input.beginFrame();
            Profiler.end("input");

            if (input.isKeyPressed(java.awt.event.KeyEvent.VK_ESCAPE)) {
                running = false;
                var audio = com.varcore.engine.audio.AudioManager.getInstance();
                if (audio != null) {
                    audio.stopAll();
                }
                break;
            }
            if (input.isKeyPressed(java.awt.event.KeyEvent.VK_F3)) {
                debugOverlay.toggle();
            }
            if (input.isKeyPressed(java.awt.event.KeyEvent.VK_F11)) {
                window.setFullscreen(!window.isFullscreen());
            }

            Profiler.begin("network");
            network.update(dt);
            Profiler.end("network");

            Profiler.begin("update");
            game.fixedUpdate(dt);
            game.update(dt);
            Profiler.end("update");

            Profiler.begin("render");
            if (window.consumeDisplayChanged()) {
                canvas.createBufferStrategy(3);
            }
            BufferStrategy strategy = canvas.getBufferStrategy();
            if (strategy == null) {
                canvas.createBufferStrategy(3);
                strategy = canvas.getBufferStrategy();
            }
            if (strategy == null) {
                Profiler.end("render");
                input.endFrame();
                continue;
            }
            do {
                Graphics2D g = (Graphics2D) strategy.getDrawGraphics();
                try {
                    renderer.beginFrame(g);
                    game.render(renderer);
                    debugOverlay.render(renderer, g);
                    renderer.endFrame();
                } finally {
                    g.dispose();
                }
                strategy.show();
            } while (strategy.contentsLost());
            Profiler.end("render");

            frameCount++;
            debugOverlay.recordFrame(unscaledDt);
            if (now - fpsTimer >= 1_000_000_000L) {
                debugOverlay.setFps(frameCount);
                frameCount = 0;
                fpsTimer = now;
            }

            input.endFrame();

            long frameBudgetNs = 1_000_000_000L / targetFps;
            long elapsed = System.nanoTime() - now;
            long sleepNs = frameBudgetNs - elapsed;
            if (sleepNs > 0) {
                try {
                    Thread.sleep(sleepNs / 1_000_000L, (int) (sleepNs % 1_000_000L));
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }
        }

        pluginHost.unloadAll();
        game.onStop();
        window.dispose();
    }

    public void stop() {
        running = false;
    }

    public void setTargetFps(int targetFps) {
        this.targetFps = Math.max(1, targetFps);
    }

    public void setTimeScale(float timeScale) {
        this.timeScale = timeScale;
    }
}
