package com.varcore.engine.core;

import java.awt.Canvas;
import java.awt.Dimension;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.awt.Rectangle;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;

public final class GameWindow {
    private final JFrame frame;
    private final Canvas canvas;
    private boolean fullscreen;
    private Dimension windowedSize;
    private Rectangle windowedBounds;
    private volatile boolean displayChanged;
    private volatile boolean closeRequested;
    private Runnable onCloseRequest;

    public GameWindow(String title, int width, int height) {
        frame = new JFrame(title);
        frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                closeRequested = true;
                if (onCloseRequest != null) {
                    try {
                        onCloseRequest.run();
                    } catch (Exception ignored) {
                    }
                }
                frame.setVisible(false);
            }
        });

        canvas = new Canvas();
        canvas.setPreferredSize(new Dimension(width, height));
        canvas.setIgnoreRepaint(true);
        frame.add(canvas);
        frame.pack();
        frame.setResizable(true);
        frame.setLocationRelativeTo(null);
        windowedSize = canvas.getSize();
        windowedBounds = frame.getBounds();

        canvas.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                displayChanged = true;
                if (!fullscreen) {
                    windowedSize = canvas.getSize();
                    windowedBounds = frame.getBounds();
                }
            }
        });
    }

    public void show() {
        SwingUtilities.invokeLater(() -> frame.setVisible(true));
    }

    public void hide() {
        SwingUtilities.invokeLater(() -> frame.setVisible(false));
    }

    public void dispose() {
        SwingUtilities.invokeLater(() -> {
            GraphicsEnvironment.getLocalGraphicsEnvironment()
                    .getDefaultScreenDevice()
                    .setFullScreenWindow(null);
            frame.dispose();
        });
    }

    public void setOnCloseRequest(Runnable onCloseRequest) {
        this.onCloseRequest = onCloseRequest;
    }

    public boolean isCloseRequested() {
        return closeRequested;
    }

    public Canvas getCanvas() {
        return canvas;
    }

    public JFrame getFrame() {
        return frame;
    }

    public int getWidth() {
        return Math.max(1, canvas.getWidth());
    }

    public int getHeight() {
        return Math.max(1, canvas.getHeight());
    }

    public void setTitle(String title) {
        frame.setTitle(title);
    }

    public void setFullscreen(boolean enabled) {
        if (fullscreen == enabled) {
            return;
        }

        GraphicsDevice device = GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice();

        if (enabled) {
            windowedSize = canvas.getSize();
            windowedBounds = frame.getBounds();
            if (device.isFullScreenSupported()) {
                // setFullScreenWindow removes decorations automatically; setUndecorated
                // cannot be called on an already-displayable frame.
                device.setFullScreenWindow(frame);
            } else {
                frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
                frame.setVisible(true);
            }
            fullscreen = true;
        } else {
            device.setFullScreenWindow(null);
            frame.setExtendedState(JFrame.NORMAL);
            if (windowedBounds != null) {
                frame.setBounds(windowedBounds);
            } else if (windowedSize != null) {
                canvas.setPreferredSize(windowedSize);
                frame.pack();
            }
            frame.setVisible(true);
            fullscreen = false;
        }

        canvas.requestFocusInWindow();
        displayChanged = true;
    }

    public boolean consumeDisplayChanged() {
        if (!displayChanged) {
            return false;
        }
        displayChanged = false;
        return true;
    }

    public boolean isFullscreen() {
        return fullscreen;
    }
}
