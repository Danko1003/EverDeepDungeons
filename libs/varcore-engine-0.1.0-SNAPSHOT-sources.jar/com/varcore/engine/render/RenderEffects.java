package com.varcore.engine.render;

import com.varcore.engine.varobject.VarObjectEffect;
import com.varcore.engine.varobject.VarObjectEffectEvaluator;
import com.varcore.engine.varobject.VarObjectEffectType;
import com.varcore.engine.varobject.VarObjectOutlineMode;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

/**
 * Fluent visual effects for any {@link Renderer} draw call — same stack used by VarObjects
 * (outline, glow, tint, flash, pulse, shimmer, fade).
 *
 * <pre>{@code
 * RenderEffects highlight = RenderEffects.outline(new Color(0xFF, 0xD9, 0x3D), 2f);
 * renderer.drawSprite(tileImage, x, y, 32, 32, 0, highlight);
 *
 * RenderEffects fx = RenderEffects.of()
 *         .outline("#FFD93D", 2f)
 *         .glow("#3DDC84", 0.5f);
 * renderer.drawSpriteRegion(sheet, 0, 0, 32, 32, x, y, 32, 32, 0, fx);
 * }</pre>
 */
public final class RenderEffects {
    private final List<VarObjectEffect> effects = new ArrayList<>();

    private RenderEffects() {
    }

    public static RenderEffects none() {
        return new RenderEffects();
    }

    public static RenderEffects of() {
        return new RenderEffects();
    }

    /** Single alpha-following outline — ideal for tiles and sprites. */
    public static RenderEffects outline(Color color, float width) {
        return none().outline(color, width, RenderEffectTarget.SPRITE);
    }

    public static RenderEffects outline(String hexColor, float width) {
        return none().outline(hexColor, width, RenderEffectTarget.SPRITE);
    }

    /** Reuse effects authored on a VarObject layer. */
    public static RenderEffects from(List<VarObjectEffect> source) {
        RenderEffects result = new RenderEffects();
        if (source != null) {
            for (VarObjectEffect effect : source) {
                if (effect != null) {
                    result.effects.add(effect.copy());
                }
            }
        }
        return result;
    }

    public static RenderEffects from(VarObjectEffect... source) {
        RenderEffects result = new RenderEffects();
        if (source != null) {
            for (VarObjectEffect effect : source) {
                if (effect != null) {
                    result.effects.add(effect.copy());
                }
            }
        }
        return result;
    }

    public RenderEffects outline(Color color, float width, RenderEffectTarget target) {
        VarObjectEffect effect = VarObjectEffect.create(VarObjectEffectType.OUTLINE);
        effect.setColor(colorToHex(color));
        effect.setWidth(width);
        effect.setOutlineMode(outlineModeFor(target));
        effects.add(effect);
        return this;
    }

    public RenderEffects outline(String hexColor, float width, RenderEffectTarget target) {
        VarObjectEffect effect = VarObjectEffect.create(VarObjectEffectType.OUTLINE);
        effect.setColor(hexColor);
        effect.setWidth(width);
        effect.setOutlineMode(outlineModeFor(target));
        effects.add(effect);
        return this;
    }

    public RenderEffects glow(Color color, float intensity) {
        VarObjectEffect effect = VarObjectEffect.create(VarObjectEffectType.GLOW);
        effect.setColor(colorToHex(color));
        effect.setIntensity(intensity);
        effects.add(effect);
        return this;
    }

    public RenderEffects glow(String hexColor, float intensity) {
        VarObjectEffect effect = VarObjectEffect.create(VarObjectEffectType.GLOW);
        effect.setColor(hexColor);
        effect.setIntensity(intensity);
        effects.add(effect);
        return this;
    }

    public RenderEffects tint(Color color, float intensity) {
        VarObjectEffect effect = VarObjectEffect.create(VarObjectEffectType.TINT);
        effect.setColor(colorToHex(color));
        effect.setIntensity(intensity);
        effects.add(effect);
        return this;
    }

    public RenderEffects tint(String hexColor, float intensity) {
        VarObjectEffect effect = VarObjectEffect.create(VarObjectEffectType.TINT);
        effect.setColor(hexColor);
        effect.setIntensity(intensity);
        effects.add(effect);
        return this;
    }

    public RenderEffects flash(Color color, float intensity, float speed) {
        VarObjectEffect effect = VarObjectEffect.create(VarObjectEffectType.FLASH);
        effect.setColor(colorToHex(color));
        effect.setIntensity(intensity);
        effect.setSpeed(speed);
        effects.add(effect);
        return this;
    }

    public RenderEffects pulse(float speed) {
        VarObjectEffect effect = VarObjectEffect.create(VarObjectEffectType.PULSE);
        effect.setSpeed(speed);
        effects.add(effect);
        return this;
    }

    public RenderEffects shimmer(Color color, float intensity, float speed) {
        VarObjectEffect effect = VarObjectEffect.create(VarObjectEffectType.SHIMMER);
        effect.setColor(colorToHex(color));
        effect.setIntensity(intensity);
        effect.setSpeed(speed);
        effects.add(effect);
        return this;
    }

    public RenderEffects fade(float speed) {
        VarObjectEffect effect = VarObjectEffect.create(VarObjectEffectType.FADE);
        effect.setSpeed(speed);
        effects.add(effect);
        return this;
    }

    public boolean isEmpty() {
        return effects.isEmpty();
    }

    public VarObjectEffectEvaluator.Sample sample(double timeSeconds) {
        return VarObjectEffectEvaluator.evaluate(effects, timeSeconds);
    }

    List<VarObjectEffect> effectsInternal() {
        return List.copyOf(effects);
    }

    private static VarObjectOutlineMode outlineModeFor(RenderEffectTarget target) {
        if (target == null) {
            return VarObjectOutlineMode.ALPHA;
        }
        return switch (target) {
            case SPRITE -> VarObjectOutlineMode.ALPHA;
            case RECT -> VarObjectOutlineMode.SHAPE_RECT;
            case ELLIPSE -> VarObjectOutlineMode.SHAPE_ELLIPSE;
        };
    }

    private static String colorToHex(Color color) {
        if (color == null) {
            return "#FFFFFF";
        }
        return String.format("#%02X%02X%02X", color.getRed(), color.getGreen(), color.getBlue());
    }
}
