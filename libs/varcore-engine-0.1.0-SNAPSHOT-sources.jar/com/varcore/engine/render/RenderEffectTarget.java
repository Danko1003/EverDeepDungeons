package com.varcore.engine.render;

/** Hint for how outline/glow should follow drawn geometry. */
public enum RenderEffectTarget {
    /** Sprites, spritesheet regions, and APack frames — alpha-following outline. */
    SPRITE,
    /** Filled/stroked rectangles. */
    RECT,
    /** Circles and ellipses. */
    ELLIPSE
}
