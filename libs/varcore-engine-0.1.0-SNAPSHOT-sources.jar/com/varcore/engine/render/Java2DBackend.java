package com.varcore.engine.render;

import com.varcore.engine.camera.Camera;
import java.awt.Graphics2D;

public final class Java2DBackend implements RendererBackend {
    @Override
    public void beginFrame(Graphics2D graphics, Camera camera, int width, int height) {
        // Java2D rendering is handled by Renderer directly.
    }

    @Override
    public void endFrame() {}

    @Override
    public String getName() {
        return "Java2D";
    }
}
