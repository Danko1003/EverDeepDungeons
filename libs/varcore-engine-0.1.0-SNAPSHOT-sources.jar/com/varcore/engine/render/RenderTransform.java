package com.varcore.engine.render;

import com.varcore.engine.math.Rect;
import com.varcore.engine.varobject.VarObjectTransform;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;

/**
 * Pivot, rotation, and scale for any {@link Renderer} draw call — same model as VarObject layers.
 *
 * <pre>{@code
 * RenderTransform spin = RenderTransform.rotation(45f).anchor(0.5f, 1f);
 * RenderTransform flip = RenderTransform.identity().flipX().scale(2f);
 * }</pre>
 */
public final class RenderTransform {
    public static final float DEFAULT_ANCHOR = VarObjectTransform.DEFAULT_ANCHOR;

    private float rotationDegrees;
    private float scaleX = 1f;
    private float scaleY = 1f;
    private float anchorX = DEFAULT_ANCHOR;
    private float anchorY = DEFAULT_ANCHOR;
    private boolean flipX;
    private boolean flipY;

    private RenderTransform() {
    }

    public static RenderTransform identity() {
        return new RenderTransform();
    }

    public static RenderTransform rotation(float degrees) {
        return identity().rotate(degrees);
    }

    public RenderTransform rotate(float degrees) {
        rotationDegrees = degrees;
        return this;
    }

    public RenderTransform scale(float uniform) {
        return scale(uniform, uniform);
    }

    public RenderTransform scale(float sx, float sy) {
        scaleX = sx;
        scaleY = sy;
        return this;
    }

    public RenderTransform anchor(float ax, float ay) {
        anchorX = clamp01(ax);
        anchorY = clamp01(ay);
        return this;
    }

    public RenderTransform anchorCenter() {
        return anchor(DEFAULT_ANCHOR, DEFAULT_ANCHOR);
    }

    public RenderTransform anchorBottomCenter() {
        return anchor(0.5f, 1f);
    }

    public RenderTransform flipX() {
        flipX = true;
        return this;
    }

    public RenderTransform flipY() {
        flipY = true;
        return this;
    }

    public float rotationDegrees() {
        return rotationDegrees;
    }

    public float scaleX() {
        return effectiveScaleX();
    }

    public float scaleY() {
        return effectiveScaleY();
    }

    public float anchorX() {
        return anchorX;
    }

    public float anchorY() {
        return anchorY;
    }

    public boolean isIdentity() {
        return Math.abs(rotationDegrees) < 1e-6f
                && Math.abs(scaleX - 1f) < 1e-6f
                && Math.abs(scaleY - 1f) < 1e-6f
                && !flipX
                && !flipY;
    }

    /** Applies transform in local space — origin top-left, size {@code width}×{@code height}. */
    public void applyLocal(Graphics2D graphics, float width, float height) {
        if (isIdentity()) {
            return;
        }
        float pivotX = anchorX * width;
        float pivotY = anchorY * height;
        float sx = effectiveScaleX();
        float sy = effectiveScaleY();
        graphics.translate(pivotX, pivotY);
        if (Math.abs(rotationDegrees) > 1e-6f) {
            graphics.rotate(Math.toRadians(rotationDegrees));
        }
        if (Math.abs(sx - 1f) > 1e-6f || Math.abs(sy - 1f) > 1e-6f) {
            graphics.scale(sx, sy);
        }
        graphics.translate(-pivotX, -pivotY);
    }

    /** Axis-aligned world bounds after transform around {@code (x, y, width, height)}. */
    public Rect worldBounds(float x, float y, float width, float height) {
        if (isIdentity()) {
            return new Rect(x, y, width, height);
        }
        if (Math.abs(rotationDegrees) > 1e-6f
                && Math.abs(scaleX - 1f) < 1e-6f
                && Math.abs(scaleY - 1f) < 1e-6f
                && !flipX
                && !flipY) {
            Rectangle2D.Float box = VarObjectTransform.rotatedBounds(
                    x, y, width, height, anchorX, anchorY, rotationDegrees);
            return new Rect(box.x, box.y, box.width, box.height);
        }

        AffineTransform transform = new AffineTransform();
        transform.translate(x, y);
        appendLocal(transform, width, height);
        float[] corners = {
                0f, 0f,
                width, 0f,
                0f, height,
                width, height
        };
        float minX = Float.MAX_VALUE;
        float minY = Float.MAX_VALUE;
        float maxX = -Float.MAX_VALUE;
        float maxY = -Float.MAX_VALUE;
        float[] pt = new float[2];
        for (int i = 0; i < corners.length; i += 2) {
            pt[0] = corners[i];
            pt[1] = corners[i + 1];
            transform.transform(pt, 0, pt, 0, 1);
            minX = Math.min(minX, pt[0]);
            minY = Math.min(minY, pt[1]);
            maxX = Math.max(maxX, pt[0]);
            maxY = Math.max(maxY, pt[1]);
        }
        return new Rect(minX, minY, maxX - minX, maxY - minY);
    }

    private void appendLocal(AffineTransform transform, float width, float height) {
        float pivotX = anchorX * width;
        float pivotY = anchorY * height;
        float sx = effectiveScaleX();
        float sy = effectiveScaleY();
        transform.translate(pivotX, pivotY);
        if (Math.abs(rotationDegrees) > 1e-6f) {
            transform.rotate(Math.toRadians(rotationDegrees));
        }
        if (Math.abs(sx - 1f) > 1e-6f || Math.abs(sy - 1f) > 1e-6f) {
            transform.scale(sx, sy);
        }
        transform.translate(-pivotX, -pivotY);
    }

    private float effectiveScaleX() {
        return flipX ? -scaleX : scaleX;
    }

    private float effectiveScaleY() {
        return flipY ? -scaleY : scaleY;
    }

    private static float clamp01(float value) {
        return Math.max(0f, Math.min(1f, value));
    }
}
