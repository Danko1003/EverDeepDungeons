package com.varcore.engine.render;

import com.varcore.engine.math.Rect;
import com.varcore.engine.varobject.VarObjectEffectDraw;
import com.varcore.engine.varobject.VarObjectEffectEvaluator;
import com.varcore.engine.varobject.VarObjectNodeType;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.util.List;

/** Internal helpers for {@link RenderStyle} drawing on {@link Renderer}. */
final class RenderDraw {
    private RenderDraw() {
    }

    static void drawSprite(Renderer renderer, BufferedImage image,
                           float x, float y, float width, float height,
                           int layer, RenderStyle style, double timeSeconds) {
        drawSpriteRegion(renderer, image, 0, 0, image.getWidth(), image.getHeight(),
                x, y, width, height, layer, style, timeSeconds);
    }

    static void drawSpriteRegion(Renderer renderer, BufferedImage sheet,
                                 int sx, int sy, int sw, int sh,
                                 float x, float y, float width, float height,
                                 int layer, RenderStyle style, double timeSeconds) {
        Rect bounds = style.worldBounds(x, y, width, height, timeSeconds);
        VarObjectEffectDraw.SpriteRegion region = new VarObjectEffectDraw.SpriteRegion(sx, sy, sw, sh);

        renderer.drawLayered(layer, bounds.x, bounds.y, bounds.width, bounds.height, g -> {
            AffineTransform saved = g.getTransform();
            g.translate(x, y);
            style.transform().applyLocal(g, width, height);

            if (style.hasEffects()) {
                VarObjectEffectEvaluator.Sample sample = style.effects().sample(timeSeconds);
                VarObjectEffectDraw.drawSpriteEffects(g, sheet, region, 0f, 0f, width, height,
                        sample.opacityMultiplier(), VarObjectNodeType.IMAGE, sample);
            } else {
                SpriteDraw.drawImage(g, sheet, 0, 0, (int) width, (int) height, sx, sy, sx + sw, sy + sh);
            }
            g.setTransform(saved);
        });
    }

    static void drawRect(Renderer renderer, float x, float y, float width, float height,
                         Color color, boolean filled, int layer, RenderStyle style, double timeSeconds) {
        drawShape(renderer, x, y, width, height, color, filled, layer, style, timeSeconds, VarObjectNodeType.RECT);
    }

    static void drawCircle(Renderer renderer, float cx, float cy, float radius,
                           Color color, boolean filled, int layer, RenderStyle style, double timeSeconds) {
        drawShape(renderer, cx - radius, cy - radius, radius * 2f, radius * 2f,
                color, filled, layer, style, timeSeconds, VarObjectNodeType.ELLIPSE);
    }

    private static void drawShape(Renderer renderer, float x, float y, float width, float height,
                                  Color color, boolean filled, int layer, RenderStyle style,
                                  double timeSeconds, VarObjectNodeType shapeType) {
        Rect bounds = style.worldBounds(x, y, width, height, timeSeconds);

        renderer.drawLayered(layer, bounds.x, bounds.y, bounds.width, bounds.height, g -> {
            AffineTransform saved = g.getTransform();
            g.translate(x, y);
            style.transform().applyLocal(g, width, height);

            float alpha = 1f;
            VarObjectEffectEvaluator.Sample sample = null;
            if (style.hasEffects()) {
                sample = style.effects().sample(timeSeconds);
                alpha = sample.opacityMultiplier();
                VarObjectEffectDraw.applyPrePasses(g, 0f, 0f, width, height, sample.passes());
            }

            g.setColor(withAlpha(color, alpha));
            int d = (int) Math.max(width, height);
            if (shapeType == VarObjectNodeType.ELLIPSE) {
                if (filled) {
                    g.fillOval(0, 0, d, d);
                } else {
                    g.drawOval(0, 0, d, d);
                }
            } else if (filled) {
                g.fillRect(0, 0, (int) width, (int) height);
            } else {
                g.drawRect(0, 0, (int) width, (int) height);
            }

            if (style.hasEffects()) {
                VarObjectEffectDraw.applyPostPasses(g, 0f, 0f, width, height, sample.passes(), shapeType);
            }
            g.setTransform(saved);
        });
    }

    static float effectMargin(List<VarObjectEffectEvaluator.DrawPass> passes) {
        float expand = 0f;
        float outline = 0f;
        for (VarObjectEffectEvaluator.DrawPass pass : passes) {
            if (pass.kind() == VarObjectEffectEvaluator.PassKind.GLOW) {
                expand = Math.max(expand, pass.expand());
            } else if (pass.kind() == VarObjectEffectEvaluator.PassKind.OUTLINE) {
                outline = Math.max(outline, pass.strokeWidth());
            }
        }
        return expand + outline + 4f;
    }

    private static Color withAlpha(Color color, float alpha) {
        int a = Math.max(0, Math.min(255, (int) (alpha * 255)));
        return new Color(color.getRed(), color.getGreen(), color.getBlue(), a);
    }
}
