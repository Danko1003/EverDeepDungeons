package com.varcore.engine.render;

import java.awt.AlphaComposite;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;

/** Helpers for crisp pixel-art spritesheet packing and drawing. */
public final class SpriteDraw {
    private SpriteDraw() {
    }

    public static void configurePixelArt(Graphics2D graphics) {
        graphics.setRenderingHint(RenderingHints.KEY_INTERPOLATION,
                RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR);
        graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
        graphics.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_SPEED);
    }

    public static void clearTransparent(Graphics2D graphics, int width, int height) {
        graphics.setComposite(AlphaComposite.Clear);
        graphics.fillRect(0, 0, width, height);
        graphics.setComposite(AlphaComposite.SrcOver);
    }

    /** Ensures loaded PNGs keep alpha instead of a white RGB backing store. */
    public static BufferedImage toArgb(BufferedImage source) {
        if (source == null) {
            return null;
        }
        if (source.getType() == BufferedImage.TYPE_INT_ARGB) {
            return source;
        }
        BufferedImage argb = new BufferedImage(source.getWidth(), source.getHeight(), BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = argb.createGraphics();
        configurePixelArt(g);
        clearTransparent(g, source.getWidth(), source.getHeight());
        g.drawImage(source, 0, 0, null);
        g.dispose();
        return argb;
    }

    public static void drawImage(Graphics2D graphics, BufferedImage image,
                                 int dx1, int dy1, int dx2, int dy2,
                                 int sx1, int sy1, int sx2, int sy2) {
        configurePixelArt(graphics);
        graphics.drawImage(image, dx1, dy1, dx2, dy2, sx1, sy1, sx2, sy2, null);
    }

    public static void drawImage(Graphics2D graphics, BufferedImage image, int x, int y) {
        configurePixelArt(graphics);
        graphics.drawImage(image, x, y, null);
    }
}
