package com.varcore.engine.render;

import com.varcore.engine.math.Rect;

/**
 * Optional transform + effects for a single draw call. Use any combination:
 *
 * <pre>{@code
 * // Transform only
 * renderer.drawSprite(img, x, y, 32, 32, 0, RenderStyle.transform(RenderTransform.rotation(45f)));
 *
 * // Effects only
 * renderer.drawSprite(img, x, y, 32, 32, 0, RenderStyle.effects(RenderEffects.outline(Color.YELLOW, 2f)));
 *
 * // Both
 * RenderStyle style = RenderStyle.of()
 *         .withTransform(RenderTransform.rotation(15f).anchorBottomCenter())
 *         .withEffects(RenderEffects.outline(Color.YELLOW, 2f));
 * renderer.drawSprite(img, x, y, 32, 32, 0, style);
 * }</pre>
 */
public final class RenderStyle {
    private RenderTransform transform = RenderTransform.identity();
    private RenderEffects effects = RenderEffects.none();

    private RenderStyle() {
    }

    public static RenderStyle none() {
        return new RenderStyle();
    }

    public static RenderStyle of() {
        return new RenderStyle();
    }

    public static RenderStyle transform(RenderTransform transform) {
        return none().withTransform(transform);
    }

    public static RenderStyle effects(RenderEffects effects) {
        return none().withEffects(effects);
    }

    public static RenderStyle of(RenderTransform transform, RenderEffects effects) {
        return none().withTransform(transform).withEffects(effects);
    }

    public RenderStyle withTransform(RenderTransform transform) {
        this.transform = transform == null ? RenderTransform.identity() : transform;
        return this;
    }

    public RenderStyle withEffects(RenderEffects effects) {
        this.effects = effects == null ? RenderEffects.none() : effects;
        return this;
    }

    public RenderTransform transform() {
        return transform;
    }

    public RenderEffects effects() {
        return effects;
    }

    public boolean hasTransform() {
        return transform != null && !transform.isIdentity();
    }

    public boolean hasEffects() {
        return effects != null && !effects.isEmpty();
    }

    public boolean isDefault() {
        return !hasTransform() && !hasEffects();
    }

    public Rect worldBounds(float x, float y, float width, float height, double timeSeconds) {
        Rect base = hasTransform()
                ? transform.worldBounds(x, y, width, height)
                : new Rect(x, y, width, height);
        if (!hasEffects()) {
            return base;
        }
        float margin = RenderDraw.effectMargin(effects.sample(timeSeconds).passes());
        return new Rect(
                base.x - margin,
                base.y - margin,
                base.width + margin * 2f,
                base.height + margin * 2f);
    }
}
