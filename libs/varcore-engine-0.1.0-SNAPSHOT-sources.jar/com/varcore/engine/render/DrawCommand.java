package com.varcore.engine.render;

import com.varcore.engine.math.Rect;
import java.awt.Graphics2D;
import java.util.function.Consumer;

record DrawCommand(int layer, Rect bounds, Consumer<Graphics2D> draw) {
    void draw(Graphics2D g) {
        draw.accept(g);
    }
}
