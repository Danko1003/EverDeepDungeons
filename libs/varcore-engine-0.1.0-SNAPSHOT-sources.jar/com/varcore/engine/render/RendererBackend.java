package com.varcore.engine.render;

import com.varcore.engine.camera.Camera;
import java.awt.Graphics2D;

/**
 * Abstraction for future renderer backends (e.g. OpenGL).
 * Current implementation uses Java2D via {@link Renderer}.
 */
public interface RendererBackend {
    void beginFrame(Graphics2D graphics, Camera camera, int width, int height);

    void endFrame();

    String getName();
}
