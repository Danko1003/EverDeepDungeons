package com.varcore.engine.render;

public enum ScaleMode {
    STRETCH,
    LETTERBOX
}
