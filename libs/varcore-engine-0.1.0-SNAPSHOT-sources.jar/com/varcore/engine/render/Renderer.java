package com.varcore.engine.render;

import com.varcore.engine.camera.Camera;
import com.varcore.engine.core.GameWindow;
import com.varcore.engine.core.Time;
import com.varcore.engine.math.Rect;
import java.awt.AlphaComposite;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;

public final class Renderer {
    private final GameWindow window;
    private final Camera camera;
    private final List<DrawCommand> commands = new ArrayList<>();
    private final List<Consumer<Graphics2D>> screenCommands = new ArrayList<>();
    private Graphics2D graphics;
    private int drawCallCount;
    private ScaleMode scaleMode = ScaleMode.LETTERBOX;
    private Color clearColor = new Color(0x11, 0x13, 0x18);
    private int virtualWidth;
    private int virtualHeight;

    public Renderer(GameWindow window, Camera camera) {
        this.window = window;
        this.camera = camera;
        this.virtualWidth = window.getCanvas().getWidth();
        this.virtualHeight = window.getCanvas().getHeight();
        camera.setViewport(virtualWidth, virtualHeight);
    }

    public void beginFrame(Graphics2D g) {
        graphics = g;
        commands.clear();
        screenCommands.clear();
        drawCallCount = 0;
        virtualWidth = window.getWidth();
        virtualHeight = window.getHeight();
        camera.setViewport(virtualWidth, virtualHeight);
        updatePresentationTransform();

        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        g.setColor(clearColor);
        g.fillRect(0, 0, virtualWidth, virtualHeight);
    }

    /** Updates camera presentation before input/render when the window size changes (e.g. fullscreen). */
    public void updatePresentationTransform() {
        virtualWidth = window.getWidth();
        virtualHeight = window.getHeight();
        camera.setViewport(virtualWidth, virtualHeight);

        if (scaleMode == ScaleMode.LETTERBOX) {
            float scale = Math.min(
                    virtualWidth / (float) camera.getWorldWidth(),
                    virtualHeight / (float) camera.getWorldHeight());
            float visibleWorldW = camera.getWorldWidth() / camera.getZoom();
            float visibleWorldH = camera.getWorldHeight() / camera.getZoom();
            float offsetX = (virtualWidth - visibleWorldW * scale) / 2f;
            float offsetY = (virtualHeight - visibleWorldH * scale) / 2f;
            camera.setPresentationTransform(
                    scale,
                    scale,
                    offsetX,
                    offsetY,
                    true,
                    offsetX,
                    offsetY,
                    visibleWorldW * scale,
                    visibleWorldH * scale);
        } else {
            float scaleX = virtualWidth / (float) camera.getWorldWidth();
            float scaleY = virtualHeight / (float) camera.getWorldHeight();
            camera.setPresentationTransform(
                    scaleX,
                    scaleY,
                    0f,
                    0f,
                    true,
                    0f,
                    0f,
                    virtualWidth,
                    virtualHeight);
        }
    }

    public void endFrame() {
        if (graphics == null) {
            return;
        }
        applyCameraTransform();
        commands.sort(Comparator.comparingInt(DrawCommand::layer));
        for (DrawCommand command : commands) {
            if (!isVisible(command)) {
                continue;
            }
            command.draw(graphics);
            drawCallCount++;
        }
        graphics.setTransform(new AffineTransform());
        for (Consumer<Graphics2D> screen : screenCommands) {
            screen.accept(graphics);
            drawCallCount++;
        }
    }

    private void applyCameraTransform() {
        graphics.setTransform(camera.getWorldToScreenTransform());
    }

    private boolean isVisible(DrawCommand command) {
        Rect bounds = command.bounds();
        if (bounds == null) {
            return true;
        }
        Rect view = camera.getViewBounds();
        return bounds.intersects(view);
    }

    public void drawSprite(BufferedImage image, float x, float y, float width, float height, int layer) {
        if (image == null) {
            return;
        }
        commands.add(new DrawCommand(layer, bounds(x, y, width, height), g -> {
            SpriteDraw.drawImage(g, image, (int) x, (int) y, (int) (x + width), (int) (y + height),
                    0, 0, image.getWidth(), image.getHeight());
        }));
    }

    public void drawSprite(BufferedImage image, float x, float y, float width, float height,
                           int layer, RenderEffects effects) {
        drawSprite(image, x, y, width, height, layer, RenderStyle.effects(effects));
    }

    public void drawSprite(BufferedImage image, float x, float y, float width, float height,
                           int layer, RenderEffects effects, double timeSeconds) {
        drawSprite(image, x, y, width, height, layer, RenderStyle.effects(effects), timeSeconds);
    }

    public void drawSprite(BufferedImage image, float x, float y, float width, float height,
                           int layer, RenderTransform transform) {
        drawSprite(image, x, y, width, height, layer, RenderStyle.transform(transform));
    }

    public void drawSprite(BufferedImage image, float x, float y, float width, float height,
                           int layer, RenderStyle style) {
        drawSprite(image, x, y, width, height, layer, style, Time.totalTime());
    }

    public void drawSprite(BufferedImage image, float x, float y, float width, float height,
                           int layer, RenderStyle style, double timeSeconds) {
        if (image == null) {
            return;
        }
        if (style == null || style.isDefault()) {
            drawSprite(image, x, y, width, height, layer);
            return;
        }
        RenderDraw.drawSprite(this, image, x, y, width, height, layer, style, timeSeconds);
    }

    public void drawSpriteRegion(BufferedImage sheet, int sx, int sy, int sw, int sh,
                                 float x, float y, float width, float height, int layer) {
        if (sheet == null) {
            return;
        }
        commands.add(new DrawCommand(layer, bounds(x, y, width, height), g -> {
            SpriteDraw.drawImage(g, sheet, (int) x, (int) y, (int) (x + width), (int) (y + height),
                    sx, sy, sx + sw, sy + sh);
        }));
    }

    public void drawSpriteRegion(BufferedImage sheet, int sx, int sy, int sw, int sh,
                                 float x, float y, float width, float height,
                                 int layer, RenderEffects effects) {
        drawSpriteRegion(sheet, sx, sy, sw, sh, x, y, width, height, layer, RenderStyle.effects(effects));
    }

    public void drawSpriteRegion(BufferedImage sheet, int sx, int sy, int sw, int sh,
                                 float x, float y, float width, float height,
                                 int layer, RenderEffects effects, double timeSeconds) {
        drawSpriteRegion(sheet, sx, sy, sw, sh, x, y, width, height, layer, RenderStyle.effects(effects), timeSeconds);
    }

    public void drawSpriteRegion(BufferedImage sheet, int sx, int sy, int sw, int sh,
                                 float x, float y, float width, float height,
                                 int layer, RenderTransform transform) {
        drawSpriteRegion(sheet, sx, sy, sw, sh, x, y, width, height, layer, RenderStyle.transform(transform));
    }

    public void drawSpriteRegion(BufferedImage sheet, int sx, int sy, int sw, int sh,
                                 float x, float y, float width, float height,
                                 int layer, RenderStyle style) {
        drawSpriteRegion(sheet, sx, sy, sw, sh, x, y, width, height, layer, style, Time.totalTime());
    }

    public void drawSpriteRegion(BufferedImage sheet, int sx, int sy, int sw, int sh,
                                 float x, float y, float width, float height,
                                 int layer, RenderStyle style, double timeSeconds) {
        if (sheet == null) {
            return;
        }
        if (style == null || style.isDefault()) {
            drawSpriteRegion(sheet, sx, sy, sw, sh, x, y, width, height, layer);
            return;
        }
        RenderDraw.drawSpriteRegion(this, sheet, sx, sy, sw, sh, x, y, width, height, layer, style, timeSeconds);
    }

    /** Single batched draw with custom compositing (e.g. alpha-aware sprite effects). */
    public void drawLayered(int layer, float x, float y, float width, float height, Consumer<Graphics2D> drawer) {
        commands.add(new DrawCommand(layer, bounds(x, y, width, height), drawer::accept));
    }

    public void drawRect(float x, float y, float width, float height, Color color, boolean filled, int layer) {
        commands.add(new DrawCommand(layer, bounds(x, y, width, height), g -> {
            g.setColor(color);
            if (filled) {
                g.fillRect((int) x, (int) y, (int) width, (int) height);
            } else {
                g.drawRect((int) x, (int) y, (int) width, (int) height);
            }
        }));
    }

    public void drawRect(float x, float y, float width, float height, Color color, boolean filled,
                         int layer, RenderEffects effects) {
        drawRect(x, y, width, height, color, filled, layer, RenderStyle.effects(effects));
    }

    public void drawRect(float x, float y, float width, float height, Color color, boolean filled,
                         int layer, RenderEffects effects, double timeSeconds) {
        drawRect(x, y, width, height, color, filled, layer, RenderStyle.effects(effects), timeSeconds);
    }

    public void drawRect(float x, float y, float width, float height, Color color, boolean filled,
                         int layer, RenderTransform transform) {
        drawRect(x, y, width, height, color, filled, layer, RenderStyle.transform(transform));
    }

    public void drawRect(float x, float y, float width, float height, Color color, boolean filled,
                         int layer, RenderStyle style) {
        drawRect(x, y, width, height, color, filled, layer, style, Time.totalTime());
    }

    public void drawRect(float x, float y, float width, float height, Color color, boolean filled,
                         int layer, RenderStyle style, double timeSeconds) {
        if (style == null || style.isDefault()) {
            drawRect(x, y, width, height, color, filled, layer);
            return;
        }
        RenderDraw.drawRect(this, x, y, width, height, color, filled, layer, style, timeSeconds);
    }

    public void drawLine(float x1, float y1, float x2, float y2, Color color, float stroke, int layer) {
        commands.add(new DrawCommand(layer, null, g -> {
            g.setColor(color);
            g.setStroke(new BasicStroke(stroke));
            g.drawLine((int) x1, (int) y1, (int) x2, (int) y2);
        }));
    }

    public void drawCircle(float cx, float cy, float radius, Color color, boolean filled, int layer) {
        commands.add(new DrawCommand(layer, bounds(cx - radius, cy - radius, radius * 2, radius * 2), g -> {
            g.setColor(color);
            int d = (int) (radius * 2);
            if (filled) {
                g.fillOval((int) (cx - radius), (int) (cy - radius), d, d);
            } else {
                g.drawOval((int) (cx - radius), (int) (cy - radius), d, d);
            }
        }));
    }

    public void drawCircle(float cx, float cy, float radius, Color color, boolean filled,
                           int layer, RenderEffects effects) {
        drawCircle(cx, cy, radius, color, filled, layer, RenderStyle.effects(effects));
    }

    public void drawCircle(float cx, float cy, float radius, Color color, boolean filled,
                           int layer, RenderEffects effects, double timeSeconds) {
        drawCircle(cx, cy, radius, color, filled, layer, RenderStyle.effects(effects), timeSeconds);
    }

    public void drawCircle(float cx, float cy, float radius, Color color, boolean filled,
                           int layer, RenderTransform transform) {
        drawCircle(cx, cy, radius, color, filled, layer, RenderStyle.transform(transform));
    }

    public void drawCircle(float cx, float cy, float radius, Color color, boolean filled,
                           int layer, RenderStyle style) {
        drawCircle(cx, cy, radius, color, filled, layer, style, Time.totalTime());
    }

    public void drawCircle(float cx, float cy, float radius, Color color, boolean filled,
                           int layer, RenderStyle style, double timeSeconds) {
        if (style == null || style.isDefault()) {
            drawCircle(cx, cy, radius, color, filled, layer);
            return;
        }
        RenderDraw.drawCircle(this, cx, cy, radius, color, filled, layer, style, timeSeconds);
    }

    public void drawText(String text, float x, float y, Font font, Color color, int layer) {
        commands.add(new DrawCommand(layer, null, g -> {
            g.setFont(font);
            g.setColor(color);
            g.drawString(text, x, y);
        }));
    }

    public void drawTextScreen(String text, float x, float y, Font font, Color color) {
        screenCommands.add(g -> {
            g.setFont(font);
            g.setColor(color);
            g.drawString(text, x, y);
        });
    }

    public void setAlpha(float alpha) {
        if (graphics != null) {
            graphics.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, alpha));
        }
    }

    public void resetAlpha() {
        if (graphics != null) {
            graphics.setComposite(AlphaComposite.SrcOver);
        }
    }

    private static Rect bounds(float x, float y, float w, float h) {
        return new Rect(x, y, w, h);
    }

    public int getDrawCallCount() {
        return drawCallCount;
    }

    public void setClearColor(Color clearColor) {
        this.clearColor = clearColor;
    }

    public void setScaleMode(ScaleMode scaleMode) {
        this.scaleMode = scaleMode;
    }

    public Camera getCamera() {
        return camera;
    }

    public Graphics2D getGraphics() {
        return graphics;
    }
}
