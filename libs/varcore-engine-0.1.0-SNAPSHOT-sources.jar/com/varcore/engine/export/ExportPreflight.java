package com.varcore.engine.export;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.stream.Stream;

public final class ExportPreflight {
    private ExportPreflight() {
    }

    public static void checkProject(Path projectRoot, String mainClass) throws IOException {
        Path srcDir = projectRoot.resolve("src/main/java");
        if (!Files.isDirectory(srcDir)) {
            throw new IOException("Project is missing src/main/java");
        }

        try (Stream<Path> sources = Files.walk(srcDir)) {
            boolean hasJava = sources.anyMatch(path -> path.toString().endsWith(".java"));
            if (!hasJava) {
                throw new IOException("Project has no Java source files to export");
            }
        }

        String mainSource = "src/main/java/" + mainClass.replace('.', '/') + ".java";
        if (!Files.exists(projectRoot.resolve(mainSource))) {
            throw new IOException("Project is missing main class source: " + mainSource);
        }

        if (!Files.isDirectory(projectRoot.resolve("assets"))) {
            throw new IOException("Project is missing assets/ folder — templates should include one");
        }
    }

    public static void checkInstallRoot(Path installRoot) throws IOException {
        EngineRuntimeDependencies.resolve(installRoot);
        Path engineJar = installRoot.resolve("varcore-engine/build/libs");
        if (!Files.isDirectory(engineJar)) {
            throw new IOException("Engine build output not found. Build VarCore first: gradlew.bat build");
        }
        try (Stream<Path> jars = Files.list(engineJar)) {
            boolean hasEngine = jars.anyMatch(path -> path.getFileName().toString().startsWith("varcore-engine")
                    && path.getFileName().toString().endsWith(".jar"));
            if (!hasEngine) {
                throw new IOException("varcore-engine JAR not found. Run gradlew.bat build from the install root.");
            }
        }
    }

    public static String readMainClass(Path projectRoot) throws IOException {
        Path meta = projectRoot.resolve("varcore-project.json");
        if (Files.exists(meta)) {
            String json = Files.readString(meta);
            int idx = json.indexOf("\"mainClass\"");
            if (idx >= 0) {
                int start = json.indexOf('"', idx + 11);
                int end = json.indexOf('"', start + 1);
                if (start >= 0 && end > start) {
                    return json.substring(start + 1, end);
                }
            }
        }
        return "com.varcore.game.Main";
    }
}
