package com.varcore.engine.export;

import java.io.IOException;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.jar.JarFile;
import java.util.stream.Stream;

public final class ExportValidator {
    private static final List<String> CRITICAL_ENGINE_CLASSES = List.of(
            "com.varcore.engine.core.Game",
            "com.varcore.engine.save.SaveManager",
            "com.google.gson.JsonElement"
    );

    private ExportValidator() {
    }

    public static ExportValidationReport validate(Path exportRoot, String mainClass, List<Path> dependencyJars)
            throws IOException {
        List<String> checks = new ArrayList<>();
        Path gameJar = exportRoot.resolve("Game.jar");
        Path libsDir = exportRoot.resolve("libs");
        Path runBat = exportRoot.resolve("run.bat");

        if (!Files.exists(gameJar)) {
            throw new IOException("Export validation failed: Game.jar was not created");
        }
        checks.add("Game.jar created");

        if (!Files.isDirectory(libsDir)) {
            throw new IOException("Export validation failed: libs/ folder is missing");
        }

        List<String> requiredLibs = dependencyJars.stream()
                .map(path -> path.getFileName().toString())
                .toList();
        for (String libName : requiredLibs) {
            Path libPath = libsDir.resolve(libName);
            if (!Files.exists(libPath)) {
                throw new IOException("Export validation failed: missing libs/" + libName);
            }
            if (Files.size(libPath) <= 0) {
                throw new IOException("Export validation failed: libs/" + libName + " is empty");
            }
            checks.add("libs/" + libName + " present");
        }

        try (JarFile jar = new JarFile(gameJar.toFile())) {
            String mainEntry = mainClass.replace('.', '/') + ".class";
            if (jar.getEntry(mainEntry) == null) {
                throw new IOException("Export validation failed: " + mainClass + " not found in Game.jar");
            }
            checks.add("Main class packaged in Game.jar");

            String classPath = jar.getManifest().getMainAttributes().getValue("Class-Path");
            if (classPath == null || classPath.isBlank()) {
                throw new IOException("Export validation failed: Game.jar manifest has no Class-Path");
            }
            for (String libName : requiredLibs) {
                String expected = "libs/" + libName;
                if (!classPath.contains(expected)) {
                    throw new IOException("Export validation failed: manifest Class-Path missing " + expected);
                }
            }
            checks.add("Manifest Class-Path lists all runtime libraries");
        }

        if (!Files.exists(runBat)) {
            throw new IOException("Export validation failed: run.bat is missing");
        }
        String runScript = Files.readString(runBat);
        if (!runScript.contains("libs\\*") && !runScript.contains("libs/*")) {
            throw new IOException("Export validation failed: run.bat does not include libs/* on classpath");
        }
        checks.add("Launcher script includes libs/* classpath");

        validateClasspathLoads(exportRoot, mainClass);
        checks.add("Runtime classpath loads game and engine dependencies");

        return new ExportValidationReport(checks);
    }

    private static void validateClasspathLoads(Path exportRoot, String mainClass) throws IOException {
        List<URL> urls = new ArrayList<>();
        urls.add(exportRoot.resolve("Game.jar").toUri().toURL());
        try (Stream<Path> jars = Files.list(exportRoot.resolve("libs"))) {
            for (Path jar : jars.filter(path -> path.toString().endsWith(".jar")).toList()) {
                urls.add(jar.toUri().toURL());
            }
        }

        URLClassLoader loader = new URLClassLoader(urls.toArray(URL[]::new));
        try {
            loader.loadClass(mainClass);
            for (String className : CRITICAL_ENGINE_CLASSES) {
                loader.loadClass(className);
            }
        } catch (ClassNotFoundException | NoClassDefFoundError ex) {
            throw new IOException("Export validation failed: classpath could not load required classes — "
                    + ex.getMessage(), ex);
        } finally {
            loader.close();
        }
    }

    public record ExportValidationReport(List<String> checks) {
        public String summary() {
            return String.join("; ", checks);
        }
    }
}
