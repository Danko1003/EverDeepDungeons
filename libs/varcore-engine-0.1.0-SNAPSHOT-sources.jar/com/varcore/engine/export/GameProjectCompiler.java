package com.varcore.engine.export;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;
import javax.tools.JavaCompiler;
import javax.tools.ToolProvider;

public final class GameProjectCompiler {
    public Path compile(Path projectRoot, Path engineJar, Path outputDir) throws IOException {
        Path srcDir = projectRoot.resolve("src/main/java");
        if (!Files.isDirectory(srcDir)) {
            throw new IOException("Project has no src/main/java directory: " + projectRoot);
        }
        if (!Files.exists(engineJar)) {
            throw new IOException("Engine JAR not found. Build the engine first: " + engineJar);
        }

        List<Path> sourceFiles;
        try (Stream<Path> paths = Files.walk(srcDir)) {
            sourceFiles = paths.filter(path -> path.toString().endsWith(".java")).toList();
        }
        if (sourceFiles.isEmpty()) {
            throw new IOException("No Java source files found in " + srcDir);
        }

        JavaCompiler compiler = ToolProvider.getSystemJavaCompiler();
        if (compiler == null) {
            throw new IOException("JDK compiler not available. Export requires a full JDK (not a JRE).");
        }

        Files.createDirectories(outputDir);

        List<String> arguments = new ArrayList<>();
        arguments.add("-classpath");
        arguments.add(engineJar.toAbsolutePath().toString());
        arguments.add("-d");
        arguments.add(outputDir.toAbsolutePath().toString());
        arguments.add("--release");
        arguments.add("21");
        for (Path source : sourceFiles) {
            arguments.add(source.toAbsolutePath().toString());
        }

        int result = compiler.run(null, null, null, arguments.toArray(String[]::new));
        if (result != 0) {
            throw new IOException("Failed to compile project sources for export");
        }

        if (!Files.isDirectory(outputDir.resolve("com"))) {
            throw new IOException("Compilation produced no class files in " + outputDir);
        }

        return outputDir;
    }
}
