package com.varcore.engine.export;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Stream;

public final class EngineRuntimeDependencies {
    private EngineRuntimeDependencies() {
    }

    public static List<Path> resolve(Path installRoot) throws IOException {
        Path engineJar = installRoot.resolve("varcore-engine/build/libs/varcore-engine-0.1.0-SNAPSHOT.jar");
        if (!Files.exists(engineJar)) {
            try (Stream<Path> jars = Files.list(installRoot.resolve("varcore-engine/build/libs"))) {
                engineJar = jars.filter(path -> path.getFileName().toString().startsWith("varcore-engine")
                                && path.getFileName().toString().endsWith(".jar"))
                        .max(Comparator.comparing(path -> path.getFileName().toString()))
                        .orElse(null);
            }
        }
        if (engineJar == null || !Files.exists(engineJar)) {
            throw new IOException("Engine JAR not found. Build the engine first from the VarCore install root.");
        }

        Path gsonJar = installRoot.resolve("libs/gson-2.11.0.jar");
        if (!Files.exists(gsonJar)) {
            throw new IOException("Gson JAR not found at " + gsonJar);
        }

        List<Path> deps = new ArrayList<>();
        deps.add(engineJar);
        deps.add(gsonJar);
        return deps;
    }

    public static Path engineJar(Path installRoot) throws IOException {
        return resolve(installRoot).getFirst();
    }
}
