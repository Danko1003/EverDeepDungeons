package com.varcore.engine.export;

/** Target platform(s) for exported game launchers. */
public enum ExportPlatform {
    WINDOWS("Windows", "run.bat"),
    MACOS("macOS", "run.sh", "run.command"),
    LINUX("Linux", "run.sh"),
    ALL("All platforms", "run.bat", "run.sh", "run.command");

    private final String label;
    private final String[] launcherFiles;

    ExportPlatform(String label, String... launcherFiles) {
        this.label = label;
        this.launcherFiles = launcherFiles;
    }

    public String label() {
        return label;
    }

    public String[] launcherFiles() {
        return launcherFiles.clone();
    }

    public boolean includesWindows() {
        return this == WINDOWS || this == ALL;
    }

    public boolean includesUnix() {
        return this == MACOS || this == LINUX || this == ALL;
    }

    public boolean includesMac() {
        return this == MACOS || this == ALL;
    }

    /** Best default when exporting from the current Studio host OS. */
    public static ExportPlatform hostDefault() {
        String os = System.getProperty("os.name", "").toLowerCase();
        if (os.contains("mac") || os.contains("darwin")) {
            return MACOS;
        }
        if (os.contains("linux")) {
            return LINUX;
        }
        return WINDOWS;
    }
}
