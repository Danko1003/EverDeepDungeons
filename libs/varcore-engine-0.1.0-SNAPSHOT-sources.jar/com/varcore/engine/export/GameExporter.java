package com.varcore.engine.export;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.varcore.engine.project.ProjectCoverImage;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.PosixFilePermission;
import java.time.Instant;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.jar.Attributes;
import java.util.jar.JarOutputStream;
import java.util.jar.Manifest;
import java.util.stream.Stream;

public final class GameExporter {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public ExportResult export(Path projectRoot, Path outputDir, String gameName, String mainClass,
                               Path engineJar, List<Path> dependencyJars, Path compiledClassesDir)
            throws IOException {
        return export(projectRoot, outputDir, gameName, mainClass, engineJar, dependencyJars,
                compiledClassesDir, ExportPlatform.ALL);
    }

    public ExportResult export(Path projectRoot, Path outputDir, String gameName, String mainClass,
                               Path engineJar, List<Path> dependencyJars, Path compiledClassesDir,
                               ExportPlatform platform)
            throws IOException {
        Path exportRoot = outputDir.resolve(gameName);
        if (Files.exists(exportRoot)) {
            deleteDirectory(exportRoot);
        }

        try {
            Path assetsDir = exportRoot.resolve("assets");
            Path libsDir = exportRoot.resolve("libs");
            Path configDir = exportRoot.resolve("config");

            Files.createDirectories(assetsDir);
            Files.createDirectories(libsDir);
            Files.createDirectories(configDir);

            Path projectAssets = projectRoot.resolve("assets");
            if (Files.isDirectory(projectAssets)) {
                copyDirectory(projectAssets, assetsDir);
            }

            Set<Path> runtimeLibs = new LinkedHashSet<>(dependencyJars);
            if (engineJar != null && Files.exists(engineJar)) {
                runtimeLibs.add(engineJar);
            }

            Path gameJar = exportRoot.resolve("Game.jar");
            buildJar(gameJar, mainClass, compiledClassesDir, List.copyOf(runtimeLibs));

            for (Path dep : runtimeLibs) {
                if (Files.exists(dep)) {
                    Files.copy(dep, libsDir.resolve(dep.getFileName()), StandardCopyOption.REPLACE_EXISTING);
                }
            }

            JsonObject config = new JsonObject();
            config.addProperty("name", gameName);
            config.addProperty("mainClass", mainClass);
            config.addProperty("engineVersion", "0.1.0-SNAPSHOT");
            config.addProperty("platform", platform.name());
            Files.writeString(configDir.resolve("game.json"), GSON.toJson(config));

            writeLaunchers(exportRoot, mainClass, platform);
            Files.writeString(exportRoot.resolve("README.txt"), buildReadme(mainClass, platform));

            Path projectCover = ProjectCoverImage.inProject(projectRoot);
            if (Files.isRegularFile(projectCover)) {
                Files.copy(projectCover, ProjectCoverImage.inExport(exportRoot), StandardCopyOption.REPLACE_EXISTING);
            }

            ExportValidator.ExportValidationReport validation =
                    ExportValidator.validate(exportRoot, mainClass, List.copyOf(runtimeLibs), platform);

            registerExport(exportRoot, gameName);
            return new ExportResult(exportRoot, Instant.now(), validation);
        } catch (IOException ex) {
            deleteDirectory(exportRoot);
            throw ex;
        }
    }

    private void writeLaunchers(Path exportRoot, String mainClass, ExportPlatform platform) throws IOException {
        if (platform.includesWindows()) {
            String runBat = """
                    @echo off
                    cd /d "%%~dp0"
                    java -cp "Game.jar;libs\\*" %s %%*
                    if errorlevel 1 pause
                    """.formatted(mainClass);
            Files.writeString(exportRoot.resolve("run.bat"), runBat.replace("\n", "\r\n"));
        }

        if (platform.includesUnix()) {
            String unixScript = """
                    #!/bin/sh
                    cd "$(dirname "$0")"
                    exec java -cp "Game.jar:libs/*" %s "$@"
                    """.formatted(mainClass);
            Path runSh = exportRoot.resolve("run.sh");
            Files.writeString(runSh, unixScript);
            makeExecutable(runSh);

            if (platform.includesMac()) {
                Path runCommand = exportRoot.resolve("run.command");
                Files.writeString(runCommand, unixScript);
                makeExecutable(runCommand);
            }
        }
    }

    private static void makeExecutable(Path script) {
        try {
            Files.setPosixFilePermissions(script, EnumSet.of(
                    PosixFilePermission.OWNER_READ,
                    PosixFilePermission.OWNER_WRITE,
                    PosixFilePermission.OWNER_EXECUTE,
                    PosixFilePermission.GROUP_READ,
                    PosixFilePermission.GROUP_EXECUTE,
                    PosixFilePermission.OTHERS_READ,
                    PosixFilePermission.OTHERS_EXECUTE));
        } catch (UnsupportedOperationException ignored) {
            // Windows hosts cannot set Unix execute bits; macOS/Linux users can chmod +x if needed.
        } catch (IOException ignored) {
        }
    }

    private static String buildReadme(String mainClass, ExportPlatform platform) {
        StringBuilder sb = new StringBuilder();
        sb.append("VarCore Exported Game\n");
        sb.append("=====================\n");
        sb.append("Requirements: Java 21+ (Temurin or Oracle JDK recommended)\n");
        sb.append("Export target: ").append(platform.label()).append("\n\n");

        if (platform.includesWindows()) {
            sb.append("Windows: double-click run.bat\n");
            sb.append("  Or: java -cp \"Game.jar;libs/*\" ").append(mainClass).append("\n\n");
        }
        if (platform.includesMac()) {
            sb.append("macOS: double-click run.command (or run ./run.sh in Terminal)\n");
            sb.append("  If blocked, run: chmod +x run.sh run.command\n");
            sb.append("  Or: java -cp \"Game.jar:libs/*\" ").append(mainClass).append("\n\n");
        }
        if (platform == ExportPlatform.LINUX) {
            sb.append("Linux: ./run.sh\n");
            sb.append("  Or: java -cp \"Game.jar:libs/*\" ").append(mainClass).append("\n\n");
        }
        if (platform == ExportPlatform.ALL) {
            sb.append("Linux: ./run.sh\n\n");
        }

        sb.append("Controls: ESC to quit, F3 debug overlay, F11 fullscreen\n");
        return sb.toString();
    }

    private void buildJar(Path jarPath, String mainClass, Path classesDir, List<Path> dependencyJars)
            throws IOException {
        if (classesDir == null || !Files.isDirectory(classesDir)) {
            throw new IOException("Compiled classes directory is missing for export");
        }

        Manifest manifest = new Manifest();
        manifest.getMainAttributes().put(Attributes.Name.MANIFEST_VERSION, "1.0");
        manifest.getMainAttributes().put(Attributes.Name.MAIN_CLASS, mainClass);

        StringBuilder classPath = new StringBuilder();
        for (int i = 0; i < dependencyJars.size(); i++) {
            if (i > 0) {
                classPath.append(' ');
            }
            classPath.append("libs/").append(dependencyJars.get(i).getFileName());
        }
        manifest.getMainAttributes().put(Attributes.Name.CLASS_PATH, classPath.toString());

        try (JarOutputStream jos = new JarOutputStream(Files.newOutputStream(jarPath), manifest)) {
            addDirectoryToJar(jos, classesDir, classesDir);
        }
    }

    private void addDirectoryToJar(JarOutputStream jos, Path root, Path current) throws IOException {
        try (Stream<Path> paths = Files.walk(current)) {
            for (Path path : paths.filter(Files::isRegularFile).toList()) {
                String entryName = root.relativize(path).toString().replace('\\', '/');
                jos.putNextEntry(new java.util.zip.ZipEntry(entryName));
                Files.copy(path, jos);
                jos.closeEntry();
            }
        }
    }

    private void copyDirectory(Path source, Path target) throws IOException {
        try (Stream<Path> paths = Files.walk(source)) {
            for (Path path : paths.toList()) {
                Path dest = target.resolve(source.relativize(path));
                if (Files.isDirectory(path)) {
                    Files.createDirectories(dest);
                } else {
                    Files.createDirectories(dest.getParent());
                    Files.copy(path, dest, StandardCopyOption.REPLACE_EXISTING);
                }
            }
        }
    }

    private void deleteDirectory(Path path) throws IOException {
        if (!Files.exists(path)) {
            return;
        }
        try (Stream<Path> paths = Files.walk(path)) {
            paths.sorted((a, b) -> b.compareTo(a)).forEach(p -> {
                try {
                    Files.deleteIfExists(p);
                } catch (IOException ignored) {
                }
            });
        }
    }

    public void registerExport(Path exportPath, String gameName) throws IOException {
        Path registryDir = Path.of(System.getProperty("user.home"), ".varcore");
        Files.createDirectories(registryDir);
        Path registryFile = registryDir.resolve("exports.json");

        List<JsonObject> exports = new ArrayList<>();
        if (Files.exists(registryFile)) {
            JsonArray array = GSON.fromJson(Files.readString(registryFile), JsonArray.class);
            if (array != null) {
                for (var el : array) {
                    exports.add(el.getAsJsonObject());
                }
            }
        }

        JsonObject entry = new JsonObject();
        entry.addProperty("name", gameName);
        entry.addProperty("path", exportPath.toAbsolutePath().toString());
        entry.addProperty("date", Instant.now().toString());
        entry.addProperty("engineVersion", "0.1.0-SNAPSHOT");
        exports.add(entry);

        JsonArray out = new JsonArray();
        exports.forEach(out::add);
        Files.writeString(registryFile, GSON.toJson(out));
    }

    public record ExportResult(Path exportPath, Instant exportDate,
                               ExportValidator.ExportValidationReport validation) {}
}
