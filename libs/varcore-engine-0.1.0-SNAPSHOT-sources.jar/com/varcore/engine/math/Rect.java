package com.varcore.engine.math;

public final class Rect {
    public float x;
    public float y;
    public float width;
    public float height;

    public Rect() {
        this(0, 0, 0, 0);
    }

    public Rect(float x, float y, float width, float height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }

    public float right() {
        return x + width;
    }

    public float bottom() {
        return y + height;
    }

    public boolean contains(float px, float py) {
        return px >= x && py >= y && px < right() && py < bottom();
    }

    public boolean intersects(Rect other) {
        return x < other.right() && right() > other.x
                && y < other.bottom() && bottom() > other.y;
    }

    public Rect copy() {
        return new Rect(x, y, width, height);
    }
}
