package com.varcore.engine.math;

public final class MathUtils {
    private MathUtils() {}

    public static float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }

    public static float lerp(float a, float b, float t) {
        return a + (b - a) * t;
    }

    public static float degToRad(float degrees) {
        return (float) (degrees * Math.PI / 180.0);
    }

    public static float radToDeg(float radians) {
        return (float) (radians * 180.0 / Math.PI);
    }
}
