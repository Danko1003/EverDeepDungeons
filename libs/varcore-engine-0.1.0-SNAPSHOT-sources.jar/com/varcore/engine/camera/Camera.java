package com.varcore.engine.camera;

import com.varcore.engine.math.Rect;
import com.varcore.engine.math.Vector2;
import java.awt.geom.AffineTransform;
import java.awt.geom.NoninvertibleTransformException;
import java.awt.geom.Point2D;

public final class Camera {
    private final Vector2 position = new Vector2();
    private final Vector2 shakeOffset = new Vector2();
    private float zoom = 1f;
    private int viewportWidth;
    private int viewportHeight;
    private int worldWidth;
    private int worldHeight;
    private float presentationScaleX = 1f;
    private float presentationScaleY = 1f;
    private float presentationOffsetX;
    private float presentationOffsetY;
    private float presentationContentX;
    private float presentationContentY;
    private float presentationContentW;
    private float presentationContentH;
    private boolean presentationFitsWorld;

    public Camera(int worldWidth, int worldHeight) {
        this.worldWidth = worldWidth;
        this.worldHeight = worldHeight;
        position.set(worldWidth / 2f, worldHeight / 2f);
    }

    public void setViewport(int width, int height) {
        this.viewportWidth = width;
        this.viewportHeight = height;
    }

    public void setWorldSize(int width, int height) {
        this.worldWidth = width;
        this.worldHeight = height;
    }

    public void setPresentationTransform(float scaleX, float scaleY, float offsetX, float offsetY, boolean fitsWorld) {
        setPresentationTransform(scaleX, scaleY, offsetX, offsetY, fitsWorld, offsetX, offsetY,
                worldWidth / zoom * scaleX, worldHeight / zoom * scaleY);
    }

    public void setPresentationTransform(
            float scaleX,
            float scaleY,
            float offsetX,
            float offsetY,
            boolean fitsWorld,
            float contentX,
            float contentY,
            float contentW,
            float contentH) {
        this.presentationScaleX = scaleX;
        this.presentationScaleY = scaleY;
        this.presentationOffsetX = offsetX;
        this.presentationOffsetY = offsetY;
        this.presentationContentX = contentX;
        this.presentationContentY = contentY;
        this.presentationContentW = contentW;
        this.presentationContentH = contentH;
        this.presentationFitsWorld = fitsWorld;
    }

    public void resetPresentationTransform() {
        setPresentationTransform(1f, 1f, 0f, 0f, false, 0f, 0f, viewportWidth, viewportHeight);
    }

    public Vector2 getPosition() {
        return position;
    }

    public float getZoom() {
        return zoom;
    }

    public void setZoom(float zoom) {
        this.zoom = Math.max(0.1f, zoom);
    }

    public void shake(float intensity) {
        shakeOffset.set(
                (float) (Math.random() * 2 - 1) * intensity,
                (float) (Math.random() * 2 - 1) * intensity);
    }

    public AffineTransform getWorldToScreenTransform() {
        float camX = position.x + shakeOffset.x;
        float camY = position.y + shakeOffset.y;

        if (presentationFitsWorld) {
            float visibleW = visibleWorldWidth();
            float visibleH = visibleWorldHeight();
            float worldLeft = camX - visibleW / 2f;
            float worldTop = camY - visibleH / 2f;

            AffineTransform transform = new AffineTransform();
            transform.translate(presentationOffsetX, presentationOffsetY);
            transform.scale(presentationScaleX, presentationScaleY);
            transform.translate(-worldLeft, -worldTop);
            return transform;
        }

        AffineTransform transform = new AffineTransform();
        transform.translate(viewportWidth / 2f, viewportHeight / 2f);
        transform.scale(zoom, zoom);
        transform.translate(-camX, -camY);
        return transform;
    }

    public Vector2 worldToScreen(float wx, float wy) {
        Point2D.Float src = new Point2D.Float(wx, wy);
        Point2D.Float dst = new Point2D.Float();
        getWorldToScreenTransform().transform(src, dst);
        return new Vector2(dst.x, dst.y);
    }

    public Vector2 screenToWorld(float sx, float sy) {
        try {
            Point2D.Float src = new Point2D.Float(sx, sy);
            Point2D.Float dst = new Point2D.Float();
            getWorldToScreenTransform().createInverse().transform(src, dst);
            return new Vector2(dst.x, dst.y);
        } catch (NoninvertibleTransformException ex) {
            return new Vector2(position.x, position.y);
        }
    }

    public Rect getViewBounds() {
        float camX = position.x + shakeOffset.x;
        float camY = position.y + shakeOffset.y;
        float visibleW = visibleWorldWidth();
        float visibleH = visibleWorldHeight();
        float worldLeft = camX - visibleW / 2f;
        float worldTop = camY - visibleH / 2f;

        if (viewportWidth <= 0 || viewportHeight <= 0) {
            return new Rect(worldLeft, worldTop, visibleW, visibleH);
        }

        float screenX;
        float screenY;
        float screenW;
        float screenH;
        if (presentationFitsWorld) {
            screenX = presentationContentX;
            screenY = presentationContentY;
            screenW = presentationContentW;
            screenH = presentationContentH;
        } else {
            screenX = 0f;
            screenY = 0f;
            screenW = viewportWidth;
            screenH = viewportHeight;
        }

        Vector2 topLeft = screenToWorld(screenX, screenY);
        Vector2 topRight = screenToWorld(screenX + screenW, screenY);
        Vector2 bottomLeft = screenToWorld(screenX, screenY + screenH);
        Vector2 bottomRight = screenToWorld(screenX + screenW, screenY + screenH);

        float minX = Math.min(Math.min(topLeft.x, topRight.x), Math.min(bottomLeft.x, bottomRight.x));
        float minY = Math.min(Math.min(topLeft.y, topRight.y), Math.min(bottomLeft.y, bottomRight.y));
        float maxX = Math.max(Math.max(topLeft.x, topRight.x), Math.max(bottomLeft.x, bottomRight.x));
        float maxY = Math.max(Math.max(topLeft.y, topRight.y), Math.max(bottomLeft.y, bottomRight.y));

        float pad = 2f;
        return new Rect(minX - pad, minY - pad, (maxX - minX) + pad * 2f, (maxY - minY) + pad * 2f);
    }

    private float visibleWorldWidth() {
        if (presentationFitsWorld) {
            return worldWidth / zoom;
        }
        return viewportWidth / (zoom * Math.max(presentationScaleX, 1e-6f));
    }

    private float visibleWorldHeight() {
        if (presentationFitsWorld) {
            return worldHeight / zoom;
        }
        return viewportHeight / (zoom * Math.max(presentationScaleY, 1e-6f));
    }

    public int getWorldWidth() {
        return worldWidth;
    }

    public int getWorldHeight() {
        return worldHeight;
    }

    /** Places the camera so world (0,0) is the top-left of the logical world bounds. */
    public void centerOnWorld() {
        position.set(worldWidth / 2f, worldHeight / 2f);
    }
}
