package com.varcore.engine.save;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.varcore.engine.entity.GameObject;
import com.varcore.engine.scene.Scene;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public final class SaveManager {
    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();
    private static final int VERSION = 1;

    public void saveScene(Scene scene, Path file) throws IOException {
        JsonObject root = new JsonObject();
        root.addProperty("version", VERSION);
        root.addProperty("name", scene.getName());
        JsonArray objects = new JsonArray();
        for (GameObject go : scene.getGameObjects()) {
            JsonObject obj = new JsonObject();
            obj.addProperty("name", go.getName());
            obj.addProperty("tag", go.getTag());
            obj.addProperty("x", go.getTransform().getPosition().x);
            obj.addProperty("y", go.getTransform().getPosition().y);
            obj.addProperty("active", go.isActive());
            objects.add(obj);
        }
        root.add("objects", objects);
        Files.writeString(file, gson.toJson(root));
    }

    public void loadScene(Scene scene, Path file) throws IOException {
        String json = Files.readString(file);
        JsonObject root = gson.fromJson(json, JsonObject.class);
        scene.clear();
        JsonArray objects = root.getAsJsonArray("objects");
        for (var element : objects) {
            JsonObject obj = element.getAsJsonObject();
            GameObject go = new GameObject(obj.get("name").getAsString());
            go.setTag(obj.has("tag") ? obj.get("tag").getAsString() : "");
            go.getTransform().setPosition(obj.get("x").getAsFloat(), obj.get("y").getAsFloat());
            go.setActive(!obj.has("active") || obj.get("active").getAsBoolean());
            scene.add(go);
        }
    }
}
