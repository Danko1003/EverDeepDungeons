package com.varcore.engine.input;

import com.varcore.engine.camera.Camera;
import com.varcore.engine.math.Vector2;
import java.awt.Canvas;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import java.util.HashSet;
import java.util.Set;

public final class InputManager implements KeyListener, MouseListener, MouseMotionListener, MouseWheelListener {
    private final Object lock = new Object();
    private final Set<Integer> keysDown = new HashSet<>();
    private final Set<Integer> keysPressed = new HashSet<>();
    private final Set<Integer> keysReleased = new HashSet<>();
    private final Set<Integer> mouseDown = new HashSet<>();
    private final Set<Integer> mousePressed = new HashSet<>();
    private final Set<Integer> mouseClicked = new HashSet<>();
    private final Set<Integer> liveKeysDown = new HashSet<>();
    private final Set<Integer> liveMouseDown = new HashSet<>();
    private final Set<Integer> pendingKeysPressed = new HashSet<>();
    private final Set<Integer> pendingKeysReleased = new HashSet<>();
    private final Set<Integer> pendingMousePressed = new HashSet<>();
    private final Set<Integer> pendingMouseClicked = new HashSet<>();
    private int mouseX;
    private int mouseY;
    private int liveMouseX;
    private int liveMouseY;
    private int previousMouseX;
    private int previousMouseY;
    private int mouseDeltaX;
    private int mouseDeltaY;
    private int mouseWheelDelta;
    private int pendingMouseWheelDelta;
    private int mouseClickCount;
    private int pendingMouseClickCount;
    private long lastClickTimestamp;
    private long pendingLastClickTimestamp;
    private Camera camera;

    public InputManager(Canvas canvas) {
        canvas.addKeyListener(this);
        canvas.addMouseListener(this);
        canvas.addMouseMotionListener(this);
        canvas.addMouseWheelListener(this);
        canvas.setFocusable(true);
        canvas.requestFocusInWindow();
    }

    public void setCamera(Camera camera) {
        this.camera = camera;
    }

    public void beginFrame() {
        synchronized (lock) {
            keysDown.clear();
            keysDown.addAll(liveKeysDown);
            keysPressed.clear();
            keysPressed.addAll(pendingKeysPressed);
            pendingKeysPressed.clear();
            keysReleased.clear();
            keysReleased.addAll(pendingKeysReleased);
            pendingKeysReleased.clear();

            mouseDown.clear();
            mouseDown.addAll(liveMouseDown);
            mousePressed.clear();
            mousePressed.addAll(pendingMousePressed);
            pendingMousePressed.clear();
            mouseClicked.clear();
            mouseClicked.addAll(pendingMouseClicked);
            pendingMouseClicked.clear();

            mouseX = liveMouseX;
            mouseY = liveMouseY;
            mouseWheelDelta = pendingMouseWheelDelta;
            pendingMouseWheelDelta = 0;
            if (pendingMouseClickCount > 0) {
                mouseClickCount = pendingMouseClickCount;
                pendingMouseClickCount = 0;
            }
            if (pendingLastClickTimestamp != 0L) {
                lastClickTimestamp = pendingLastClickTimestamp;
                pendingLastClickTimestamp = 0L;
            }
        }
        mouseDeltaX = mouseX - previousMouseX;
        mouseDeltaY = mouseY - previousMouseY;
        previousMouseX = mouseX;
        previousMouseY = mouseY;
    }

    public void endFrame() {
        // Edge events are cleared when the next frame snapshots pending input.
        // This prevents events arriving late in a laggy frame from being erased
        // before gameplay has a chance to observe them.
    }

    public boolean isKeyDown(int keyCode) {
        return keysDown.contains(keyCode);
    }

    public boolean isKeyPressed(int keyCode) {
        return keysPressed.contains(keyCode);
    }

    public boolean isKeyReleased(int keyCode) {
        return keysReleased.contains(keyCode);
    }

    public boolean isMouseDown(int button) {
        return mouseDown.contains(button);
    }

    public boolean isMousePressed(int button) {
        return mousePressed.contains(button);
    }

    public boolean isMouseClicked(int button) {
        return mouseClicked.contains(button);
    }

    public int getMouseX() {
        return mouseX;
    }

    public int getMouseY() {
        return mouseY;
    }

    public int getMouseDeltaX() {
        return mouseDeltaX;
    }

    public int getMouseDeltaY() {
        return mouseDeltaY;
    }

    public int getMouseWheelDelta() {
        return mouseWheelDelta;
    }

    public int getMouseClickCount() {
        return mouseClickCount;
    }

    public float getSecondsSinceLastClick() {
        if (lastClickTimestamp == 0L) {
            return Float.MAX_VALUE;
        }
        return (System.nanoTime() - lastClickTimestamp) / 1_000_000_000f;
    }

    public Vector2 getMouseWorldPosition() {
        if (camera == null) {
            return new Vector2(mouseX, mouseY);
        }
        return camera.screenToWorld(mouseX, mouseY);
    }

    public Vector2 getMovementVector() {
        float dx = 0f;
        float dy = 0f;
        if (isKeyDown(KeyEvent.VK_W) || isKeyDown(KeyEvent.VK_UP)) {
            dy -= 1f;
        }
        if (isKeyDown(KeyEvent.VK_S) || isKeyDown(KeyEvent.VK_DOWN)) {
            dy += 1f;
        }
        if (isKeyDown(KeyEvent.VK_A) || isKeyDown(KeyEvent.VK_LEFT)) {
            dx -= 1f;
        }
        if (isKeyDown(KeyEvent.VK_D) || isKeyDown(KeyEvent.VK_RIGHT)) {
            dx += 1f;
        }
        if (dx == 0f && dy == 0f) {
            return new Vector2(0f, 0f);
        }
        float length = (float) Math.sqrt(dx * dx + dy * dy);
        return new Vector2(dx / length, dy / length);
    }

    @Override
    public void keyTyped(KeyEvent e) {}

    @Override
    public void keyPressed(KeyEvent e) {
        int code = e.getKeyCode();
        synchronized (lock) {
            if (!liveKeysDown.contains(code)) {
                pendingKeysPressed.add(code);
            }
            liveKeysDown.add(code);
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        int code = e.getKeyCode();
        synchronized (lock) {
            liveKeysDown.remove(code);
            pendingKeysReleased.add(code);
        }
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        synchronized (lock) {
            pendingMouseClicked.add(e.getButton());
            pendingMouseClickCount = e.getClickCount();
            pendingLastClickTimestamp = System.nanoTime();
            liveMouseX = e.getX();
            liveMouseY = e.getY();
        }
    }

    @Override
    public void mousePressed(MouseEvent e) {
        synchronized (lock) {
            liveMouseDown.add(e.getButton());
            pendingMousePressed.add(e.getButton());
            liveMouseX = e.getX();
            liveMouseY = e.getY();
        }
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        synchronized (lock) {
            liveMouseDown.remove(e.getButton());
            liveMouseX = e.getX();
            liveMouseY = e.getY();
        }
    }

    @Override
    public void mouseEntered(MouseEvent e) {}

    @Override
    public void mouseExited(MouseEvent e) {}

    @Override
    public void mouseDragged(MouseEvent e) {
        synchronized (lock) {
            liveMouseX = e.getX();
            liveMouseY = e.getY();
        }
    }

    @Override
    public void mouseMoved(MouseEvent e) {
        synchronized (lock) {
            liveMouseX = e.getX();
            liveMouseY = e.getY();
        }
    }

    @Override
    public void mouseWheelMoved(MouseWheelEvent e) {
        synchronized (lock) {
            pendingMouseWheelDelta += e.getWheelRotation();
        }
    }
}
