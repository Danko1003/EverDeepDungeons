package com.varcore.engine.collision;

import com.varcore.engine.math.Rect;

final class Raycasts {
    private Raycasts() {
    }

    static Float intersectAabb(float originX, float originY, float dirX, float dirY,
                               float maxDistance, Rect box) {
        float tMin = 0f;
        float tMax = maxDistance;

        if (Math.abs(dirX) > 1e-6f) {
            float tx1 = (box.x - originX) / dirX;
            float tx2 = (box.right() - originX) / dirX;
            tMin = Math.max(tMin, Math.min(tx1, tx2));
            tMax = Math.min(tMax, Math.max(tx1, tx2));
        } else if (originX < box.x || originX > box.right()) {
            return null;
        }

        if (Math.abs(dirY) > 1e-6f) {
            float ty1 = (box.y - originY) / dirY;
            float ty2 = (box.bottom() - originY) / dirY;
            tMin = Math.max(tMin, Math.min(ty1, ty2));
            tMax = Math.min(tMax, Math.max(ty1, ty2));
        } else if (originY < box.y || originY > box.bottom()) {
            return null;
        }

        if (tMax < tMin || tMin < 0 || tMin > maxDistance) {
            return null;
        }
        return tMin;
    }
}
