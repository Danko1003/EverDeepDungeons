package com.varcore.engine.collision;

public final class CollisionLayers {
    public static final int DEFAULT = 1;
    public static final int PLAYER = 1 << 1;
    public static final int WORLD = 1 << 2;
    public static final int PROJECTILE = 1 << 3;
    public static final int TRIGGER = 1 << 4;

    public static final int ALL = DEFAULT | PLAYER | WORLD | PROJECTILE | TRIGGER;

    private CollisionLayers() {
    }

    public static boolean canInteract(int layerA, int maskA, int layerB, int maskB) {
        return (layerA & maskB) != 0 && (layerB & maskA) != 0;
    }
}
