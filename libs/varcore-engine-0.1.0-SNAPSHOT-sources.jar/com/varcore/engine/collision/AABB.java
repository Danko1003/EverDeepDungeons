package com.varcore.engine.collision;

import com.varcore.engine.math.Rect;

public final class AABB {
    private final Rect bounds = new Rect();

    public AABB(float x, float y, float width, float height) {
        bounds.x = x;
        bounds.y = y;
        bounds.width = width;
        bounds.height = height;
    }

    public Rect getBounds() {
        return bounds;
    }

    public void setPosition(float x, float y) {
        bounds.x = x;
        bounds.y = y;
    }

    public void setSize(float width, float height) {
        bounds.width = width;
        bounds.height = height;
    }

    public boolean intersects(AABB other) {
        return bounds.intersects(other.bounds);
    }
}
