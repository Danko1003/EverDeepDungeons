package com.varcore.engine.collision;

import com.varcore.engine.component.Collider;
import com.varcore.engine.math.Rect;
import com.varcore.engine.scene.Scene;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public final class CollisionWorld {
    private final Map<Collider, Set<Collider>> touching = new HashMap<>();

    public void update(Scene scene, float dt) {
        List<Collider> colliders = collectColliders(scene);
        for (Collider collider : colliders) {
            collider.syncBounds();
        }

        detectContacts(colliders);
        resolveSolids(colliders);
        for (Collider collider : colliders) {
            collider.syncBounds();
        }
    }

    public CollisionHit raycast(Scene scene, float x0, float y0, float x1, float y1, int layerMask) {
        float dx = x1 - x0;
        float dy = y1 - y0;
        float maxDistance = (float) Math.sqrt(dx * dx + dy * dy);
        if (maxDistance < 1e-6f) {
            return null;
        }
        float dirX = dx / maxDistance;
        float dirY = dy / maxDistance;

        Collider closest = null;
        float closestDistance = maxDistance;

        for (Collider collider : collectColliders(scene)) {
            if (!matchesLayerMask(collider, layerMask)) {
                continue;
            }
            collider.syncBounds();
            Float hitDistance = Raycasts.intersectAabb(
                    x0, y0, dirX, dirY, maxDistance, collider.getBounds().getBounds());
            if (hitDistance != null && hitDistance < closestDistance) {
                closestDistance = hitDistance;
                closest = collider;
            }
        }

        if (closest == null) {
            return null;
        }
        return new CollisionHit(closest, x0 + dirX * closestDistance, y0 + dirY * closestDistance, closestDistance);
    }

    public List<Collider> overlapBox(Scene scene, float x, float y, float width, float height, int layerMask) {
        Rect query = new Rect(x, y, width, height);
        List<Collider> hits = new ArrayList<>();
        for (Collider collider : collectColliders(scene)) {
            if (!matchesLayerMask(collider, layerMask)) {
                continue;
            }
            collider.syncBounds();
            if (collider.getBounds().getBounds().intersects(query)) {
                hits.add(collider);
            }
        }
        return hits;
    }

    public Collider overlapPoint(Scene scene, float x, float y, int layerMask) {
        for (Collider collider : collectColliders(scene)) {
            if (!matchesLayerMask(collider, layerMask)) {
                continue;
            }
            collider.syncBounds();
            if (collider.getBounds().getBounds().contains(x, y)) {
                return collider;
            }
        }
        return null;
    }

    private void detectContacts(List<Collider> colliders) {
        Map<Collider, Set<Collider>> currentTouches = new HashMap<>();

        for (int i = 0; i < colliders.size(); i++) {
            Collider a = colliders.get(i);
            if (!a.isEnabled()) {
                continue;
            }
            for (int j = i + 1; j < colliders.size(); j++) {
                Collider b = colliders.get(j);
                if (!b.isEnabled() || !a.canCollideWith(b)) {
                    continue;
                }
                if (a.getBounds().intersects(b.getBounds())) {
                    currentTouches.computeIfAbsent(a, k -> new HashSet<>()).add(b);
                    currentTouches.computeIfAbsent(b, k -> new HashSet<>()).add(a);

                    Set<Collider> previous = touching.getOrDefault(a, Set.of());
                    if (!previous.contains(b)) {
                        a.onCollisionEnter(b);
                        b.onCollisionEnter(a);
                    } else {
                        a.onCollisionStay(b);
                        b.onCollisionStay(a);
                    }
                }
            }
        }

        for (Map.Entry<Collider, Set<Collider>> entry : touching.entrySet()) {
            Collider a = entry.getKey();
            for (Collider b : entry.getValue()) {
                Set<Collider> stillTouching = currentTouches.getOrDefault(a, Set.of());
                if (!stillTouching.contains(b)) {
                    a.onCollisionExit(b);
                    b.onCollisionExit(a);
                }
            }
        }

        touching.clear();
        touching.putAll(currentTouches);
    }

    private void resolveSolids(List<Collider> colliders) {
        for (int i = 0; i < colliders.size(); i++) {
            Collider a = colliders.get(i);
            if (!a.isEnabled()) {
                continue;
            }
            for (int j = i + 1; j < colliders.size(); j++) {
                Collider b = colliders.get(j);
                if (!b.isEnabled() || !a.canCollideWith(b)) {
                    continue;
                }
                if (a.getBounds().intersects(b.getBounds())) {
                    separate(a, b);
                }
            }
        }
    }

    private void separate(Collider a, Collider b) {
        if (!a.blocksMovement() && !b.blocksMovement()) {
            return;
        }
        if (a.isStatic() && b.isStatic()) {
            return;
        }

        Collider push = chooseMovable(a, b);
        if (push == null) {
            return;
        }
        Collider obstacle = push == a ? b : a;

        Rect pushRect = push.getBounds().getBounds();
        Rect obstacleRect = obstacle.getBounds().getBounds();
        float overlapX = Math.min(pushRect.right(), obstacleRect.right()) - Math.max(pushRect.x, obstacleRect.x);
        float overlapY = Math.min(pushRect.bottom(), obstacleRect.bottom()) - Math.max(pushRect.y, obstacleRect.y);
        if (overlapX <= 0 || overlapY <= 0) {
            return;
        }

        if (overlapX < overlapY) {
            float direction = (pushRect.x + pushRect.width * 0.5f) < (obstacleRect.x + obstacleRect.width * 0.5f)
                    ? -1f : 1f;
            push.getGameObject().getTransform().translate(direction * overlapX, 0);
        } else {
            float direction = (pushRect.y + pushRect.height * 0.5f) < (obstacleRect.y + obstacleRect.height * 0.5f)
                    ? -1f : 1f;
            push.getGameObject().getTransform().translate(0, direction * overlapY);
        }
        push.syncBounds();
    }

    private static Collider chooseMovable(Collider a, Collider b) {
        if (a.isStatic() && !b.isStatic()) {
            return b.blocksMovement() ? b : null;
        }
        if (b.isStatic() && !a.isStatic()) {
            return a.blocksMovement() ? a : null;
        }
        if (!a.isStatic() && a.blocksMovement()) {
            return a;
        }
        if (!b.isStatic() && b.blocksMovement()) {
            return b;
        }
        return null;
    }

    private static List<Collider> collectColliders(Scene scene) {
        List<Collider> colliders = new ArrayList<>();
        scene.getGameObjects().forEach(go ->
                go.getComponents().stream()
                        .filter(Collider.class::isInstance)
                        .map(Collider.class::cast)
                        .forEach(colliders::add));
        return colliders;
    }

    private static boolean matchesLayerMask(Collider collider, int layerMask) {
        return (collider.getLayer() & layerMask) != 0;
    }
}
