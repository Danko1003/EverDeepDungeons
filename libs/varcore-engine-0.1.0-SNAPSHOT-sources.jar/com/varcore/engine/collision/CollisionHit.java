package com.varcore.engine.collision;

import com.varcore.engine.component.Collider;

public record CollisionHit(Collider collider, float x, float y, float distance) {}
