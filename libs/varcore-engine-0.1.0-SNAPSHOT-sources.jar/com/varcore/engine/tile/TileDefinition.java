package com.varcore.engine.tile;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Metadata for one tile type in a {@link TileLibrary}. */
public final class TileDefinition {
    private final String id;
    private final String name;
    private final TileKind kind;
    private final int sheetX;
    private final int sheetY;
    private final int sheetWidth;
    private final int sheetHeight;
    private final boolean solid;
    private final boolean trigger;
    private final int renderLayer;
    private final int footprintWidth;
    private final int footprintHeight;
    private final int anchorCol;
    private final int anchorRow;
    private final TileAnchor placeAnchor;
    private final List<TilePartDefinition> parts;
    private final Set<String> tags;
    private final Map<String, String> properties;

    public TileDefinition(
            String id,
            String name,
            TileKind kind,
            int sheetX,
            int sheetY,
            int sheetWidth,
            int sheetHeight,
            boolean solid,
            boolean trigger,
            int renderLayer,
            int footprintWidth,
            int footprintHeight,
            int anchorCol,
            int anchorRow,
            TileAnchor placeAnchor,
            List<TilePartDefinition> parts,
            Set<String> tags,
            Map<String, String> properties) {
        this.id = id;
        this.name = name;
        this.kind = kind == null ? TileKind.SIMPLE : kind;
        this.sheetX = sheetX;
        this.sheetY = sheetY;
        this.sheetWidth = sheetWidth;
        this.sheetHeight = sheetHeight;
        this.solid = solid;
        this.trigger = trigger;
        this.renderLayer = renderLayer;
        this.footprintWidth = Math.max(1, footprintWidth);
        this.footprintHeight = Math.max(1, footprintHeight);
        this.anchorCol = anchorCol;
        this.anchorRow = anchorRow;
        this.placeAnchor = placeAnchor == null ? TileAnchor.TOP_LEFT : placeAnchor;
        this.parts = parts == null || parts.isEmpty()
                ? List.of(defaultPart(sheetX, sheetY, sheetWidth, sheetHeight, solid, trigger, renderLayer))
                : List.copyOf(parts);
        this.tags = Set.copyOf(tags);
        this.properties = Map.copyOf(properties);
    }

    private static TilePartDefinition defaultPart(
            int sx, int sy, int sw, int sh, boolean solid, boolean trigger, int renderLayer) {
        return TilePartDefinition.builder()
                .offset(0, 0)
                .sheetRect(sx, sy, sw, sh)
                .solid(solid)
                .trigger(trigger)
                .renderLayer(renderLayer)
                .build();
    }

    public String id() {
        return id;
    }

    public String name() {
        return name;
    }

    public TileKind kind() {
        return kind;
    }

    public boolean isCompound() {
        return kind == TileKind.COMPOUND;
    }

    public int sheetX() {
        return sheetX;
    }

    public int sheetY() {
        return sheetY;
    }

    public int sheetWidth() {
        return sheetWidth;
    }

    public int sheetHeight() {
        return sheetHeight;
    }

    public boolean solid() {
        return solid;
    }

    public boolean trigger() {
        return trigger;
    }

    public int renderLayer() {
        return renderLayer;
    }

    public int footprintWidth() {
        return footprintWidth;
    }

    public int footprintHeight() {
        return footprintHeight;
    }

    public int anchorCol() {
        return anchorCol;
    }

    public int anchorRow() {
        return anchorRow;
    }

    public TileAnchor placeAnchor() {
        return placeAnchor;
    }

    public List<TilePartDefinition> parts() {
        return parts;
    }

    public Set<String> tags() {
        return tags;
    }

    public Map<String, String> properties() {
        return properties;
    }

    public boolean hasTag(String tag) {
        return tags.contains(tag);
    }

    public String property(String key) {
        return properties.get(key);
    }

    /** Footprint origin column when this tile is placed at anchor cell (col, row). */
    public int footprintOriginCol(int anchorCellCol) {
        return anchorCellCol - anchorCol;
    }

    public int footprintOriginRow(int anchorCellRow) {
        return anchorCellRow - anchorRow;
    }

    public boolean footprintContains(int originCol, int originRow, int col, int row) {
        return col >= originCol && col < originCol + footprintWidth
                && row >= originRow && row < originRow + footprintHeight;
    }

    public boolean isSolidAt(int originCol, int originRow, int col, int row) {
        int localCol = col - originCol;
        int localRow = row - originRow;
        for (TilePartDefinition part : parts) {
            if (part.solid() && part.dx() == localCol && part.dy() == localRow) {
                return true;
            }
        }
        return false;
    }

    public static Builder builder(String id) {
        return new Builder(id);
    }

    public static final class Builder {
        private final String id;
        private String name;
        private TileKind kind = TileKind.SIMPLE;
        private int sheetX;
        private int sheetY;
        private int sheetWidth = 32;
        private int sheetHeight = 32;
        private boolean solid;
        private boolean trigger;
        private int renderLayer;
        private int footprintWidth = 1;
        private int footprintHeight = 1;
        private int anchorCol;
        private int anchorRow;
        private TileAnchor placeAnchor = TileAnchor.TOP_LEFT;
        private List<TilePartDefinition> parts = List.of();
        private final Set<String> tags = new HashSet<>();
        private final Map<String, String> properties = new HashMap<>();

        public Builder(String id) {
            this.id = id;
            this.name = id;
        }

        public Builder name(String name) {
            this.name = name;
            return this;
        }

        public Builder kind(TileKind kind) {
            this.kind = kind;
            return this;
        }

        public Builder sheetRect(int x, int y, int w, int h) {
            this.sheetX = x;
            this.sheetY = y;
            this.sheetWidth = w;
            this.sheetHeight = h;
            return this;
        }

        public Builder solid(boolean solid) {
            this.solid = solid;
            return this;
        }

        public Builder trigger(boolean trigger) {
            this.trigger = trigger;
            return this;
        }

        public Builder renderLayer(int renderLayer) {
            this.renderLayer = renderLayer;
            return this;
        }

        public Builder footprint(int width, int height) {
            this.footprintWidth = width;
            this.footprintHeight = height;
            return this;
        }

        public Builder anchorCell(int col, int row) {
            this.anchorCol = col;
            this.anchorRow = row;
            return this;
        }

        public Builder placeAnchor(TileAnchor anchor) {
            this.placeAnchor = anchor;
            return this;
        }

        public Builder parts(List<TilePartDefinition> parts) {
            this.parts = parts;
            return this;
        }

        public Builder tag(String tag) {
            tags.add(tag);
            return this;
        }

        public Builder property(String key, String value) {
            properties.put(key, value);
            return this;
        }

        public TileDefinition build() {
            return new TileDefinition(
                    id, name, kind, sheetX, sheetY, sheetWidth, sheetHeight,
                    solid, trigger, renderLayer,
                    footprintWidth, footprintHeight, anchorCol, anchorRow, placeAnchor,
                    parts, tags, properties);
        }
    }
}
