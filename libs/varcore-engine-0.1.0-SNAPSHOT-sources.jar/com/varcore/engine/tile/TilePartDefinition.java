package com.varcore.engine.tile;

/** One visual/collision slice of a compound tile, offset in grid cells from the footprint origin. */
public final class TilePartDefinition {
    private final int dx;
    private final int dy;
    private final int sheetX;
    private final int sheetY;
    private final int sheetWidth;
    private final int sheetHeight;
    private final boolean solid;
    private final boolean trigger;
    private final int renderLayer;

    public TilePartDefinition(
            int dx, int dy,
            int sheetX, int sheetY, int sheetWidth, int sheetHeight,
            boolean solid, boolean trigger, int renderLayer) {
        this.dx = dx;
        this.dy = dy;
        this.sheetX = sheetX;
        this.sheetY = sheetY;
        this.sheetWidth = sheetWidth;
        this.sheetHeight = sheetHeight;
        this.solid = solid;
        this.trigger = trigger;
        this.renderLayer = renderLayer;
    }

    public int dx() {
        return dx;
    }

    public int dy() {
        return dy;
    }

    public int sheetX() {
        return sheetX;
    }

    public int sheetY() {
        return sheetY;
    }

    public int sheetWidth() {
        return sheetWidth;
    }

    public int sheetHeight() {
        return sheetHeight;
    }

    public boolean solid() {
        return solid;
    }

    public boolean trigger() {
        return trigger;
    }

    public int renderLayer() {
        return renderLayer;
    }

    public static Builder builder() {
        return new Builder();
    }

    public static final class Builder {
        private int dx;
        private int dy;
        private int sheetX;
        private int sheetY;
        private int sheetWidth = 32;
        private int sheetHeight = 32;
        private boolean solid;
        private boolean trigger;
        private int renderLayer;

        public Builder offset(int dx, int dy) {
            this.dx = dx;
            this.dy = dy;
            return this;
        }

        public Builder sheetRect(int x, int y, int w, int h) {
            this.sheetX = x;
            this.sheetY = y;
            this.sheetWidth = w;
            this.sheetHeight = h;
            return this;
        }

        public Builder solid(boolean solid) {
            this.solid = solid;
            return this;
        }

        public Builder trigger(boolean trigger) {
            this.trigger = trigger;
            return this;
        }

        public Builder renderLayer(int renderLayer) {
            this.renderLayer = renderLayer;
            return this;
        }

        public TilePartDefinition build() {
            return new TilePartDefinition(dx, dy, sheetX, sheetY, sheetWidth, sheetHeight,
                    solid, trigger, renderLayer);
        }
    }
}
