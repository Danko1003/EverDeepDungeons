package com.varcore.engine.tile;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/** Catalog of tile definitions loaded from JSON or built in code. */
public final class TileLibrary {
    private final String id;
    private final String name;
    private final String tilesetPath;
    private final int defaultTileSize;
    private final Map<String, TileDefinition> tiles = new LinkedHashMap<>();

    public TileLibrary(String tilesetPath, int defaultTileSize) {
        this("", "", tilesetPath, defaultTileSize);
    }

    public TileLibrary(String id, String name, String tilesetPath, int defaultTileSize) {
        this.id = id;
        this.name = name;
        this.tilesetPath = tilesetPath;
        this.defaultTileSize = defaultTileSize;
    }

    public static TileLibrary fromJson(JsonObject root) {
        String id = root.has("id") ? root.get("id").getAsString() : "";
        String name = root.has("name") ? root.get("name").getAsString() : id;
        String tileset = root.has("tileset") ? root.get("tileset").getAsString() : "";
        int tileSize = root.has("tileSize") ? root.get("tileSize").getAsInt() : 32;
        TileLibrary library = new TileLibrary(id, name, tileset, tileSize);
        if (root.has("tiles") && root.get("tiles").isJsonArray()) {
            for (JsonElement el : root.getAsJsonArray("tiles")) {
                library.register(parseDefinition(el.getAsJsonObject(), tileSize));
            }
        }
        return library;
    }

    public JsonObject toJson() {
        JsonObject root = new JsonObject();
        if (!id.isBlank()) {
            root.addProperty("id", id);
        }
        if (!name.isBlank()) {
            root.addProperty("name", name);
        }
        root.addProperty("formatVersion", 1);
        root.addProperty("tileset", tilesetPath);
        root.addProperty("tileSize", defaultTileSize);
        JsonArray tileArray = new JsonArray();
        for (TileDefinition tile : tiles.values()) {
            tileArray.add(definitionToJson(tile));
        }
        root.add("tiles", tileArray);
        return root;
    }

    private static JsonObject definitionToJson(TileDefinition tile) {
        JsonObject obj = new JsonObject();
        obj.addProperty("id", tile.id());
        obj.addProperty("name", tile.name());
        if (tile.isCompound()) {
            obj.addProperty("kind", "compound");
            JsonObject footprint = new JsonObject();
            footprint.addProperty("w", tile.footprintWidth());
            footprint.addProperty("h", tile.footprintHeight());
            obj.add("footprint", footprint);
            JsonObject anchor = new JsonObject();
            anchor.addProperty("col", tile.anchorCol());
            anchor.addProperty("row", tile.anchorRow());
            anchor.addProperty("sub", tile.placeAnchor().name());
            obj.add("anchor", anchor);
            JsonArray parts = new JsonArray();
            for (TilePartDefinition part : tile.parts()) {
                parts.add(partToJson(part));
            }
            obj.add("parts", parts);
        } else {
            obj.addProperty("sx", tile.sheetX());
            obj.addProperty("sy", tile.sheetY());
            obj.addProperty("sw", tile.sheetWidth());
            obj.addProperty("sh", tile.sheetHeight());
        }
        if (tile.solid()) {
            obj.addProperty("solid", true);
        }
        if (tile.trigger()) {
            obj.addProperty("trigger", true);
        }
        if (tile.renderLayer() != 0) {
            obj.addProperty("renderLayer", tile.renderLayer());
        }
        if (!tile.tags().isEmpty()) {
            JsonArray tags = new JsonArray();
            tile.tags().forEach(tags::add);
            obj.add("tags", tags);
        }
        if (!tile.properties().isEmpty()) {
            JsonObject props = new JsonObject();
            tile.properties().forEach(props::addProperty);
            obj.add("properties", props);
        }
        return obj;
    }

    private static JsonObject partToJson(TilePartDefinition part) {
        JsonObject obj = new JsonObject();
        obj.addProperty("dx", part.dx());
        obj.addProperty("dy", part.dy());
        obj.addProperty("sx", part.sheetX());
        obj.addProperty("sy", part.sheetY());
        obj.addProperty("sw", part.sheetWidth());
        obj.addProperty("sh", part.sheetHeight());
        if (part.solid()) {
            obj.addProperty("solid", true);
        }
        if (part.trigger()) {
            obj.addProperty("trigger", true);
        }
        if (part.renderLayer() != 0) {
            obj.addProperty("renderLayer", part.renderLayer());
        }
        return obj;
    }

    private static TileDefinition parseDefinition(JsonObject obj, int defaultSize) {
        String id = obj.get("id").getAsString();
        TileKind kind = obj.has("kind") ? TileKind.fromString(obj.get("kind").getAsString()) : TileKind.SIMPLE;
        TileDefinition.Builder builder = TileDefinition.builder(id)
                .name(obj.has("name") ? obj.get("name").getAsString() : id)
                .kind(kind)
                .solid(obj.has("solid") && obj.get("solid").getAsBoolean())
                .trigger(obj.has("trigger") && obj.get("trigger").getAsBoolean())
                .renderLayer(obj.has("renderLayer") ? obj.get("renderLayer").getAsInt() : 0);

        if (kind == TileKind.COMPOUND) {
            if (obj.has("footprint") && obj.get("footprint").isJsonObject()) {
                JsonObject footprint = obj.getAsJsonObject("footprint");
                builder.footprint(
                        footprint.has("w") ? footprint.get("w").getAsInt() : 1,
                        footprint.has("h") ? footprint.get("h").getAsInt() : 1);
            }
            if (obj.has("anchor") && obj.get("anchor").isJsonObject()) {
                JsonObject anchor = obj.getAsJsonObject("anchor");
                builder.anchorCell(
                        anchor.has("col") ? anchor.get("col").getAsInt() : 0,
                        anchor.has("row") ? anchor.get("row").getAsInt() : 0);
                if (anchor.has("sub")) {
                    builder.placeAnchor(parseAnchor(anchor.get("sub").getAsString()));
                }
            }
            List<TilePartDefinition> parts = new ArrayList<>();
            if (obj.has("parts") && obj.get("parts").isJsonArray()) {
                for (JsonElement partEl : obj.getAsJsonArray("parts")) {
                    parts.add(parsePart(partEl.getAsJsonObject(), defaultSize));
                }
            }
            builder.parts(parts);
            if (!parts.isEmpty()) {
                TilePartDefinition first = parts.get(0);
                builder.sheetRect(first.sheetX(), first.sheetY(), first.sheetWidth(), first.sheetHeight());
            }
        } else {
            int sw = obj.has("sw") ? obj.get("sw").getAsInt() : defaultSize;
            int sh = obj.has("sh") ? obj.get("sh").getAsInt() : defaultSize;
            int sx = obj.has("sx") ? obj.get("sx").getAsInt() : 0;
            int sy = obj.has("sy") ? obj.get("sy").getAsInt() : 0;
            builder.sheetRect(sx, sy, sw, sh);
        }

        if (obj.has("tags") && obj.get("tags").isJsonArray()) {
            for (JsonElement tag : obj.getAsJsonArray("tags")) {
                builder.tag(tag.getAsString());
            }
        }
        if (obj.has("properties") && obj.get("properties").isJsonObject()) {
            for (var entry : obj.getAsJsonObject("properties").entrySet()) {
                builder.property(entry.getKey(), entry.getValue().getAsString());
            }
        }
        return builder.build();
    }

    private static TilePartDefinition parsePart(JsonObject obj, int defaultSize) {
        TilePartDefinition.Builder builder = TilePartDefinition.builder()
                .offset(obj.has("dx") ? obj.get("dx").getAsInt() : 0,
                        obj.has("dy") ? obj.get("dy").getAsInt() : 0)
                .solid(obj.has("solid") && obj.get("solid").getAsBoolean())
                .trigger(obj.has("trigger") && obj.get("trigger").getAsBoolean())
                .renderLayer(obj.has("renderLayer") ? obj.get("renderLayer").getAsInt() : 0);
        int sw = obj.has("sw") ? obj.get("sw").getAsInt() : defaultSize;
        int sh = obj.has("sh") ? obj.get("sh").getAsInt() : defaultSize;
        int sx = obj.has("sx") ? obj.get("sx").getAsInt() : 0;
        int sy = obj.has("sy") ? obj.get("sy").getAsInt() : 0;
        return builder.sheetRect(sx, sy, sw, sh).build();
    }

    private static TileAnchor parseAnchor(String value) {
        if (value == null || value.isBlank()) {
            return TileAnchor.TOP_LEFT;
        }
        try {
            return TileAnchor.valueOf(value.toUpperCase());
        } catch (IllegalArgumentException ex) {
            return TileAnchor.TOP_LEFT;
        }
    }

    public void register(TileDefinition definition) {
        tiles.put(definition.id(), definition);
    }

    public Optional<TileDefinition> get(String id) {
        if (id == null || id.isBlank()) {
            return Optional.empty();
        }
        return Optional.ofNullable(tiles.get(id));
    }

    public TileDefinition require(String id) {
        return get(id).orElseThrow(() -> new IllegalArgumentException("Unknown tile id: " + id));
    }

    public Collection<TileDefinition> all() {
        return Collections.unmodifiableCollection(tiles.values());
    }

    public String id() {
        return id;
    }

    public String name() {
        return name;
    }

    public String tilesetPath() {
        return tilesetPath;
    }

    public int defaultTileSize() {
        return defaultTileSize;
    }

    public boolean isEmpty() {
        return tiles.isEmpty();
    }
}
