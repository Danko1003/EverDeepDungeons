package com.varcore.engine.tile;

public record TileCoord(int col, int row) {
    public static TileCoord of(int col, int row) {
        return new TileCoord(col, row);
    }

    public TileCoord neighbor(int dCol, int dRow) {
        return new TileCoord(col + dCol, row + dRow);
    }

    public int manhattanDistance(TileCoord other) {
        return Math.abs(col - other.col) + Math.abs(row - other.row);
    }
}
