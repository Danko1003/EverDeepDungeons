package com.varcore.engine.tile;

/** Anchor point within a tile cell for objects, props, and spawn markers. */
public enum TileAnchor {
    TOP_LEFT(0f, 0f),
    TOP_CENTER(0.5f, 0f),
    TOP_RIGHT(1f, 0f),
    CENTER(0.5f, 0.5f),
    BOTTOM_LEFT(0f, 1f),
    BOTTOM_CENTER(0.5f, 1f),
    BOTTOM_RIGHT(1f, 1f);

    private final float u;
    private final float v;

    TileAnchor(float u, float v) {
        this.u = u;
        this.v = v;
    }

    public float u() {
        return u;
    }

    public float v() {
        return v;
    }
}
