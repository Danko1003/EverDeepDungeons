package com.varcore.engine.tile;

import com.varcore.engine.camera.Camera;
import com.varcore.engine.math.Rect;
import com.varcore.engine.math.Vector2;
import com.varcore.engine.render.Renderer;
import java.awt.Color;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.BiConsumer;

/** Flexible multi-layer tile grid with anchoring, queries, and rendering. */
public final class TileMap {
    public static final String LAYER_TERRAIN = "terrain";
    public static final String LAYER_PROPS = "props";
    public static final String LAYER_META = "metadata";

    private final Map<String, TileLayer> layers = new LinkedHashMap<>();
    private final List<TileAnchorBinding> anchors = new ArrayList<>();
    private float originX;
    private float originY;
    private float tileWidth = 32f;
    private float tileHeight = 32f;

    public TileMap(int width, int height) {
        addLayer(LAYER_TERRAIN, width, height);
    }

    public TileLayer addLayer(String name, int width, int height) {
        TileLayer layer = new TileLayer(name, width, height);
        layers.put(name, layer);
        return layer;
    }

    public Optional<TileLayer> layer(String name) {
        return Optional.ofNullable(layers.get(name));
    }

    public TileLayer requireLayer(String name) {
        return layer(name).orElseThrow(() -> new IllegalArgumentException("Unknown layer: " + name));
    }

    public List<String> layerNames() {
        return List.copyOf(layers.keySet());
    }

    public void setOrigin(float x, float y) {
        originX = x;
        originY = y;
    }

    public float originX() {
        return originX;
    }

    public float originY() {
        return originY;
    }

    public void setTileSize(float width, float height) {
        tileWidth = width;
        tileHeight = height;
    }

    public float tileWidth() {
        return tileWidth;
    }

    public float tileHeight() {
        return tileHeight;
    }

    public int width() {
        return requireLayer(LAYER_TERRAIN).width();
    }

    public int height() {
        return requireLayer(LAYER_TERRAIN).height();
    }

    /** Resizes every layer to the same width and height (clears cell data). */
    public void resize(int width, int height) {
        if (layers.isEmpty()) {
            addLayer(LAYER_TERRAIN, width, height);
            return;
        }
        for (String name : layerNames()) {
            layers.put(name, new TileLayer(name, width, height));
        }
    }

    public void setTile(String layerName, int col, int row, String tileId) {
        requireLayer(layerName).set(col, row, tileId);
    }

    public String getTile(String layerName, int col, int row) {
        return requireLayer(layerName).get(col, row);
    }

    public TileCoord worldToTile(float worldX, float worldY) {
        int col = (int) Math.floor((worldX - originX) / tileWidth);
        int row = (int) Math.floor((worldY - originY) / tileHeight);
        return TileCoord.of(col, row);
    }

    public Vector2 tileToWorld(int col, int row) {
        return tileToWorld(col, row, TileAnchor.TOP_LEFT);
    }

    public Vector2 tileToWorld(int col, int row, TileAnchor anchor) {
        float x = originX + col * tileWidth + tileWidth * anchor.u();
        float y = originY + row * tileHeight + tileHeight * anchor.v();
        return new Vector2(x, y);
    }

    public Rect tileBounds(int col, int row) {
        return new Rect(originX + col * tileWidth, originY + row * tileHeight, tileWidth, tileHeight);
    }

    public void addAnchor(TileAnchorBinding binding) {
        anchors.add(binding);
    }

    public List<TileAnchorBinding> anchors() {
        return List.copyOf(anchors);
    }

    public void clearAnchors() {
        anchors.clear();
    }

    public Vector2 anchorWorldPosition(TileAnchorBinding binding) {
        Vector2 base = tileToWorld(binding.tile().col(), binding.tile().row(), binding.anchor());
        base.add(binding.pixelOffset().x, binding.pixelOffset().y);
        return base;
    }

    public TileQueryResult queryWorld(float worldX, float worldY, TileLibrary library) {
        TileCoord coord = worldToTile(worldX, worldY);
        return queryTile(coord.col(), coord.row(), library);
    }

    public TileQueryResult queryTile(int col, int row, TileLibrary library) {
        Vector2 center = tileToWorld(col, row, TileAnchor.CENTER);
        TileQueryResult result = new TileQueryResult(TileCoord.of(col, row), center);
        for (TileLayer layer : layers.values()) {
            if (!layer.inBounds(col, row)) {
                continue;
            }
            collectHitsAtCell(layer, col, row, library, result);
        }
        for (TileAnchorBinding binding : anchors) {
            if (binding.tile().col() == col && binding.tile().row() == row) {
                result.addAnchor(binding);
            }
        }
        return result;
    }

    private void collectHitsAtCell(TileLayer layer, int col, int row, TileLibrary library, TileQueryResult result) {
        String directId = layer.get(col, row);
        if (directId != null && !directId.isBlank()) {
            TileDefinition def = library.get(directId).orElse(null);
            result.addLayerHit(layer.name(), directId, def, col, row);
        }
        int maxFootprint = maxFootprint(library);
        for (int scanRow = row - maxFootprint + 1; scanRow <= row; scanRow++) {
            for (int scanCol = col - maxFootprint + 1; scanCol <= col; scanCol++) {
                if (!layer.inBounds(scanCol, scanRow)) {
                    continue;
                }
                String tileId = layer.get(scanCol, scanRow);
                if (tileId == null || tileId.isBlank()) {
                    continue;
                }
                TileDefinition def = library.get(tileId).orElse(null);
                if (def == null || !def.isCompound()) {
                    continue;
                }
                int originCol = def.footprintOriginCol(scanCol);
                int originRow = def.footprintOriginRow(scanRow);
                if (!def.footprintContains(originCol, originRow, col, row)) {
                    continue;
                }
                if (scanCol == col && scanRow == row && tileId.equals(directId)) {
                    continue;
                }
                result.addLayerHit(layer.name(), tileId, def, col, row, scanCol, scanRow);
            }
        }
    }

    private static int maxFootprint(TileLibrary library) {
        int max = 1;
        for (TileDefinition def : library.all()) {
            max = Math.max(max, Math.max(def.footprintWidth(), def.footprintHeight()));
        }
        return max;
    }

    /** Places a tile at the anchor cell. Compound tiles only write the anchor cell. */
    public void placeTile(String layerName, int anchorCol, int anchorRow, String tileId, TileLibrary library) {
        requireLayer(layerName).set(anchorCol, anchorRow, tileId);
        TileDefinition def = library.get(tileId).orElse(null);
        if (def == null || !def.isCompound()) {
            return;
        }
        int originCol = def.footprintOriginCol(anchorCol);
        int originRow = def.footprintOriginRow(anchorRow);
        TileLayer layer = requireLayer(layerName);
        for (int row = originRow; row < originRow + def.footprintHeight(); row++) {
            for (int col = originCol; col < originCol + def.footprintWidth(); col++) {
                if (col == anchorCol && row == anchorRow) {
                    continue;
                }
                if (layer.inBounds(col, row)) {
                    layer.set(col, row, null);
                }
            }
        }
    }

    public boolean isSolid(int col, int row, TileLibrary library) {
        return queryTile(col, row, library).isSolid();
    }

    public void forEachVisibleTile(Camera camera, BiConsumer<TileLayer, TileCoord> visitor) {
        Rect view = camera.getViewBounds();
        int margin = 2;
        int minCol = (int) Math.floor((view.x - originX) / tileWidth) - margin;
        int minRow = (int) Math.floor((view.y - originY) / tileHeight) - margin;
        int maxCol = (int) Math.ceil((view.right() - originX) / tileWidth) + margin;
        int maxRow = (int) Math.ceil((view.bottom() - originY) / tileHeight) + margin;
        for (TileLayer layer : layers.values()) {
            for (int row = minRow; row <= maxRow; row++) {
                for (int col = minCol; col <= maxCol; col++) {
                    if (!layer.inBounds(col, row)) {
                        continue;
                    }
                    if (layer.get(col, row) != null) {
                        visitor.accept(layer, TileCoord.of(col, row));
                    }
                }
            }
        }
    }

    public void render(Renderer renderer, TileLibrary library, BufferedImage tileset, Camera camera) {
        java.util.HashSet<String> renderedCompounds = new java.util.HashSet<>();
        forEachVisibleTile(camera, (layer, coord) -> {
            String tileId = layer.get(coord.col(), coord.row());
            if (tileId == null) {
                return;
            }
            TileDefinition def = library.get(tileId).orElse(null);
            if (def != null && def.isCompound()) {
                String key = layer.name() + ":" + coord.col() + "," + coord.row();
                if (!renderedCompounds.add(key)) {
                    return;
                }
                renderCompoundTile(renderer, tileset, def, coord.col(), coord.row(), layer.name());
                return;
            }
            renderSimpleTile(renderer, tileset, def, tileId, coord.col(), coord.row());
        });
    }

    private void renderSimpleTile(Renderer renderer, BufferedImage tileset, TileDefinition def,
                                  String tileId, int col, int row) {
        float x = originX + col * tileWidth;
        float y = originY + row * tileHeight;
        int renderLayer = def == null ? 0 : def.renderLayer();
        if (tileset != null && def != null) {
            renderer.drawSpriteRegion(
                    tileset,
                    def.sheetX(), def.sheetY(), def.sheetWidth(), def.sheetHeight(),
                    x, y, tileWidth, tileHeight,
                    renderLayer);
        } else {
            renderer.drawRect(x, y, tileWidth, tileHeight, colorForTile(tileId, def), true, renderLayer);
        }
    }

    private void renderCompoundTile(Renderer renderer, BufferedImage tileset, TileDefinition def,
                                    int anchorCol, int anchorRow, String layerName) {
        int originCol = def.footprintOriginCol(anchorCol);
        int originRow = def.footprintOriginRow(anchorRow);
        for (TilePartDefinition part : def.parts()) {
            float x = originX + (originCol + part.dx()) * tileWidth;
            float y = originY + (originRow + part.dy()) * tileHeight;
            float drawW = part.sheetWidth();
            float drawH = part.sheetHeight();
            if (tileset != null) {
                renderer.drawSpriteRegion(
                        tileset,
                        part.sheetX(), part.sheetY(), part.sheetWidth(), part.sheetHeight(),
                        x, y, drawW, drawH,
                        part.renderLayer());
            } else {
                renderer.drawRect(x, y, drawW, drawH, colorForTile(def.id(), def), true, part.renderLayer());
            }
        }
    }

    public void renderAnchors(Renderer renderer, Color color) {
        for (TileAnchorBinding binding : anchors) {
            Vector2 pos = anchorWorldPosition(binding);
            renderer.drawCircle(pos.x, pos.y, 6f, color, true, 5);
        }
    }

    private static Color colorForTile(String tileId, TileDefinition def) {
        if (def != null && def.hasTag("water")) {
            return new Color(0x5B, 0x8C, 0xFF);
        }
        if (def != null && def.solid()) {
            return new Color(0x6B, 0x6B, 0x6B);
        }
        return switch (tileId) {
            case "grass" -> new Color(0x3D, 0xDC, 0x84);
            case "dirt" -> new Color(0x8B, 0x6B, 0x4A);
            case "stone" -> new Color(0x7A, 0x7A, 0x7A);
            case "water" -> new Color(0x5B, 0x8C, 0xFF);
            case "tree" -> new Color(0x1B, 0x4D, 0x3E);
            case "chest" -> new Color(0xFF, 0xD9, 0x3D);
            default -> new Color(0x2A, 0x5C, 0x44);
        };
    }
}
