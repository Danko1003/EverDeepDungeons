package com.varcore.engine.tile;

import java.util.Random;

/**
 * Cellular-automata world evolution — good for caves, islands, and organic terrain.
 * Run {@link #evolve(TileMap, TileLibrary, int)} multiple times to watch the map change.
 */
public final class CellularEvolutionGenerator implements WorldGenerator {
    private final String floorId;
    private final String wallId;
    private final float initialWallChance;
    private final int birthLimit;
    private final int deathLimit;

    public CellularEvolutionGenerator(String floorId, String wallId) {
        this(floorId, wallId, 0.48f, 5, 4);
    }

    public CellularEvolutionGenerator(
            String floorId,
            String wallId,
            float initialWallChance,
            int birthLimit,
            int deathLimit) {
        this.floorId = floorId;
        this.wallId = wallId;
        this.initialWallChance = initialWallChance;
        this.birthLimit = birthLimit;
        this.deathLimit = deathLimit;
    }

    @Override
    public void generate(TileMap map, TileLibrary library, long seed) {
        Random random = new Random(seed);
        TileLayer terrain = map.requireLayer(TileMap.LAYER_TERRAIN);
        for (int row = 0; row < terrain.height(); row++) {
            for (int col = 0; col < terrain.width(); col++) {
                boolean wall = random.nextFloat() < initialWallChance;
                terrain.set(col, row, wall ? wallId : floorId);
            }
        }
        smooth(map, 4);
    }

    public void evolve(TileMap map, TileLibrary library, int steps) {
        for (int i = 0; i < steps; i++) {
            step(map);
        }
    }

    private void step(TileMap map) {
        TileLayer terrain = map.requireLayer(TileMap.LAYER_TERRAIN);
        boolean[][] next = new boolean[terrain.width()][terrain.height()];
        for (int row = 0; row < terrain.height(); row++) {
            for (int col = 0; col < terrain.width(); col++) {
                int walls = countWallNeighbors(terrain, col, row);
                boolean currentWall = wallId.equals(terrain.get(col, row));
                if (currentWall) {
                    next[col][row] = walls >= deathLimit;
                } else {
                    next[col][row] = walls >= birthLimit;
                }
            }
        }
        for (int row = 0; row < terrain.height(); row++) {
            for (int col = 0; col < terrain.width(); col++) {
                terrain.set(col, row, next[col][row] ? wallId : floorId);
            }
        }
    }

    private void smooth(TileMap map, int steps) {
        for (int i = 0; i < steps; i++) {
            step(map);
        }
    }

    private int countWallNeighbors(TileLayer terrain, int col, int row) {
        int count = 0;
        for (int dy = -1; dy <= 1; dy++) {
            for (int dx = -1; dx <= 1; dx++) {
                if (dx == 0 && dy == 0) {
                    continue;
                }
                int nc = col + dx;
                int nr = row + dy;
                if (!terrain.inBounds(nc, nr)) {
                    count++;
                    continue;
                }
                if (wallId.equals(terrain.get(nc, nr))) {
                    count++;
                }
            }
        }
        return count;
    }
}
