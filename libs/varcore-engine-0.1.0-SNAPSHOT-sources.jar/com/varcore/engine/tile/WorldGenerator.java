package com.varcore.engine.tile;

/** Generates or evolves tile layers inside a {@link TileMap}. */
public interface WorldGenerator {
    void generate(TileMap map, TileLibrary library, long seed);
}
