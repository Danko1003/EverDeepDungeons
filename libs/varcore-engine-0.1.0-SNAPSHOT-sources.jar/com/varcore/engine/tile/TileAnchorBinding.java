package com.varcore.engine.tile;

import com.varcore.engine.math.Vector2;
import java.util.Objects;

/** Binds a logical object id to a tile cell with a sub-tile anchor. */
public final class TileAnchorBinding {
    private final String objectId;
    private final TileCoord tile;
    private final TileAnchor anchor;
    private final String layerHint;
    private final Vector2 pixelOffset = new Vector2();

    public TileAnchorBinding(String objectId, TileCoord tile, TileAnchor anchor) {
        this(objectId, tile, anchor, null);
    }

    public TileAnchorBinding(String objectId, TileCoord tile, TileAnchor anchor, String layerHint) {
        this.objectId = Objects.requireNonNull(objectId);
        this.tile = Objects.requireNonNull(tile);
        this.anchor = anchor == null ? TileAnchor.CENTER : anchor;
        this.layerHint = layerHint;
    }

    public String objectId() {
        return objectId;
    }

    public TileCoord tile() {
        return tile;
    }

    public TileAnchor anchor() {
        return anchor;
    }

    public String layerHint() {
        return layerHint;
    }

    public Vector2 pixelOffset() {
        return pixelOffset;
    }

    public TileAnchorBinding withOffset(float x, float y) {
        pixelOffset.set(x, y);
        return this;
    }
}
