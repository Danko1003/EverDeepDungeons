package com.varcore.engine.tile;

import java.util.Arrays;

/** One named tile layer (terrain, props, metadata, etc.). */
public final class TileLayer {
    private final String name;
    private final int width;
    private final int height;
    private final String[] cells;

    public TileLayer(String name, int width, int height) {
        this.name = name;
        this.width = width;
        this.height = height;
        this.cells = new String[width * height];
    }

    public String name() {
        return name;
    }

    public int width() {
        return width;
    }

    public int height() {
        return height;
    }

    public boolean inBounds(int col, int row) {
        return col >= 0 && row >= 0 && col < width && row < height;
    }

    public String get(int col, int row) {
        if (!inBounds(col, row)) {
            return null;
        }
        return cells[index(col, row)];
    }

    public void set(int col, int row, String tileId) {
        if (!inBounds(col, row)) {
            return;
        }
        cells[index(col, row)] = tileId;
    }

    public void fill(String tileId) {
        Arrays.fill(cells, tileId);
    }

    public void clear() {
        Arrays.fill(cells, null);
    }

    private int index(int col, int row) {
        return row * width + col;
    }
}
