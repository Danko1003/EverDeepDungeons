package com.varcore.engine.tile;

public enum TileKind {
    SIMPLE,
    COMPOUND;

    public static TileKind fromString(String value) {
        if (value == null || value.isBlank()) {
            return SIMPLE;
        }
        try {
            return TileKind.valueOf(value.toUpperCase());
        } catch (IllegalArgumentException ex) {
            return SIMPLE;
        }
    }
}
