package com.varcore.engine.tile;

import com.varcore.engine.math.Vector2;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

/** Result of querying tile data at a world position or cell. */
public final class TileQueryResult {
    private final TileCoord coord;
    private final Vector2 worldPosition;
    private final List<LayerHit> layerHits = new ArrayList<>();
    private final List<TileAnchorBinding> anchors = new ArrayList<>();

    public TileQueryResult(TileCoord coord, Vector2 worldPosition) {
        this.coord = coord;
        this.worldPosition = worldPosition.copy();
    }

    public void addLayerHit(String layerName, String tileId, TileDefinition definition, int queryCol, int queryRow) {
        layerHits.add(new LayerHit(layerName, tileId, definition, queryCol, queryRow, queryCol, queryRow));
    }

    public void addLayerHit(String layerName, String tileId, TileDefinition definition,
                            int queryCol, int queryRow, int anchorCol, int anchorRow) {
        layerHits.add(new LayerHit(layerName, tileId, definition, queryCol, queryRow, anchorCol, anchorRow));
    }

    public void addAnchor(TileAnchorBinding binding) {
        anchors.add(binding);
    }

    public TileCoord coord() {
        return coord;
    }

    public Vector2 worldPosition() {
        return worldPosition;
    }

    public List<LayerHit> layerHits() {
        return Collections.unmodifiableList(layerHits);
    }

    public List<TileAnchorBinding> anchors() {
        return Collections.unmodifiableList(anchors);
    }

    public boolean isSolid() {
        return layerHits.stream().anyMatch(TileQueryResult::hitIsSolid);
    }

    private static boolean hitIsSolid(LayerHit hit) {
        if (hit.definition() == null) {
            return false;
        }
        TileDefinition def = hit.definition();
        if (!def.isCompound()) {
            return def.solid();
        }
        return def.isSolidAt(
                def.footprintOriginCol(hit.anchorCol()),
                def.footprintOriginRow(hit.anchorRow()),
                hit.queryCol(),
                hit.queryRow());
    }

    public boolean hasTag(String tag) {
        return layerHits.stream().anyMatch(hit -> hit.definition() != null && hit.definition().hasTag(tag));
    }

    public Optional<LayerHit> firstLayer(String layerName) {
        return layerHits.stream().filter(hit -> hit.layerName().equals(layerName)).findFirst();
    }

    public Optional<TileDefinition> topDefinition() {
        for (int i = layerHits.size() - 1; i >= 0; i--) {
            TileDefinition def = layerHits.get(i).definition();
            if (def != null) {
                return Optional.of(def);
            }
        }
        return Optional.empty();
    }

    public record LayerHit(String layerName, String tileId, TileDefinition definition,
                           int queryCol, int queryRow, int anchorCol, int anchorRow) {}
}
