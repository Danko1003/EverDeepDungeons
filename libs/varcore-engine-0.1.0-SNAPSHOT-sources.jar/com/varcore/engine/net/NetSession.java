package com.varcore.engine.net;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Active multiplayer session state owned by {@link NetworkManager}. */
public final class NetSession {
    private NetRole role = NetRole.NONE;
    private int localPeerId = -1;
    private String roomCode = "";
    private String gameName = "VarCore Game";
    private final Map<Integer, NetPeer> peers = new LinkedHashMap<>();

    public NetRole role() {
        return role;
    }

    public void setRole(NetRole role) {
        this.role = role == null ? NetRole.NONE : role;
    }

    public boolean isActive() {
        return role != NetRole.NONE;
    }

    public boolean isHost() {
        return role == NetRole.HOST || role == NetRole.DEDICATED;
    }

    public boolean isClient() {
        return role == NetRole.CLIENT;
    }

    public int localPeerId() {
        return localPeerId;
    }

    public void setLocalPeerId(int localPeerId) {
        this.localPeerId = localPeerId;
    }

    public String roomCode() {
        return roomCode;
    }

    public void setRoomCode(String roomCode) {
        this.roomCode = roomCode == null ? "" : roomCode;
    }

    public String gameName() {
        return gameName;
    }

    public void setGameName(String gameName) {
        this.gameName = gameName == null || gameName.isBlank() ? "VarCore Game" : gameName;
    }

    public NetPeer peer(int id) {
        return peers.get(id);
    }

    public Collection<NetPeer> peers() {
        return Collections.unmodifiableCollection(peers.values());
    }

    public List<NetPeer> remotePeers() {
        List<NetPeer> list = new ArrayList<>();
        for (NetPeer peer : peers.values()) {
            if (peer.id() != localPeerId) {
                list.add(peer);
            }
        }
        return list;
    }

    public void putPeer(NetPeer peer) {
        if (peer != null) {
            peers.put(peer.id(), peer);
        }
    }

    public NetPeer removePeer(int id) {
        return peers.remove(id);
    }

    public void clearPeers() {
        peers.clear();
    }

    public int peerCount() {
        return peers.size();
    }

    public void reset() {
        role = NetRole.NONE;
        localPeerId = -1;
        roomCode = "";
        peers.clear();
    }
}
