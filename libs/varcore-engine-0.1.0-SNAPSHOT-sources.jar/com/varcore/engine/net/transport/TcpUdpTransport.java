package com.varcore.engine.net.transport;

import com.varcore.engine.net.NetProtocol;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * TCP for reliable frames + UDP for unreliable state.
 * Host local peer id is always 1; clients receive ids from WELCOME.
 */
public final class TcpUdpTransport implements NetTransport {
    private final AtomicBoolean open = new AtomicBoolean();
    private final AtomicInteger nextPeerId = new AtomicInteger(2);
    private final ConcurrentLinkedQueue<Inbound> inbound = new ConcurrentLinkedQueue<>();
    private final Map<Integer, PeerLink> peers = new ConcurrentHashMap<>();
    private final Map<String, Integer> udpKeyToPeer = new ConcurrentHashMap<>();

    private ServerSocket serverSocket;
    private DatagramSocket udpSocket;
    private Thread acceptThread;
    private Thread udpThread;
    private volatile boolean hosting;
    private volatile int localPeerId = 1;
    private volatile InetAddress remoteUdpAddress;
    private volatile int remoteUdpPort;

    public int localPeerId() {
        return localPeerId;
    }

    public void setLocalPeerId(int localPeerId) {
        this.localPeerId = localPeerId;
    }

    @Override
    public void host(int tcpPort, int udpPort) throws IOException {
        close();
        hosting = true;
        localPeerId = 1;
        nextPeerId.set(2);
        serverSocket = new ServerSocket();
        serverSocket.setReuseAddress(true);
        serverSocket.bind(new InetSocketAddress(tcpPort));
        udpSocket = new DatagramSocket(null);
        udpSocket.setReuseAddress(true);
        udpSocket.bind(new InetSocketAddress(udpPort));
        open.set(true);
        acceptThread = new Thread(this::acceptLoop, "varcore-net-accept");
        acceptThread.setDaemon(true);
        acceptThread.start();
        startUdp();
    }

    @Override
    public void connect(String host, int tcpPort, int udpPort) throws IOException {
        close();
        hosting = false;
        Socket socket = new Socket();
        socket.connect(new InetSocketAddress(host, tcpPort), 5000);
        socket.setTcpNoDelay(true);
        udpSocket = new DatagramSocket();
        remoteUdpAddress = InetAddress.getByName(host);
        remoteUdpPort = udpPort;
        open.set(true);
        PeerLink link = new PeerLink(1, socket); // host is peer 1
        peers.put(1, link);
        startReader(link);
        startUdp();
    }

    public void rebindPeer(int oldId, int newId) {
        PeerLink link = peers.remove(oldId);
        if (link != null) {
            link.peerId = newId;
            peers.put(newId, link);
        }
    }

    public int allocatePeerId() {
        return nextPeerId.getAndIncrement();
    }

    public void registerUdpEndpoint(int peerId, InetAddress address, int port) {
        if (address == null) {
            return;
        }
        udpKeyToPeer.put(key(address, port), peerId);
        PeerLink link = peers.get(peerId);
        if (link != null) {
            link.udpAddress = address;
            link.udpPort = port;
            link.udpLearned = true;
        }
    }

    public PeerLink peerLink(int peerId) {
        return peers.get(peerId);
    }

    @Override
    public void sendReliable(int peerId, byte type, byte channel, byte[] payload) throws IOException {
        PeerLink link = peers.get(peerId);
        if (link == null || !open.get()) {
            return;
        }
        byte[] frame = NetProtocol.encode(type, NetProtocol.FLAG_RELIABLE, channel, payload);
        synchronized (link.out) {
            link.out.write(frame);
            link.out.flush();
        }
    }

    @Override
    public void sendUnreliable(int peerId, byte type, byte channel, byte[] payload) throws IOException {
        if (udpSocket == null || !open.get()) {
            sendReliable(peerId, type, channel, payload);
            return;
        }
        byte[] frame = NetProtocol.encode(type, (byte) 0, channel, payload);
        if (hosting) {
            PeerLink link = peers.get(peerId);
            if (link == null || link.udpAddress == null || !link.udpLearned) {
                sendReliable(peerId, type, channel, payload);
                return;
            }
            udpSocket.send(new DatagramPacket(frame, frame.length, link.udpAddress, link.udpPort));
        } else if (remoteUdpAddress != null) {
            udpSocket.send(new DatagramPacket(frame, frame.length, remoteUdpAddress, remoteUdpPort));
        } else {
            sendReliable(peerId, type, channel, payload);
        }
    }

    @Override
    public void broadcastReliable(byte type, byte channel, byte[] payload, int exceptPeerId) throws IOException {
        for (Integer id : new ArrayList<>(peers.keySet())) {
            if (id != exceptPeerId) {
                sendReliable(id, type, channel, payload);
            }
        }
    }

    @Override
    public void broadcastUnreliable(byte type, byte channel, byte[] payload, int exceptPeerId) throws IOException {
        for (Integer id : new ArrayList<>(peers.keySet())) {
            if (id != exceptPeerId) {
                sendUnreliable(id, type, channel, payload);
            }
        }
    }

    @Override
    public List<Inbound> poll() {
        List<Inbound> list = new ArrayList<>();
        Inbound item;
        while ((item = inbound.poll()) != null) {
            list.add(item);
        }
        return list;
    }

    @Override
    public boolean isOpen() {
        return open.get();
    }

    @Override
    public void close() {
        open.set(false);
        hosting = false;
        if (acceptThread != null) {
            acceptThread.interrupt();
        }
        if (udpThread != null) {
            udpThread.interrupt();
        }
        for (PeerLink link : peers.values()) {
            try {
                link.socket.close();
            } catch (IOException ignored) {
            }
        }
        peers.clear();
        udpKeyToPeer.clear();
        inbound.clear();
        if (serverSocket != null) {
            try {
                serverSocket.close();
            } catch (IOException ignored) {
            }
            serverSocket = null;
        }
        if (udpSocket != null) {
            udpSocket.close();
            udpSocket = null;
        }
    }

    private void startUdp() {
        udpThread = new Thread(this::udpLoop, "varcore-net-udp");
        udpThread.setDaemon(true);
        udpThread.start();
    }

    private void acceptLoop() {
        while (open.get() && serverSocket != null && !serverSocket.isClosed()) {
            try {
                Socket socket = serverSocket.accept();
                socket.setTcpNoDelay(true);
                int peerId = allocatePeerId();
                PeerLink link = new PeerLink(peerId, socket);
                peers.put(peerId, link);
                // Best-effort UDP association from TCP remote address (same host, udpPort may differ)
                startReader(link);
            } catch (IOException e) {
                if (!open.get()) {
                    break;
                }
            }
        }
    }

    private void startReader(PeerLink link) {
        Thread t = new Thread(() -> readLoop(link), "varcore-net-tcp-" + link.peerId);
        t.setDaemon(true);
        t.start();
    }

    private void readLoop(PeerLink link) {
        try {
            InputStream in = link.socket.getInputStream();
            byte[] header = new byte[NetProtocol.HEADER_SIZE];
            while (open.get() && !link.socket.isClosed()) {
                readFully(in, header, 0, header.length);
                int payloadLen = ((header[8] & 0xFF) << 24)
                        | ((header[9] & 0xFF) << 16)
                        | ((header[10] & 0xFF) << 8)
                        | (header[11] & 0xFF);
                if (payloadLen < 0 || payloadLen > NetProtocol.MAX_PAYLOAD) {
                    break;
                }
                byte[] full = new byte[NetProtocol.HEADER_SIZE + payloadLen];
                System.arraycopy(header, 0, full, 0, NetProtocol.HEADER_SIZE);
                if (payloadLen > 0) {
                    readFully(in, full, NetProtocol.HEADER_SIZE, payloadLen);
                }
                NetProtocol.Frame frame = NetProtocol.decode(full, 0, full.length);
                if (frame != null) {
                    inbound.offer(new Inbound(link.peerId, frame));
                }
            }
        } catch (IOException ignored) {
        } finally {
            int id = link.peerId;
            peers.remove(id);
            inbound.offer(new Inbound(id, new NetProtocol.Frame(
                    NetProtocol.TYPE_PEER_LEFT, NetProtocol.FLAG_RELIABLE, (byte) 0,
                    NetProtocol.packInt(id))));
            try {
                link.socket.close();
            } catch (IOException ignored) {
            }
        }
    }

    private void udpLoop() {
        byte[] buf = new byte[NetProtocol.HEADER_SIZE + 2048];
        DatagramPacket packet = new DatagramPacket(buf, buf.length);
        while (open.get() && udpSocket != null && !udpSocket.isClosed()) {
            try {
                udpSocket.setSoTimeout(500);
                packet.setData(buf);
                packet.setLength(buf.length);
                udpSocket.receive(packet);
                NetProtocol.Frame frame = NetProtocol.decode(packet.getData(), packet.getOffset(), packet.getLength());
                if (frame == null) {
                    continue;
                }
                int peerId;
                if (hosting) {
                    String k = key(packet.getAddress(), packet.getPort());
                    Integer mapped = udpKeyToPeer.get(k);
                    if (mapped == null) {
                        mapped = learnUdpPeer(packet.getAddress(), packet.getPort());
                    }
                    if (mapped == null) {
                        continue;
                    }
                    peerId = mapped;
                } else {
                    peerId = 1;
                }
                inbound.offer(new Inbound(peerId, frame));
            } catch (SocketTimeoutException ignored) {
            } catch (IOException e) {
                if (!open.get()) {
                    break;
                }
            }
        }
    }

    /** Match inbound UDP to a TCP peer by IP (first unmatched peer on that address). */
    private Integer learnUdpPeer(InetAddress address, int port) {
        if (address == null) {
            return null;
        }
        String host = address.getHostAddress();
        for (PeerLink link : peers.values()) {
            if (link.remoteAddress() == null) {
                continue;
            }
            if (!host.equals(link.remoteAddress().getHostAddress())) {
                continue;
            }
            if (link.udpLearned && link.udpPort != port) {
                continue;
            }
            registerUdpEndpoint(link.peerId, address, port);
            return link.peerId;
        }
        return null;
    }

    private static String key(InetAddress address, int port) {
        return address.getHostAddress() + ":" + port;
    }

    private static void readFully(InputStream in, byte[] dest, int off, int len) throws IOException {
        int read = 0;
        while (read < len) {
            int n = in.read(dest, off + read, len - read);
            if (n < 0) {
                throw new IOException("EOF");
            }
            read += n;
        }
    }

    public static final class PeerLink {
        volatile int peerId;
        final Socket socket;
        final DataOutputStream out;
        volatile InetAddress udpAddress;
        volatile int udpPort;
        volatile boolean udpLearned;

        PeerLink(int peerId, Socket socket) throws IOException {
            this.peerId = peerId;
            this.socket = socket;
            this.out = new DataOutputStream(socket.getOutputStream());
        }

        public InetAddress remoteAddress() {
            return socket.getInetAddress();
        }
    }
}
