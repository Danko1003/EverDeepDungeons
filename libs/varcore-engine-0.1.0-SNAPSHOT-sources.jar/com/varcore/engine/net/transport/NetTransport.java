package com.varcore.engine.net.transport;

import com.varcore.engine.net.NetProtocol;
import java.io.IOException;
import java.util.List;

/** Pluggable multiplayer transport. */
public interface NetTransport extends AutoCloseable {
    void host(int tcpPort, int udpPort) throws IOException;

    void connect(String host, int tcpPort, int udpPort) throws IOException;

    void sendReliable(int peerId, byte type, byte channel, byte[] payload) throws IOException;

    void sendUnreliable(int peerId, byte type, byte channel, byte[] payload) throws IOException;

    void broadcastReliable(byte type, byte channel, byte[] payload, int exceptPeerId) throws IOException;

    void broadcastUnreliable(byte type, byte channel, byte[] payload, int exceptPeerId) throws IOException;

    /** Poll inbound frames; call from game thread. */
    List<Inbound> poll();

    boolean isOpen();

    @Override
    void close();

    record Inbound(int peerId, NetProtocol.Frame frame) {}
}
