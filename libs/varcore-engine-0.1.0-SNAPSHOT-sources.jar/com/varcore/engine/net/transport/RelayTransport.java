package com.varcore.engine.net.transport;

import com.varcore.engine.net.NetProtocol;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Connects to a {@link com.varcore.engine.net.NetRelayServer}.
 * All traffic is reliable TCP; UDP ports are ignored.
 * Peer id 0 = broadcast via relay; local assignment happens at NetworkManager layer.
 */
public final class RelayTransport implements NetTransport {
    private final AtomicBoolean open = new AtomicBoolean();
    private final ConcurrentLinkedQueue<Inbound> inbound = new ConcurrentLinkedQueue<>();
    private Socket socket;
    private OutputStream out;
    private Thread reader;
    private String roomCode = "";
    private boolean createdRoom;

    public String roomCode() {
        return roomCode;
    }

    public boolean createdRoom() {
        return createdRoom;
    }

    /** Host creates a room on the relay. */
    public void createRoom(String relayHost, int relayPort) throws IOException {
        connectSocket(relayHost, relayPort);
        sendRaw(NetProtocol.encode(NetProtocol.TYPE_RELAY_CREATE, NetProtocol.FLAG_RELIABLE, (byte) 0, new byte[0]));
        waitForOk(true);
    }

    /** Client joins an existing room code. */
    public void joinRoom(String relayHost, int relayPort, String code) throws IOException {
        connectSocket(relayHost, relayPort);
        byte[] payload = code.trim().toUpperCase().getBytes(StandardCharsets.UTF_8);
        sendRaw(NetProtocol.encode(NetProtocol.TYPE_RELAY_JOIN, NetProtocol.FLAG_RELIABLE, (byte) 0, payload));
        waitForOk(false);
    }

    @Override
    public void host(int tcpPort, int udpPort) {
        throw new UnsupportedOperationException("Use createRoom(host, port) for relay hosting");
    }

    @Override
    public void connect(String host, int tcpPort, int udpPort) {
        throw new UnsupportedOperationException("Use joinRoom(host, port, code) for relay clients");
    }

    @Override
    public void sendReliable(int peerId, byte type, byte channel, byte[] payload) throws IOException {
        // Wrap original frame inside RELAY_FORWARD
        byte[] inner = NetProtocol.encode(type, NetProtocol.FLAG_RELIABLE, channel, payload);
        sendRaw(NetProtocol.encode(NetProtocol.TYPE_RELAY_FORWARD, NetProtocol.FLAG_RELIABLE, (byte) 0, inner));
    }

    @Override
    public void sendUnreliable(int peerId, byte type, byte channel, byte[] payload) throws IOException {
        sendReliable(peerId, type, channel, payload);
    }

    @Override
    public void broadcastReliable(byte type, byte channel, byte[] payload, int exceptPeerId) throws IOException {
        sendReliable(-1, type, channel, payload);
    }

    @Override
    public void broadcastUnreliable(byte type, byte channel, byte[] payload, int exceptPeerId) throws IOException {
        sendReliable(-1, type, channel, payload);
    }

    @Override
    public List<Inbound> poll() {
        List<Inbound> list = new ArrayList<>();
        Inbound item;
        while ((item = inbound.poll()) != null) {
            list.add(item);
        }
        return list;
    }

    @Override
    public boolean isOpen() {
        return open.get();
    }

    @Override
    public void close() {
        open.set(false);
        if (reader != null) {
            reader.interrupt();
        }
        if (socket != null) {
            try {
                socket.close();
            } catch (IOException ignored) {
            }
        }
        inbound.clear();
    }

    private void connectSocket(String host, int port) throws IOException {
        close();
        socket = new Socket();
        socket.connect(new InetSocketAddress(host, port), 5000);
        socket.setTcpNoDelay(true);
        out = socket.getOutputStream();
        open.set(true);
        reader = new Thread(this::readLoop, "varcore-relay-client");
        reader.setDaemon(true);
        reader.start();
    }

    private void waitForOk(boolean create) throws IOException {
        long deadline = System.currentTimeMillis() + 5000;
        while (System.currentTimeMillis() < deadline) {
            for (Inbound in : poll()) {
                if (in.frame().type() == NetProtocol.TYPE_RELAY_OK) {
                    roomCode = NetProtocol.readString(in.frame().payload());
                    createdRoom = create;
                    return;
                }
                if (in.frame().type() == NetProtocol.TYPE_RELAY_FAIL) {
                    throw new IOException(NetProtocol.readString(in.frame().payload()));
                }
            }
            try {
                Thread.sleep(20);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw new IOException("Interrupted waiting for relay", e);
            }
        }
        throw new IOException("Timed out waiting for relay room");
    }

    private void sendRaw(byte[] frame) throws IOException {
        if (out == null || !open.get()) {
            return;
        }
        synchronized (out) {
            out.write(frame);
            out.flush();
        }
    }

    private void readLoop() {
        try {
            InputStream in = socket.getInputStream();
            while (open.get() && !socket.isClosed()) {
                byte[] full = readFrame(in);
                if (full == null) {
                    break;
                }
                NetProtocol.Frame frame = NetProtocol.decode(full, 0, full.length);
                if (frame == null) {
                    continue;
                }
                if (frame.type() == NetProtocol.TYPE_RELAY_FORWARD) {
                    NetProtocol.Frame inner = NetProtocol.decode(frame.payload(), 0, frame.payload().length);
                    if (inner != null) {
                        inbound.offer(new Inbound(-1, inner));
                    }
                } else {
                    inbound.offer(new Inbound(-1, frame));
                }
            }
        } catch (IOException ignored) {
        } finally {
            open.set(false);
        }
    }

    private static byte[] readFrame(InputStream in) throws IOException {
        byte[] header = new byte[NetProtocol.HEADER_SIZE];
        if (!readFully(in, header, 0, header.length)) {
            return null;
        }
        int payloadLen = ((header[8] & 0xFF) << 24)
                | ((header[9] & 0xFF) << 16)
                | ((header[10] & 0xFF) << 8)
                | (header[11] & 0xFF);
        if (payloadLen < 0 || payloadLen > NetProtocol.MAX_PAYLOAD) {
            return null;
        }
        byte[] full = new byte[NetProtocol.HEADER_SIZE + payloadLen];
        System.arraycopy(header, 0, full, 0, NetProtocol.HEADER_SIZE);
        if (payloadLen > 0 && !readFully(in, full, NetProtocol.HEADER_SIZE, payloadLen)) {
            return null;
        }
        return full;
    }

    private static boolean readFully(InputStream in, byte[] dest, int off, int len) throws IOException {
        int read = 0;
        while (read < len) {
            int n = in.read(dest, off + read, len - read);
            if (n < 0) {
                return false;
            }
            read += n;
        }
        return true;
    }
}
