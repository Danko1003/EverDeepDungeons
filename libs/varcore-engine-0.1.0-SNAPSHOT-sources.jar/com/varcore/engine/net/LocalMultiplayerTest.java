package com.varcore.engine.net;

import com.varcore.engine.core.Game;
import java.awt.Frame;

/**
 * Same-PC multiplayer helpers: window offset, titles, and JVM property bootstrap.
 *
 * <pre>
 * // Window A
 * java -Dvarcore.net=host -Dvarcore.net.instance=0 ...
 * // Window B
 * java -Dvarcore.net=join:127.0.0.1:7777 -Dvarcore.net.instance=1 ...
 * </pre>
 */
public final class LocalMultiplayerTest {
    private LocalMultiplayerTest() {
    }

    public static int instanceIndex() {
        return Integer.getInteger("varcore.net.instance", 0);
    }

    public static String modeProperty() {
        String mode = System.getProperty("varcore.net", "");
        return mode == null ? "" : mode.trim();
    }

    /** Offset the game window so two instances are visible side-by-side. */
    public static void configureWindow(Game game, int instanceIndex) {
        if (game == null) {
            return;
        }
        Frame frame = game.getWindow().getFrame();
        String title = frame.getTitle();
        if (instanceIndex <= 0) {
            frame.setTitle(title + " [HOST]");
            frame.setLocation(40, 60);
        } else {
            frame.setTitle(title + " [CLIENT " + instanceIndex + "]");
            int w = Math.max(400, frame.getWidth());
            frame.setLocation(60 + w + 20, 60);
        }
    }

    public static void configureWindow(Game game) {
        configureWindow(game, instanceIndex());
    }

    /**
     * Applies {@code -Dvarcore.net=...} after the window is shown.
     * Returns a human-readable status string (empty if no property set).
     */
    public static String applyFromSystemProperties(NetworkManager net) throws Exception {
        String mode = modeProperty();
        if (mode.isEmpty()) {
            return "";
        }
        if ("host".equalsIgnoreCase(mode) || "local-test".equalsIgnoreCase(mode)) {
            net.host();
            return "Auto-host from -Dvarcore.net=" + mode;
        }
        if (mode.toLowerCase().startsWith("join:")) {
            String target = mode.substring(5).trim();
            String host = "127.0.0.1";
            int port = NetworkManager.DEFAULT_TCP_PORT;
            int colon = target.lastIndexOf(':');
            if (colon > 0) {
                host = target.substring(0, colon);
                port = Integer.parseInt(target.substring(colon + 1));
            } else if (!target.isEmpty()) {
                host = target;
            }
            net.join(host, port);
            return "Auto-join " + host + ":" + port;
        }
        if (mode.toLowerCase().startsWith("relay:")) {
            // relay:host:port:ROOM or relay:host:ROOM
            String rest = mode.substring(6).trim();
            String[] parts = rest.split(":");
            if (parts.length >= 3) {
                net.joinRelay(parts[0], Integer.parseInt(parts[1]), parts[2]);
                return "Auto-join relay " + parts[0] + " room " + parts[2];
            }
            if (parts.length == 2) {
                net.joinRelay(parts[0], parts[1]);
                return "Auto-join relay " + parts[0] + " room " + parts[1];
            }
        }
        if (mode.equalsIgnoreCase("lan")) {
            net.joinLan();
            return "Auto-join LAN";
        }
        return "Unknown -Dvarcore.net=" + mode;
    }
}
