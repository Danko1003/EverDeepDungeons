package com.varcore.engine.net.sync;

/** Client-side linear interpolator for remote transforms. */
public final class NetInterpolator {
    private float fromX;
    private float fromY;
    private float toX;
    private float toY;
    private float elapsed;
    private float duration = 0.1f;
    private boolean hasTarget;

    public void setDuration(float duration) {
        this.duration = Math.max(0.01f, duration);
    }

    public void push(float x, float y) {
        if (!hasTarget) {
            fromX = toX = x;
            fromY = toY = y;
            hasTarget = true;
            elapsed = duration;
            return;
        }
        fromX = currentX();
        fromY = currentY();
        toX = x;
        toY = y;
        elapsed = 0f;
    }

    public void update(float dt) {
        elapsed = Math.min(duration, elapsed + dt);
    }

    public float currentX() {
        if (!hasTarget) {
            return toX;
        }
        float t = Math.min(1f, elapsed / duration);
        return fromX + (toX - fromX) * t;
    }

    public float currentY() {
        if (!hasTarget) {
            return toY;
        }
        float t = Math.min(1f, elapsed / duration);
        return fromY + (toY - fromY) * t;
    }

    public boolean hasTarget() {
        return hasTarget;
    }
}
