package com.varcore.engine.net.sync;

/** Simple tick accumulator for network send rates. */
public final class NetTickClock {
    private final float intervalSeconds;
    private float accumulator;

    public NetTickClock(float ticksPerSecond) {
        this.intervalSeconds = 1f / Math.max(1f, ticksPerSecond);
    }

    public boolean tick(float dt) {
        accumulator += dt;
        if (accumulator >= intervalSeconds) {
            accumulator -= intervalSeconds;
            if (accumulator > intervalSeconds) {
                accumulator = 0f;
            }
            return true;
        }
        return false;
    }

    public float intervalSeconds() {
        return intervalSeconds;
    }
}
