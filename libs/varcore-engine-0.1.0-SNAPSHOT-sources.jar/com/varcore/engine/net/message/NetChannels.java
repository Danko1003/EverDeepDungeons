package com.varcore.engine.net.message;

/** Built-in message channel ids (byte). */
public final class NetChannels {
    public static final byte SYSTEM = 0;
    public static final byte INPUT = 1;
    public static final byte TRANSFORM = 2;
    public static final byte RPC = 3;
    public static final byte CHAT = 4;
    public static final byte CUSTOM = 5;

    private NetChannels() {
    }
}
