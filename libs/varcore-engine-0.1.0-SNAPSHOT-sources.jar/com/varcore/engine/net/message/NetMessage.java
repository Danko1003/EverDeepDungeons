package com.varcore.engine.net.message;

import java.nio.charset.StandardCharsets;

/** Typed application message envelope. */
public final class NetMessage {
    private final String type;
    private final byte channel;
    private final boolean reliable;
    private final byte[] payload;
    private final int senderPeerId;

    public NetMessage(String type, byte channel, boolean reliable, byte[] payload, int senderPeerId) {
        this.type = type == null ? "" : type;
        this.channel = channel;
        this.reliable = reliable;
        this.payload = payload == null ? new byte[0] : payload;
        this.senderPeerId = senderPeerId;
    }

    public static NetMessage of(String type, String text, boolean reliable) {
        return new NetMessage(type, NetChannels.CUSTOM, reliable,
                text == null ? new byte[0] : text.getBytes(StandardCharsets.UTF_8), -1);
    }

    public static NetMessage of(String type, byte[] payload, boolean reliable) {
        return new NetMessage(type, NetChannels.CUSTOM, reliable, payload, -1);
    }

    public static NetMessage rpc(String type, byte[] payload, boolean reliable) {
        return new NetMessage(type, NetChannels.RPC, reliable, payload, -1);
    }

    public static NetMessage chat(String text) {
        return new NetMessage("Chat", NetChannels.CHAT, true,
                text == null ? new byte[0] : text.getBytes(StandardCharsets.UTF_8), -1);
    }

    public String type() {
        return type;
    }

    public byte channel() {
        return channel;
    }

    public boolean reliable() {
        return reliable;
    }

    public byte[] payload() {
        return payload;
    }

    public int senderPeerId() {
        return senderPeerId;
    }

    public String text() {
        return new String(payload, StandardCharsets.UTF_8);
    }

    public NetMessage withSender(int peerId) {
        return new NetMessage(type, channel, reliable, payload, peerId);
    }

    public NetMessage withChannel(byte channel) {
        return new NetMessage(type, channel, reliable, payload, senderPeerId);
    }
}
