package com.varcore.engine.net.message;

import com.varcore.engine.net.NetPeer;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.BiConsumer;

/** Registers typed handlers and encodes/decodes DATA payloads. */
public final class NetMessageBus {
    private final Map<String, BiConsumer<NetPeer, NetMessage>> handlers = new ConcurrentHashMap<>();
    private BiConsumer<NetPeer, NetMessage> fallback;

    public void register(String type, BiConsumer<NetPeer, NetMessage> handler) {
        if (type != null && handler != null) {
            handlers.put(type, handler);
        }
    }

    public void unregister(String type) {
        handlers.remove(type);
    }

    public void setFallback(BiConsumer<NetPeer, NetMessage> fallback) {
        this.fallback = fallback;
    }

    public void dispatch(NetPeer peer, NetMessage message) {
        if (message == null) {
            return;
        }
        BiConsumer<NetPeer, NetMessage> handler = handlers.get(message.type());
        if (handler != null) {
            handler.accept(peer, message);
        } else if (fallback != null) {
            fallback.accept(peer, message);
        }
    }

    public void clear() {
        handlers.clear();
        fallback = null;
    }

    /** Wire format: typeLen(2) + type UTF-8 + payload. */
    public static byte[] encode(NetMessage message) {
        byte[] typeBytes = message.type().getBytes(StandardCharsets.UTF_8);
        byte[] payload = message.payload();
        ByteBuffer buf = ByteBuffer.allocate(2 + typeBytes.length + payload.length).order(ByteOrder.BIG_ENDIAN);
        buf.putShort((short) typeBytes.length);
        buf.put(typeBytes);
        buf.put(payload);
        return buf.array();
    }

    public static NetMessage decode(byte channel, boolean reliable, byte[] data, int senderPeerId) {
        if (data == null || data.length < 2) {
            return new NetMessage("", channel, reliable, new byte[0], senderPeerId);
        }
        ByteBuffer buf = ByteBuffer.wrap(data).order(ByteOrder.BIG_ENDIAN);
        int typeLen = Short.toUnsignedInt(buf.getShort());
        if (typeLen < 0 || typeLen > buf.remaining()) {
            return new NetMessage("", channel, reliable, data, senderPeerId);
        }
        byte[] typeBytes = new byte[typeLen];
        buf.get(typeBytes);
        byte[] payload = new byte[buf.remaining()];
        buf.get(payload);
        return new NetMessage(new String(typeBytes, StandardCharsets.UTF_8), channel, reliable, payload, senderPeerId);
    }
}
