package com.varcore.engine.net;

/** Role of the local machine in a multiplayer session. */
public enum NetRole {
    NONE,
    HOST,
    CLIENT,
    DEDICATED
}
