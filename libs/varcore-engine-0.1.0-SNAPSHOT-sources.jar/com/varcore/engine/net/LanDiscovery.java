package com.varcore.engine.net;

import com.varcore.engine.net.NetProtocol.Frame;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.SocketTimeoutException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicBoolean;

/** UDP broadcast advertise / browse for LAN rooms. */
public final class LanDiscovery implements AutoCloseable {
    public static final int DEFAULT_PORT = 47777;

    private final int port;
    private final AtomicBoolean running = new AtomicBoolean();
    private final CopyOnWriteArrayList<LanRoom> rooms = new CopyOnWriteArrayList<>();
    private DatagramSocket socket;
    private Thread thread;
    private volatile Advertisement advertisement;

    public LanDiscovery() {
        this(DEFAULT_PORT);
    }

    public LanDiscovery(int port) {
        this.port = port;
    }

    public void startBrowsing() throws IOException {
        ensureSocket();
        running.set(true);
        if (thread == null || !thread.isAlive()) {
            thread = new Thread(this::loop, "varcore-lan-discovery");
            thread.setDaemon(true);
            thread.start();
        }
        byte[] probe = NetProtocol.encode(NetProtocol.TYPE_DISCOVER, (byte) 0, (byte) 0, new byte[0]);
        DatagramPacket packet = new DatagramPacket(probe, probe.length,
                InetAddress.getByName("255.255.255.255"), port);
        socket.send(packet);
    }

    public void advertise(String gameName, String roomCode, int tcpPort, int udpPort) throws IOException {
        ensureSocket();
        advertisement = new Advertisement(gameName, roomCode, tcpPort, udpPort);
        running.set(true);
        if (thread == null || !thread.isAlive()) {
            thread = new Thread(this::loop, "varcore-lan-discovery");
            thread.setDaemon(true);
            thread.start();
        }
    }

    public void stopAdvertising() {
        advertisement = null;
    }

    public List<LanRoom> rooms() {
        long now = System.currentTimeMillis();
        List<LanRoom> fresh = new ArrayList<>();
        for (LanRoom room : rooms) {
            if (now - room.seenAtMs() < 5000) {
                fresh.add(room);
            }
        }
        rooms.retainAll(fresh);
        return List.copyOf(fresh);
    }

    public LanRoom firstRoom() {
        List<LanRoom> list = rooms();
        return list.isEmpty() ? null : list.get(0);
    }

    private void ensureSocket() throws IOException {
        if (socket != null && !socket.isClosed()) {
            return;
        }
        socket = new DatagramSocket(null);
        socket.setReuseAddress(true);
        socket.setBroadcast(true);
        socket.bind(new InetSocketAddress(port));
    }

    private void loop() {
        byte[] buf = new byte[2048];
        DatagramPacket packet = new DatagramPacket(buf, buf.length);
        long lastAdvertise = 0;
        while (running.get() && socket != null && !socket.isClosed()) {
            try {
                Advertisement ad = advertisement;
                long now = System.currentTimeMillis();
                if (ad != null && now - lastAdvertise > 1000) {
                    byte[] reply = encodeReply(ad);
                    DatagramPacket out = new DatagramPacket(reply, reply.length,
                            InetAddress.getByName("255.255.255.255"), port);
                    socket.send(out);
                    lastAdvertise = now;
                }
                socket.setSoTimeout(300);
                packet.setData(buf);
                packet.setLength(buf.length);
                socket.receive(packet);
                Frame frame = NetProtocol.decode(packet.getData(), packet.getOffset(), packet.getLength());
                if (frame == null) {
                    continue;
                }
                if (frame.type() == NetProtocol.TYPE_DISCOVER && ad != null) {
                    byte[] reply = encodeReply(ad);
                    DatagramPacket out = new DatagramPacket(reply, reply.length, packet.getAddress(), packet.getPort());
                    socket.send(out);
                } else if (frame.type() == NetProtocol.TYPE_DISCOVER_REPLY) {
                    LanRoom room = decodeReply(frame.payload(), packet.getAddress().getHostAddress());
                    if (room != null) {
                        upsert(room);
                    }
                }
            } catch (SocketTimeoutException ignored) {
            } catch (IOException e) {
                if (!running.get()) {
                    break;
                }
            }
        }
    }

    private void upsert(LanRoom room) {
        rooms.removeIf(r -> r.host().equals(room.host()) && r.tcpPort() == room.tcpPort());
        rooms.add(room);
    }

    private static byte[] encodeReply(Advertisement ad) {
        byte[] name = ad.gameName().getBytes(StandardCharsets.UTF_8);
        byte[] code = ad.roomCode().getBytes(StandardCharsets.UTF_8);
        ByteBuffer buf = ByteBuffer.allocate(12 + name.length + code.length).order(ByteOrder.BIG_ENDIAN);
        buf.putInt(ad.tcpPort());
        buf.putInt(ad.udpPort());
        buf.putShort((short) name.length);
        buf.put(name);
        buf.putShort((short) code.length);
        buf.put(code);
        return NetProtocol.encode(NetProtocol.TYPE_DISCOVER_REPLY, (byte) 0, (byte) 0, buf.array());
    }

    private static LanRoom decodeReply(byte[] payload, String host) {
        try {
            ByteBuffer buf = ByteBuffer.wrap(payload).order(ByteOrder.BIG_ENDIAN);
            int tcp = buf.getInt();
            int udp = buf.getInt();
            int nLen = Short.toUnsignedInt(buf.getShort());
            byte[] name = new byte[nLen];
            buf.get(name);
            int cLen = Short.toUnsignedInt(buf.getShort());
            byte[] code = new byte[cLen];
            buf.get(code);
            return new LanRoom(host, tcp, udp,
                    new String(name, StandardCharsets.UTF_8),
                    new String(code, StandardCharsets.UTF_8),
                    System.currentTimeMillis());
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public void close() {
        running.set(false);
        advertisement = null;
        if (thread != null) {
            thread.interrupt();
        }
        if (socket != null) {
            socket.close();
            socket = null;
        }
        rooms.clear();
    }

    public record LanRoom(String host, int tcpPort, int udpPort, String gameName, String roomCode, long seenAtMs) {}

    private record Advertisement(String gameName, String roomCode, int tcpPort, int udpPort) {}
}
