package com.varcore.engine.net;

import com.varcore.engine.net.NetProtocol.Frame;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Lightweight TCP relay: creates rooms by code and forwards framed packets between members.
 * Run standalone via {@link #main(String[])} or embed for local worldwide tests.
 */
public final class NetRelayServer implements AutoCloseable {
    public static final int DEFAULT_PORT = 7788;

    private final int port;
    private final AtomicBoolean running = new AtomicBoolean();
    private final Map<String, Room> rooms = new ConcurrentHashMap<>();
    private ServerSocket serverSocket;
    private Thread acceptThread;

    public NetRelayServer() {
        this(DEFAULT_PORT);
    }

    public NetRelayServer(int port) {
        this.port = port;
    }

    public void start() throws IOException {
        if (running.get()) {
            return;
        }
        serverSocket = new ServerSocket(port);
        running.set(true);
        acceptThread = new Thread(this::acceptLoop, "varcore-relay-accept");
        acceptThread.setDaemon(true);
        acceptThread.start();
        System.out.println("VarCore relay listening on port " + port);
    }

    public int port() {
        return port;
    }

    public boolean isRunning() {
        return running.get();
    }

    private void acceptLoop() {
        while (running.get() && serverSocket != null && !serverSocket.isClosed()) {
            try {
                Socket socket = serverSocket.accept();
                Thread t = new Thread(() -> handleClient(socket), "varcore-relay-client");
                t.setDaemon(true);
                t.start();
            } catch (IOException e) {
                if (!running.get()) {
                    break;
                }
            }
        }
    }

    private void handleClient(Socket socket) {
        Member member = null;
        try {
            InputStream in = socket.getInputStream();
            OutputStream out = socket.getOutputStream();
            while (running.get() && !socket.isClosed()) {
                byte[] full = readFrame(in);
                if (full == null) {
                    break;
                }
                Frame frame = NetProtocol.decode(full, 0, full.length);
                if (frame == null) {
                    continue;
                }
                if (frame.type() == NetProtocol.TYPE_RELAY_CREATE) {
                    String code = randomCode();
                    Room room = rooms.computeIfAbsent(code, Room::new);
                    member = new Member(socket, out, room, true);
                    room.members.put(member, Boolean.TRUE);
                    byte[] ok = NetProtocol.encode(NetProtocol.TYPE_RELAY_OK, NetProtocol.FLAG_RELIABLE, (byte) 0,
                            code.getBytes(StandardCharsets.UTF_8));
                    out.write(ok);
                    out.flush();
                } else if (frame.type() == NetProtocol.TYPE_RELAY_JOIN) {
                    String code = NetProtocol.readString(frame.payload()).trim().toUpperCase();
                    Room room = rooms.get(code);
                    if (room == null) {
                        byte[] fail = NetProtocol.encode(NetProtocol.TYPE_RELAY_FAIL, NetProtocol.FLAG_RELIABLE, (byte) 0,
                                "Room not found".getBytes(StandardCharsets.UTF_8));
                        out.write(fail);
                        out.flush();
                        break;
                    }
                    member = new Member(socket, out, room, false);
                    room.members.put(member, Boolean.TRUE);
                    byte[] ok = NetProtocol.encode(NetProtocol.TYPE_RELAY_OK, NetProtocol.FLAG_RELIABLE, (byte) 0,
                            code.getBytes(StandardCharsets.UTF_8));
                    out.write(ok);
                    out.flush();
                } else if (frame.type() == NetProtocol.TYPE_RELAY_FORWARD && member != null) {
                    forward(member, full);
                }
            }
        } catch (IOException ignored) {
        } finally {
            if (member != null) {
                member.room.members.remove(member);
                if (member.room.members.isEmpty()) {
                    rooms.remove(member.room.code);
                }
            }
            try {
                socket.close();
            } catch (IOException ignored) {
            }
        }
    }

    private void forward(Member from, byte[] fullFrame) {
        for (Member member : from.room.members.keySet()) {
            if (member == from) {
                continue;
            }
            try {
                synchronized (member.out) {
                    member.out.write(fullFrame);
                    member.out.flush();
                }
            } catch (IOException ignored) {
            }
        }
    }

    private static byte[] readFrame(InputStream in) throws IOException {
        byte[] header = new byte[NetProtocol.HEADER_SIZE];
        if (!readFully(in, header)) {
            return null;
        }
        int payloadLen = ((header[8] & 0xFF) << 24)
                | ((header[9] & 0xFF) << 16)
                | ((header[10] & 0xFF) << 8)
                | (header[11] & 0xFF);
        if (payloadLen < 0 || payloadLen > NetProtocol.MAX_PAYLOAD) {
            return null;
        }
        byte[] full = new byte[NetProtocol.HEADER_SIZE + payloadLen];
        System.arraycopy(header, 0, full, 0, NetProtocol.HEADER_SIZE);
        if (payloadLen > 0 && !readFully(in, full, NetProtocol.HEADER_SIZE, payloadLen)) {
            return null;
        }
        return full;
    }

    private static boolean readFully(InputStream in, byte[] dest) throws IOException {
        return readFully(in, dest, 0, dest.length);
    }

    private static boolean readFully(InputStream in, byte[] dest, int off, int len) throws IOException {
        int read = 0;
        while (read < len) {
            int n = in.read(dest, off + read, len - read);
            if (n < 0) {
                return false;
            }
            read += n;
        }
        return true;
    }

    private static String randomCode() {
        String alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
        StringBuilder sb = new StringBuilder(4);
        for (int i = 0; i < 4; i++) {
            sb.append(alphabet.charAt((int) (Math.random() * alphabet.length())));
        }
        return sb.toString();
    }

    @Override
    public void close() {
        running.set(false);
        if (acceptThread != null) {
            acceptThread.interrupt();
        }
        if (serverSocket != null) {
            try {
                serverSocket.close();
            } catch (IOException ignored) {
            }
        }
        rooms.clear();
    }

    public static void main(String[] args) throws Exception {
        int port = DEFAULT_PORT;
        if (args.length > 0) {
            port = Integer.parseInt(args[0]);
        }
        NetRelayServer server = new NetRelayServer(port);
        server.start();
        Runtime.getRuntime().addShutdownHook(new Thread(server::close));
        Thread.currentThread().join();
    }

    private static final class Room {
        final String code;
        final Map<Member, Boolean> members = new ConcurrentHashMap<>();

        Room(String code) {
            this.code = code;
        }
    }

    private static final class Member {
        final Socket socket;
        final OutputStream out;
        final Room room;
        final boolean host;

        Member(Socket socket, OutputStream out, Room room, boolean host) {
            this.socket = socket;
            this.out = out;
            this.room = room;
            this.host = host;
        }
    }
}
