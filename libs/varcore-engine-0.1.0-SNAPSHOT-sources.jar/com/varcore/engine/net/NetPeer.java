package com.varcore.engine.net;

/** A connected remote (or local) peer in a session. */
public final class NetPeer {
    private final int id;
    private final String name;
    private volatile boolean connected = true;
    private volatile long lastRttMs;
    private volatile long lastHeardMs = System.currentTimeMillis();

    public NetPeer(int id, String name) {
        this.id = id;
        this.name = name == null || name.isBlank() ? "Player" + id : name;
    }

    public int id() {
        return id;
    }

    public String name() {
        return name;
    }

    public boolean isConnected() {
        return connected;
    }

    public void setConnected(boolean connected) {
        this.connected = connected;
    }

    public long lastRttMs() {
        return lastRttMs;
    }

    public void setLastRttMs(long lastRttMs) {
        this.lastRttMs = lastRttMs;
    }

    public long lastHeardMs() {
        return lastHeardMs;
    }

    public void touch() {
        lastHeardMs = System.currentTimeMillis();
    }

    @Override
    public String toString() {
        return "NetPeer{id=" + id + ", name='" + name + "', rtt=" + lastRttMs + "ms}";
    }
}
