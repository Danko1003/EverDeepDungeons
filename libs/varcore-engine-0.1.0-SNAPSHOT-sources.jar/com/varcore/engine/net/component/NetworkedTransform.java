package com.varcore.engine.net.component;

import com.varcore.engine.component.Component;
import com.varcore.engine.entity.Transform;
import com.varcore.engine.net.sync.NetInterpolator;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/** Replicates world position (and optional rotation) over the network. */
public class NetworkedTransform extends Component {
    private boolean syncRotation;
    private float sendRate = 20f;
    private final NetInterpolator interpolator = new NetInterpolator();
    private float sendAccumulator;
    private float lastSentX = Float.NaN;
    private float lastSentY = Float.NaN;
    private float lastSentRot = Float.NaN;

    public NetworkedTransform syncRotation(boolean syncRotation) {
        this.syncRotation = syncRotation;
        return this;
    }

    public NetworkedTransform sendRate(float hz) {
        this.sendRate = Math.max(1f, hz);
        return this;
    }

    public NetInterpolator interpolator() {
        return interpolator;
    }

    public boolean syncRotation() {
        return syncRotation;
    }

    public boolean shouldSend(float dt, boolean hasAuthority) {
        if (!hasAuthority) {
            return false;
        }
        sendAccumulator += dt;
        float interval = 1f / sendRate;
        if (sendAccumulator < interval) {
            return false;
        }
        sendAccumulator = 0f;
        Transform t = getGameObject() == null ? null : getGameObject().getTransform();
        if (t == null) {
            return false;
        }
        float x = t.getPosition().x;
        float y = t.getPosition().y;
        float rot = t.getRotation();
        if (x == lastSentX && y == lastSentY && (!syncRotation || rot == lastSentRot)) {
            return false;
        }
        lastSentX = x;
        lastSentY = y;
        lastSentRot = rot;
        return true;
    }

    public byte[] encodeSnapshot() {
        Transform t = getGameObject().getTransform();
        ByteBuffer buf = ByteBuffer.allocate(syncRotation ? 12 : 8).order(ByteOrder.BIG_ENDIAN);
        buf.putFloat(t.getPosition().x);
        buf.putFloat(t.getPosition().y);
        if (syncRotation) {
            buf.putFloat(t.getRotation());
        }
        return buf.array();
    }

    public void applySnapshot(byte[] payload, boolean interpolate) {
        if (payload == null || payload.length < 8) {
            return;
        }
        ByteBuffer buf = ByteBuffer.wrap(payload).order(ByteOrder.BIG_ENDIAN);
        float x = buf.getFloat();
        float y = buf.getFloat();
        float rot = syncRotation && buf.remaining() >= 4 ? buf.getFloat() : Float.NaN;
        if (interpolate) {
            interpolator.push(x, y);
        } else if (getGameObject() != null) {
            getGameObject().getTransform().setPosition(x, y);
        }
        if (!Float.isNaN(rot) && getGameObject() != null) {
            getGameObject().getTransform().setRotation(rot);
        }
    }

    @Override
    public void update(float dt) {
        NetworkIdentity identity = getGameObject() == null ? null : getGameObject().getComponent(NetworkIdentity.class);
        boolean remote = identity != null && !identity.isLocalPlayer();
        if (remote && interpolator.hasTarget()) {
            interpolator.update(dt);
            getGameObject().getTransform().setPosition(interpolator.currentX(), interpolator.currentY());
        }
    }
}
