package com.varcore.engine.net.component;

import com.varcore.engine.component.Component;
import java.util.concurrent.atomic.AtomicInteger;

/** Marks a GameObject as networked. Host assigns ids; ownerPeerId is who has authority. */
public class NetworkIdentity extends Component {
    private static final AtomicInteger NEXT_ID = new AtomicInteger(1);

    private int netId = -1;
    private int ownerPeerId = -1;
    private boolean localPlayer;

    public static int allocateId() {
        return NEXT_ID.getAndIncrement();
    }

    public static void resetIdsForTests() {
        NEXT_ID.set(1);
    }

    public int netId() {
        return netId;
    }

    public void setNetId(int netId) {
        this.netId = netId;
    }

    public int ownerPeerId() {
        return ownerPeerId;
    }

    public void setOwnerPeerId(int ownerPeerId) {
        this.ownerPeerId = ownerPeerId;
    }

    public boolean isLocalPlayer() {
        return localPlayer;
    }

    public void setLocalPlayer(boolean localPlayer) {
        this.localPlayer = localPlayer;
    }

    public boolean hasAuthority(int localPeerId, boolean isHost) {
        if (ownerPeerId < 0) {
            return isHost;
        }
        return ownerPeerId == localPeerId;
    }

    /** Assign a fresh net id if unset (host-side spawn). */
    public void ensureNetId() {
        if (netId < 0) {
            netId = allocateId();
        }
    }
}
