package com.varcore.engine.net.component;

import com.varcore.engine.component.Component;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/**
 * Client → host input snapshot. Store axes/buttons locally, encode each tick.
 * Host applies remote input via {@link #applyRemote(byte[])}.
 */
public class NetworkInput extends Component {
    private float axisX;
    private float axisY;
    private int buttons;
    private float sendRate = 30f;
    private float sendAccumulator;
    private float remoteAxisX;
    private float remoteAxisY;
    private int remoteButtons;

    public NetworkInput sendRate(float hz) {
        this.sendRate = Math.max(1f, hz);
        return this;
    }

    public void setAxes(float x, float y) {
        this.axisX = x;
        this.axisY = y;
    }

    public void setButton(int bit, boolean down) {
        if (down) {
            buttons |= (1 << bit);
        } else {
            buttons &= ~(1 << bit);
        }
    }

    public float axisX() {
        return axisX;
    }

    public float axisY() {
        return axisY;
    }

    public int buttons() {
        return buttons;
    }

    public float remoteAxisX() {
        return remoteAxisX;
    }

    public float remoteAxisY() {
        return remoteAxisY;
    }

    public int remoteButtons() {
        return remoteButtons;
    }

    public boolean isRemoteButtonDown(int bit) {
        return (remoteButtons & (1 << bit)) != 0;
    }

    public boolean shouldSend(float dt) {
        sendAccumulator += dt;
        float interval = 1f / sendRate;
        if (sendAccumulator >= interval) {
            sendAccumulator = 0f;
            return true;
        }
        return false;
    }

    public byte[] encode() {
        ByteBuffer buf = ByteBuffer.allocate(12).order(ByteOrder.BIG_ENDIAN);
        buf.putFloat(axisX);
        buf.putFloat(axisY);
        buf.putInt(buttons);
        return buf.array();
    }

    public void applyRemote(byte[] payload) {
        if (payload == null || payload.length < 12) {
            return;
        }
        ByteBuffer buf = ByteBuffer.wrap(payload).order(ByteOrder.BIG_ENDIAN);
        remoteAxisX = buf.getFloat();
        remoteAxisY = buf.getFloat();
        remoteButtons = buf.getInt();
    }
}
