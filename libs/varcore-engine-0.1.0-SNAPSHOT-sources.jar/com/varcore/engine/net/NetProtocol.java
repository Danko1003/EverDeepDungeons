package com.varcore.engine.net;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;

/**
 * Binary framing for VarCore multiplayer.
 * Frame: magic(4) + version(1) + type(1) + flags(1) + channel(1) + length(4 BE) + payload.
 */
public final class NetProtocol {
    public static final byte[] MAGIC = {'V', 'C', 'N', '1'};
    public static final byte VERSION = 1;
    public static final int HEADER_SIZE = 12;
    public static final int MAX_PAYLOAD = 64 * 1024;

    public static final byte TYPE_HELLO = 1;
    public static final byte TYPE_WELCOME = 2;
    public static final byte TYPE_PEER_JOINED = 3;
    public static final byte TYPE_PEER_LEFT = 4;
    public static final byte TYPE_DATA = 5;
    public static final byte TYPE_PING = 6;
    public static final byte TYPE_PONG = 7;
    public static final byte TYPE_DISCOVER = 8;
    public static final byte TYPE_DISCOVER_REPLY = 9;
    public static final byte TYPE_RELAY_CREATE = 10;
    public static final byte TYPE_RELAY_JOIN = 11;
    public static final byte TYPE_RELAY_FORWARD = 12;
    public static final byte TYPE_RELAY_OK = 13;
    public static final byte TYPE_RELAY_FAIL = 14;

    public static final byte FLAG_RELIABLE = 1;

    private NetProtocol() {
    }

    public static byte[] encode(byte type, byte flags, byte channel, byte[] payload) {
        byte[] body = payload == null ? new byte[0] : payload;
        if (body.length > MAX_PAYLOAD) {
            throw new IllegalArgumentException("Payload too large: " + body.length);
        }
        ByteBuffer buf = ByteBuffer.allocate(HEADER_SIZE + body.length).order(ByteOrder.BIG_ENDIAN);
        buf.put(MAGIC);
        buf.put(VERSION);
        buf.put(type);
        buf.put(flags);
        buf.put(channel);
        buf.putInt(body.length);
        buf.put(body);
        return buf.array();
    }

    public static Frame decode(byte[] data, int offset, int length) {
        if (length < HEADER_SIZE) {
            return null;
        }
        ByteBuffer buf = ByteBuffer.wrap(data, offset, length).order(ByteOrder.BIG_ENDIAN);
        byte[] magic = new byte[4];
        buf.get(magic);
        if (!Arrays.equals(magic, MAGIC)) {
            return null;
        }
        byte version = buf.get();
        if (version != VERSION) {
            return null;
        }
        byte type = buf.get();
        byte flags = buf.get();
        byte channel = buf.get();
        int payloadLen = buf.getInt();
        if (payloadLen < 0 || payloadLen > MAX_PAYLOAD || HEADER_SIZE + payloadLen > length) {
            return null;
        }
        byte[] payload = new byte[payloadLen];
        buf.get(payload);
        return new Frame(type, flags, channel, payload);
    }

    public static byte[] stringBytes(String value) {
        return (value == null ? "" : value).getBytes(StandardCharsets.UTF_8);
    }

    public static String readString(byte[] payload) {
        return payload == null ? "" : new String(payload, StandardCharsets.UTF_8);
    }

    public static byte[] packHello(String playerName, String gameName) {
        String name = playerName == null ? "Player" : playerName;
        String game = gameName == null ? "Game" : gameName;
        byte[] nb = stringBytes(name);
        byte[] gb = stringBytes(game);
        ByteBuffer buf = ByteBuffer.allocate(4 + nb.length + 4 + gb.length).order(ByteOrder.BIG_ENDIAN);
        buf.putInt(nb.length);
        buf.put(nb);
        buf.putInt(gb.length);
        buf.put(gb);
        return buf.array();
    }

    public static HelloPayload unpackHello(byte[] payload) {
        ByteBuffer buf = ByteBuffer.wrap(payload).order(ByteOrder.BIG_ENDIAN);
        int nLen = buf.getInt();
        byte[] nb = new byte[nLen];
        buf.get(nb);
        int gLen = buf.getInt();
        byte[] gb = new byte[gLen];
        buf.get(gb);
        return new HelloPayload(new String(nb, StandardCharsets.UTF_8), new String(gb, StandardCharsets.UTF_8));
    }

    public static byte[] packWelcome(int peerId, String roomCode) {
        byte[] code = stringBytes(roomCode);
        ByteBuffer buf = ByteBuffer.allocate(8 + code.length).order(ByteOrder.BIG_ENDIAN);
        buf.putInt(peerId);
        buf.putInt(code.length);
        buf.put(code);
        return buf.array();
    }

    public static WelcomePayload unpackWelcome(byte[] payload) {
        ByteBuffer buf = ByteBuffer.wrap(payload).order(ByteOrder.BIG_ENDIAN);
        int peerId = buf.getInt();
        int len = buf.getInt();
        byte[] code = new byte[len];
        buf.get(code);
        return new WelcomePayload(peerId, new String(code, StandardCharsets.UTF_8));
    }

    public static byte[] packPeerInfo(int peerId, String name) {
        byte[] nb = stringBytes(name);
        ByteBuffer buf = ByteBuffer.allocate(8 + nb.length).order(ByteOrder.BIG_ENDIAN);
        buf.putInt(peerId);
        buf.putInt(nb.length);
        buf.put(nb);
        return buf.array();
    }

    public static PeerInfo unpackPeerInfo(byte[] payload) {
        ByteBuffer buf = ByteBuffer.wrap(payload).order(ByteOrder.BIG_ENDIAN);
        int peerId = buf.getInt();
        int len = buf.getInt();
        byte[] nb = new byte[len];
        buf.get(nb);
        return new PeerInfo(peerId, new String(nb, StandardCharsets.UTF_8));
    }

    public static byte[] packInt(int value) {
        return ByteBuffer.allocate(4).order(ByteOrder.BIG_ENDIAN).putInt(value).array();
    }

    public static int unpackInt(byte[] payload) {
        return ByteBuffer.wrap(payload).order(ByteOrder.BIG_ENDIAN).getInt();
    }

    public static byte[] packLong(long value) {
        return ByteBuffer.allocate(8).order(ByteOrder.BIG_ENDIAN).putLong(value).array();
    }

    public static long unpackLong(byte[] payload) {
        return ByteBuffer.wrap(payload).order(ByteOrder.BIG_ENDIAN).getLong();
    }

    public record Frame(byte type, byte flags, byte channel, byte[] payload) {
        public boolean reliable() {
            return (flags & FLAG_RELIABLE) != 0;
        }
    }

    public record HelloPayload(String playerName, String gameName) {}

    public record WelcomePayload(int peerId, String roomCode) {}

    public record PeerInfo(int peerId, String name) {}
}
