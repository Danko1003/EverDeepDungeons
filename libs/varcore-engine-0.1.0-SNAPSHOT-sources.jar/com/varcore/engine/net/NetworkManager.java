package com.varcore.engine.net;

import com.varcore.engine.entity.GameObject;
import com.varcore.engine.net.component.NetworkIdentity;
import com.varcore.engine.net.component.NetworkInput;
import com.varcore.engine.net.component.NetworkedTransform;
import com.varcore.engine.net.message.NetChannels;
import com.varcore.engine.net.message.NetMessage;
import com.varcore.engine.net.message.NetMessageBus;
import com.varcore.engine.net.transport.NetTransport;
import com.varcore.engine.net.transport.RelayTransport;
import com.varcore.engine.net.transport.TcpUdpTransport;
import com.varcore.engine.scene.Scene;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.BiConsumer;
import java.util.function.Consumer;

/**
 * Central multiplayer API: host / join / LAN / relay, messages, and transform/input sync.
 * Access via {@code game.getNetwork()}.
 */
public final class NetworkManager {
    public static final int DEFAULT_TCP_PORT = 7777;
    public static final int DEFAULT_UDP_PORT = 7778;

    private final NetSession session = new NetSession();
    private final NetMessageBus bus = new NetMessageBus();
    private final LanDiscovery lan = new LanDiscovery();
    private final List<Consumer<NetPeer>> joinListeners = new CopyOnWriteArrayList<>();
    private final List<Consumer<NetPeer>> leaveListeners = new CopyOnWriteArrayList<>();
    private final List<Consumer<String>> statusListeners = new CopyOnWriteArrayList<>();
    private final Map<Integer, GameObject> netObjects = new ConcurrentHashMap<>();

    private NetTransport transport;
    private String playerName = "Player";
    private Scene syncScene;
    private long lastPingSent;
    private final Map<Integer, Long> pingSentAt = new ConcurrentHashMap<>();

    public NetSession session() {
        return session;
    }

    public NetMessageBus bus() {
        return bus;
    }

    public LanDiscovery lan() {
        return lan;
    }

    public void setPlayerName(String playerName) {
        this.playerName = playerName == null || playerName.isBlank() ? "Player" : playerName;
    }

    public String playerName() {
        return playerName;
    }

    public void setGameName(String gameName) {
        session.setGameName(gameName);
    }

    /** Scene scanned each tick for NetworkedTransform / NetworkInput. */
    public void setSyncScene(Scene scene) {
        this.syncScene = scene;
    }

    public void onPeerJoined(Consumer<NetPeer> listener) {
        if (listener != null) {
            joinListeners.add(listener);
        }
    }

    public void onPeerLeft(Consumer<NetPeer> listener) {
        if (listener != null) {
            leaveListeners.add(listener);
        }
    }

    public void onStatus(Consumer<String> listener) {
        if (listener != null) {
            statusListeners.add(listener);
        }
    }

    public void registerHandler(String type, BiConsumer<NetPeer, NetMessage> handler) {
        bus.register(type, handler);
    }

    public boolean isConnected() {
        return session.isActive() && transport != null && transport.isOpen();
    }

    public void host() throws IOException {
        host(DEFAULT_TCP_PORT, DEFAULT_UDP_PORT, false);
    }

    public void host(int port) throws IOException {
        host(port, port + 1, false);
    }

    public void hostDedicated(int port) throws IOException {
        host(port, port + 1, true);
    }

    public void host(int tcpPort, int udpPort, boolean dedicated) throws IOException {
        disconnect();
        TcpUdpTransport tcp = new TcpUdpTransport();
        tcp.host(tcpPort, udpPort);
        transport = tcp;
        session.setRole(dedicated ? NetRole.DEDICATED : NetRole.HOST);
        session.setLocalPeerId(1);
        session.putPeer(new NetPeer(1, playerName));
        session.setRoomCode(shortCode());
        try {
            lan.advertise(session.gameName(), session.roomCode(), tcpPort, udpPort);
        } catch (IOException e) {
            status("LAN advertise failed: " + e.getMessage());
        }
        status(dedicated ? "Dedicated host on " + tcpPort : "Hosting on " + tcpPort + " (room " + session.roomCode() + ")");
    }

    public void join(String host) throws IOException {
        join(host, DEFAULT_TCP_PORT, DEFAULT_UDP_PORT);
    }

    public void join(String host, int port) throws IOException {
        join(host, port, port + 1);
    }

    public void join(String host, int tcpPort, int udpPort) throws IOException {
        disconnect();
        TcpUdpTransport tcp = new TcpUdpTransport();
        tcp.connect(host, tcpPort, udpPort);
        transport = tcp;
        session.setRole(NetRole.CLIENT);
        session.setLocalPeerId(-1);
        // Send HELLO
        byte[] hello = NetProtocol.packHello(playerName, session.gameName());
        transport.sendReliable(1, NetProtocol.TYPE_HELLO, NetChannels.SYSTEM, hello);
        // Register UDP endpoint hint: send a ping-sized unreliable after welcome
        status("Connecting to " + host + ":" + tcpPort + "…");
    }

    public void joinLan() throws IOException {
        lan.startBrowsing();
        long deadline = System.currentTimeMillis() + 3000;
        LanDiscovery.LanRoom room = null;
        while (System.currentTimeMillis() < deadline) {
            room = lan.firstRoom();
            if (room != null) {
                break;
            }
            try {
                Thread.sleep(50);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            }
        }
        if (room == null) {
            throw new IOException("No LAN rooms found");
        }
        join(room.host(), room.tcpPort(), room.udpPort());
        status("Joined LAN room " + room.roomCode() + " @ " + room.host());
    }

    public List<LanDiscovery.LanRoom> browseLan() throws IOException {
        lan.startBrowsing();
        try {
            Thread.sleep(400);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        return lan.rooms();
    }

    /** Host creates a worldwide room via relay (no port-forward needed). */
    public void hostRelay(String relayHost, int relayPort) throws IOException {
        disconnect();
        RelayTransport relay = new RelayTransport();
        relay.createRoom(relayHost, relayPort);
        transport = relay;
        session.setRole(NetRole.HOST);
        session.setLocalPeerId(1);
        session.putPeer(new NetPeer(1, playerName));
        session.setRoomCode(relay.roomCode());
        status("Relay room " + session.roomCode() + " via " + relayHost + ":" + relayPort);
    }

    public void hostRelay(String relayHost) throws IOException {
        hostRelay(relayHost, NetRelayServer.DEFAULT_PORT);
    }

    public void joinRelay(String relayHost, int relayPort, String roomCode) throws IOException {
        disconnect();
        RelayTransport relay = new RelayTransport();
        relay.joinRoom(relayHost, relayPort, roomCode);
        transport = relay;
        session.setRole(NetRole.CLIENT);
        session.setLocalPeerId(-1);
        session.setRoomCode(roomCode.trim().toUpperCase());
        byte[] hello = NetProtocol.packHello(playerName, session.gameName());
        transport.sendReliable(-1, NetProtocol.TYPE_HELLO, NetChannels.SYSTEM, hello);
        status("Joining relay room " + session.roomCode() + "…");
    }

    public void joinRelay(String relayHost, String roomCode) throws IOException {
        joinRelay(relayHost, NetRelayServer.DEFAULT_PORT, roomCode);
    }

    public void disconnect() {
        lan.stopAdvertising();
        if (transport != null) {
            transport.close();
            transport = null;
        }
        session.reset();
        netObjects.clear();
        pingSentAt.clear();
        status("Disconnected");
    }

    public void registerNetObject(GameObject object) {
        if (object == null) {
            return;
        }
        NetworkIdentity identity = object.getComponent(NetworkIdentity.class);
        if (identity == null) {
            identity = object.addComponent(new NetworkIdentity());
        }
        if (session.isHost()) {
            identity.ensureNetId();
            if (identity.ownerPeerId() < 0) {
                identity.setOwnerPeerId(session.localPeerId());
            }
        }
        if (identity.netId() >= 0) {
            netObjects.put(identity.netId(), object);
        }
    }

    public GameObject findNetObject(int netId) {
        return netObjects.get(netId);
    }

    public void sendToAll(String type, byte[] payload, boolean reliable) {
        send(NetMessage.of(type, payload, reliable), -1);
    }

    public void sendToAll(String type, String text, boolean reliable) {
        send(NetMessage.of(type, text, reliable), -1);
    }

    public void sendToHost(String type, byte[] payload, boolean reliable) {
        send(NetMessage.of(type, payload, reliable), session.isHost() ? session.localPeerId() : 1);
    }

    public void sendTo(int peerId, String type, String text, boolean reliable) {
        send(NetMessage.of(type, text, reliable), peerId);
    }

    public void send(NetMessage message, int targetPeerId) {
        if (!isConnected() || message == null) {
            return;
        }
        try {
            byte[] encoded = NetMessageBus.encode(message);
            byte type = NetProtocol.TYPE_DATA;
            if (targetPeerId < 0) {
                if (message.reliable()) {
                    transport.broadcastReliable(type, message.channel(), encoded, -1);
                } else {
                    transport.broadcastUnreliable(type, message.channel(), encoded, -1);
                }
                // Host also delivers locally for listen-server convenience? Skip — caller handles local.
            } else if (targetPeerId == session.localPeerId()) {
                bus.dispatch(session.peer(session.localPeerId()), message.withSender(session.localPeerId()));
            } else if (message.reliable()) {
                transport.sendReliable(targetPeerId, type, message.channel(), encoded);
            } else {
                transport.sendUnreliable(targetPeerId, type, message.channel(), encoded);
            }
        } catch (IOException e) {
            status("Send failed: " + e.getMessage());
        }
    }

    /** Call once per frame from the game loop. */
    public void update(float dt) {
        if (transport == null || !transport.isOpen()) {
            return;
        }
        for (NetTransport.Inbound inbound : transport.poll()) {
            handleFrame(inbound.peerId(), inbound.frame());
        }
        syncComponents(dt);
        maybePing();
    }

    private void handleFrame(int peerId, NetProtocol.Frame frame) {
        if (frame == null) {
            return;
        }
        try {
            switch (frame.type()) {
                case NetProtocol.TYPE_HELLO -> handleHello(peerId, frame);
                case NetProtocol.TYPE_WELCOME -> handleWelcome(frame);
                case NetProtocol.TYPE_PEER_JOINED -> handlePeerJoined(frame);
                case NetProtocol.TYPE_PEER_LEFT -> handlePeerLeft(peerId, frame);
                case NetProtocol.TYPE_DATA -> handleData(peerId, frame);
                case NetProtocol.TYPE_PING -> handlePing(peerId, frame);
                case NetProtocol.TYPE_PONG -> handlePong(peerId, frame);
                default -> {
                }
            }
        } catch (Exception e) {
            status("Frame error: " + e.getMessage());
        }
    }

    private void handleHello(int peerId, NetProtocol.Frame frame) throws IOException {
        if (!session.isHost()) {
            return;
        }
        // Relay may deliver HELLO with peerId -1 — assign sequential ids via session
        int assignedId = peerId;
        if (assignedId < 0 || transport instanceof RelayTransport) {
            assignedId = nextRelayPeerId();
        }
        NetProtocol.HelloPayload hello = frame.payload().length > 0
                ? NetProtocol.unpackHello(frame.payload())
                : new NetProtocol.HelloPayload("Player", session.gameName());
        NetPeer peer = new NetPeer(assignedId, hello.playerName());
        session.putPeer(peer);
        if (transport instanceof TcpUdpTransport tcp) {
            TcpUdpTransport.PeerLink link = tcp.peerLink(assignedId);
            if (link != null && link.remoteAddress() != null) {
                // Do not assume UDP port == DEFAULT_UDP_PORT (clients use ephemeral ports).
                // UDP endpoints are learned from inbound datagrams in TcpUdpTransport.
            }
            transport.sendReliable(assignedId, NetProtocol.TYPE_WELCOME, NetChannels.SYSTEM,
                    NetProtocol.packWelcome(assignedId, session.roomCode()));
            // Tell new peer about existing peers
            for (NetPeer existing : session.peers()) {
                if (existing.id() != assignedId) {
                    transport.sendReliable(assignedId, NetProtocol.TYPE_PEER_JOINED, NetChannels.SYSTEM,
                            NetProtocol.packPeerInfo(existing.id(), existing.name()));
                }
            }
            // Tell others about new peer
            transport.broadcastReliable(NetProtocol.TYPE_PEER_JOINED, NetChannels.SYSTEM,
                    NetProtocol.packPeerInfo(assignedId, peer.name()), assignedId);
        } else {
            // Relay: welcome + peer joined over broadcast
            transport.broadcastReliable(NetProtocol.TYPE_WELCOME, NetChannels.SYSTEM,
                    NetProtocol.packWelcome(assignedId, session.roomCode()), -1);
            transport.broadcastReliable(NetProtocol.TYPE_PEER_JOINED, NetChannels.SYSTEM,
                    NetProtocol.packPeerInfo(assignedId, peer.name()), -1);
            for (NetPeer existing : session.peers()) {
                if (existing.id() != assignedId) {
                    transport.broadcastReliable(NetProtocol.TYPE_PEER_JOINED, NetChannels.SYSTEM,
                            NetProtocol.packPeerInfo(existing.id(), existing.name()), -1);
                }
            }
        }
        fireJoin(peer);
        status(peer.name() + " joined (#" + assignedId + ")");
    }

    private int nextRelayPeerId() {
        int max = 1;
        for (NetPeer peer : session.peers()) {
            max = Math.max(max, peer.id());
        }
        return max + 1;
    }

    private void handleWelcome(NetProtocol.Frame frame) {
        NetProtocol.WelcomePayload welcome = NetProtocol.unpackWelcome(frame.payload());
        session.setLocalPeerId(welcome.peerId());
        session.setRoomCode(welcome.roomCode());
        session.putPeer(new NetPeer(welcome.peerId(), playerName));
        NetPeer hostPeer = session.peer(1);
        if (hostPeer == null) {
            hostPeer = new NetPeer(1, "Host");
            session.putPeer(hostPeer);
        }
        if (transport instanceof TcpUdpTransport tcp) {
            tcp.setLocalPeerId(welcome.peerId());
            try {
                // Reliable ping so host learns we are alive; UDP probe uses real ephemeral port
                transport.sendReliable(1, NetProtocol.TYPE_PING, NetChannels.SYSTEM,
                        NetProtocol.packLong(System.currentTimeMillis()));
                transport.sendUnreliable(1, NetProtocol.TYPE_PING, NetChannels.SYSTEM,
                        NetProtocol.packLong(System.currentTimeMillis()));
            } catch (IOException ignored) {
            }
        }
        fireJoin(hostPeer);
        status("Joined as peer #" + welcome.peerId() + " room " + welcome.roomCode());
    }

    private void handlePeerJoined(NetProtocol.Frame frame) {
        NetProtocol.PeerInfo info = NetProtocol.unpackPeerInfo(frame.payload());
        if (info.peerId() == session.localPeerId()) {
            return;
        }
        NetPeer peer = new NetPeer(info.peerId(), info.name());
        session.putPeer(peer);
        fireJoin(peer);
    }

    private void handlePeerLeft(int peerId, NetProtocol.Frame frame) {
        int id = frame.payload().length >= 4 ? NetProtocol.unpackInt(frame.payload()) : peerId;
        NetPeer peer = session.removePeer(id);
        if (peer != null) {
            peer.setConnected(false);
            fireLeave(peer);
            status(peer.name() + " left");
        }
    }

    private void handleData(int peerId, NetProtocol.Frame frame) {
        NetMessage message = NetMessageBus.decode(frame.channel(), frame.reliable(), frame.payload(), peerId);
        if (frame.channel() == NetChannels.TRANSFORM) {
            handleTransformMessage(message);
            // Host relays client transforms to everyone else (and keeps local apply above)
            if (session.isHost() && peerId != session.localPeerId()) {
                try {
                    transport.broadcastReliable(NetProtocol.TYPE_DATA, frame.channel(), frame.payload(), peerId);
                } catch (IOException ignored) {
                }
            }
            return;
        }
        if (frame.channel() == NetChannels.INPUT) {
            handleInputMessage(message);
            return;
        }
        NetPeer peer = session.peer(peerId);
        if (peer == null) {
            peer = new NetPeer(peerId, "Peer" + peerId);
            session.putPeer(peer);
        }
        peer.touch();
        bus.dispatch(peer, message);

        // Host rebroadcasts custom/RPC/chat to others
        if (session.isHost() && peerId != session.localPeerId()) {
            try {
                transport.broadcastReliable(NetProtocol.TYPE_DATA, frame.channel(), frame.payload(), peerId);
            } catch (IOException ignored) {
            }
        }
    }

    private void handleTransformMessage(NetMessage message) {
        // Payload: netId(4) + x,y(8) [+ rot(4)]
        if (!"Transform".equals(message.type()) || message.payload().length < 12) {
            return;
        }
        ByteBuffer buf = ByteBuffer.wrap(message.payload()).order(ByteOrder.BIG_ENDIAN);
        int netId = buf.getInt();
        byte[] rest = new byte[buf.remaining()];
        buf.get(rest);
        GameObject object = netObjects.get(netId);
        if (object == null && syncScene != null) {
            for (GameObject go : syncScene.getGameObjects()) {
                NetworkIdentity id = go.getComponent(NetworkIdentity.class);
                if (id != null && id.netId() == netId) {
                    object = go;
                    netObjects.put(netId, go);
                    break;
                }
            }
        }
        if (object == null) {
            return;
        }
        NetworkedTransform nt = object.getComponent(NetworkedTransform.class);
        NetworkIdentity identity = object.getComponent(NetworkIdentity.class);
        if (nt == null || identity == null || identity.isLocalPlayer()) {
            return;
        }
        nt.applySnapshot(rest, true);
    }

    private void handleInputMessage(NetMessage message) {
        if (!"Input".equals(message.type()) || message.payload().length < 16) {
            return;
        }
        ByteBuffer buf = ByteBuffer.wrap(message.payload()).order(ByteOrder.BIG_ENDIAN);
        int netId = buf.getInt();
        byte[] rest = new byte[buf.remaining()];
        buf.get(rest);
        GameObject object = netObjects.get(netId);
        if (object == null) {
            return;
        }
        NetworkInput input = object.getComponent(NetworkInput.class);
        if (input != null) {
            input.applyRemote(rest);
        }
        // Host rebroadcasts input state if needed for spectators — optional skip
    }

    private void handlePing(int peerId, NetProtocol.Frame frame) throws IOException {
        transport.sendReliable(peerId, NetProtocol.TYPE_PONG, NetChannels.SYSTEM, frame.payload());
    }

    private void handlePong(int peerId, NetProtocol.Frame frame) {
        if (frame.payload().length < 8) {
            return;
        }
        long sent = NetProtocol.unpackLong(frame.payload());
        long rtt = System.currentTimeMillis() - sent;
        NetPeer peer = session.peer(peerId);
        if (peer != null) {
            peer.setLastRttMs(rtt);
            peer.touch();
        }
    }

    private void syncComponents(float dt) {
        if (syncScene == null || !isConnected()) {
            return;
        }
        for (GameObject go : new ArrayList<>(syncScene.getGameObjects())) {
            NetworkIdentity identity = go.getComponent(NetworkIdentity.class);
            if (identity == null) {
                continue;
            }
            if (identity.netId() >= 0) {
                netObjects.put(identity.netId(), go);
            }
            boolean authority = identity.hasAuthority(session.localPeerId(), session.isHost());

            NetworkedTransform nt = go.getComponent(NetworkedTransform.class);
            if (nt != null && nt.shouldSend(dt, authority)) {
                byte[] snapshot = nt.encodeSnapshot();
                ByteBuffer buf = ByteBuffer.allocate(4 + snapshot.length).order(ByteOrder.BIG_ENDIAN);
                buf.putInt(identity.netId());
                buf.put(snapshot);
                // Reliable: UDP peer ports are ephemeral and were being dropped silently
                NetMessage msg = new NetMessage("Transform", NetChannels.TRANSFORM, true, buf.array(), session.localPeerId());
                if (session.isHost()) {
                    send(msg, -1);
                } else {
                    send(msg, 1);
                }
            }

            NetworkInput input = go.getComponent(NetworkInput.class);
            if (input != null && identity.isLocalPlayer() && input.shouldSend(dt) && session.isClient()) {
                ByteBuffer buf = ByteBuffer.allocate(4 + 12).order(ByteOrder.BIG_ENDIAN);
                buf.putInt(identity.netId());
                buf.put(input.encode());
                send(new NetMessage("Input", NetChannels.INPUT, true, buf.array(), session.localPeerId()), 1);
            }
        }
    }

    private void maybePing() {
        long now = System.currentTimeMillis();
        if (now - lastPingSent < 2000 || !isConnected()) {
            return;
        }
        lastPingSent = now;
        try {
            byte[] payload = NetProtocol.packLong(now);
            if (session.isHost()) {
                transport.broadcastReliable(NetProtocol.TYPE_PING, NetChannels.SYSTEM, payload, -1);
            } else {
                transport.sendReliable(1, NetProtocol.TYPE_PING, NetChannels.SYSTEM, payload);
            }
        } catch (IOException ignored) {
        }
    }

    private void fireJoin(NetPeer peer) {
        for (Consumer<NetPeer> listener : joinListeners) {
            listener.accept(peer);
        }
    }

    private void fireLeave(NetPeer peer) {
        for (Consumer<NetPeer> listener : leaveListeners) {
            listener.accept(peer);
        }
    }

    private void status(String message) {
        for (Consumer<String> listener : statusListeners) {
            listener.accept(message);
        }
    }

    private static String shortCode() {
        String alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
        StringBuilder sb = new StringBuilder(4);
        for (int i = 0; i < 4; i++) {
            sb.append(alphabet.charAt((int) (Math.random() * alphabet.length())));
        }
        return sb.toString();
    }

    public void dispose() {
        disconnect();
        lan.close();
        bus.clear();
        joinListeners.clear();
        leaveListeners.clear();
        statusListeners.clear();
    }
}
