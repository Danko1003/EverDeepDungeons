package com.varcore.engine.ui;

import com.varcore.engine.input.InputManager;
import com.varcore.engine.render.Renderer;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.MouseEvent;
import java.util.function.Consumer;

public class UIButton extends UIElement {
    private String text = "Button";
    private Consumer<UIButton> onClick;
    private boolean hovered;

    public UIButton(float x, float y, float width, float height) {
        super(x, y, width, height);
    }

    public void setText(String text) {
        this.text = text;
    }

    public void setOnClick(Consumer<UIButton> onClick) {
        this.onClick = onClick;
    }

    @Override
    public void update(InputManager input) {
        hovered = contains(input.getMouseX(), input.getMouseY());
        if (hovered && input.isMousePressed(MouseEvent.BUTTON1) && onClick != null) {
            onClick.accept(this);
        }
    }

    @Override
    public void render(Renderer renderer) {
        Color bg = hovered ? new Color(0x5B, 0x8C, 0xFF) : new Color(0x22, 0x27, 0x33);
        renderer.drawRect(x, y, width, height, bg, true, 1000);
        renderer.drawRect(x, y, width, height, new Color(0x5B, 0x8C, 0xFF), false, 1000);
        renderer.drawText(text, x + 8, y + height / 2f + 4, new Font("Segoe UI", Font.PLAIN, 14),
                new Color(0xE6, 0xE6, 0xE6), 1001);
    }
}
