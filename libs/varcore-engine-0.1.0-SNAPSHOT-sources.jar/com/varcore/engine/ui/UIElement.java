package com.varcore.engine.ui;

import com.varcore.engine.input.InputManager;
import com.varcore.engine.render.Renderer;

public abstract class UIElement {
    protected float x;
    protected float y;
    protected float width;
    protected float height;
    protected UIAnchor anchor = UIAnchor.TOP_LEFT;
    protected boolean visible = true;

    protected UIElement(float x, float y, float width, float height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }

    public void setAnchor(UIAnchor anchor) {
        this.anchor = anchor;
    }

    public void setVisible(boolean visible) {
        this.visible = visible;
    }

    public boolean contains(float px, float py) {
        return px >= x && py >= y && px < x + width && py < y + height;
    }

    public void layout(int screenWidth, int screenHeight) {
        switch (anchor) {
            case TOP_CENTER -> x = (screenWidth - width) / 2f;
            case TOP_RIGHT -> x = screenWidth - width - x;
            case CENTER -> {
                x = (screenWidth - width) / 2f;
                y = (screenHeight - height) / 2f;
            }
            case BOTTOM_LEFT -> y = screenHeight - height - y;
            case BOTTOM_CENTER -> {
                x = (screenWidth - width) / 2f;
                y = screenHeight - height - y;
            }
            case BOTTOM_RIGHT -> {
                x = screenWidth - width - x;
                y = screenHeight - height - y;
            }
            default -> {}
        }
    }

    public abstract void update(InputManager input);

    public abstract void render(Renderer renderer);
}
