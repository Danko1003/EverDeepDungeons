package com.varcore.engine.ui;

import com.varcore.engine.input.InputManager;
import com.varcore.engine.render.Renderer;
import java.util.ArrayList;
import java.util.List;

public final class UIRenderer {
    private final List<UIElement> elements = new ArrayList<>();

    public void add(UIElement element) {
        elements.add(element);
    }

    public void remove(UIElement element) {
        elements.remove(element);
    }

    public void update(InputManager input, int screenWidth, int screenHeight) {
        for (UIElement element : elements) {
            if (element.visible) {
                element.layout(screenWidth, screenHeight);
                element.update(input);
            }
        }
    }

    public void render(Renderer renderer) {
        for (UIElement element : elements) {
            if (element.visible) {
                element.render(renderer);
            }
        }
    }
}
