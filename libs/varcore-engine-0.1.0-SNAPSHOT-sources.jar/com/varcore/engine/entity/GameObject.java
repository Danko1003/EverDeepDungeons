package com.varcore.engine.entity;

import com.varcore.engine.component.Component;
import com.varcore.engine.render.Renderer;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class GameObject {
    private final String name;
    private final Transform transform = new Transform();
    private final List<Component> components = new ArrayList<>();
    private boolean active = true;
    private String tag = "";

    public GameObject(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public Transform getTransform() {
        return transform;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public <T extends Component> T addComponent(T component) {
        components.add(component);
        component.setGameObject(this);
        component.onAttach();
        return component;
    }

    @SuppressWarnings("unchecked")
    public <T extends Component> T getComponent(Class<T> type) {
        for (Component component : components) {
            if (type.isInstance(component)) {
                return (T) component;
            }
        }
        return null;
    }

    public List<Component> getComponents() {
        return List.copyOf(components);
    }

    public void update(float dt) {
        if (!active) {
            return;
        }
        for (Component component : components) {
            if (component.isEnabled()) {
                component.update(dt);
            }
        }
    }

    public void render(Renderer renderer) {
        if (!active) {
            return;
        }
        for (Component component : components) {
            if (component.isEnabled()) {
                component.render(renderer);
            }
        }
    }

    public void destroy() {
        for (Component component : components) {
            component.onDestroy();
        }
        components.clear();
        active = false;
    }

    public Optional<Component> removeComponent(Class<? extends Component> type) {
        for (int i = 0; i < components.size(); i++) {
            Component component = components.get(i);
            if (type.isInstance(component)) {
                component.onDestroy();
                components.remove(i);
                return Optional.of(component);
            }
        }
        return Optional.empty();
    }
}
