package com.varcore.engine.entity;

import com.varcore.engine.math.Vector2;

public final class Transform {
    private final Vector2 position = new Vector2();
    private final Vector2 scale = new Vector2(1, 1);
    private float rotation;

    public Vector2 getPosition() {
        return position;
    }

    public Vector2 getScale() {
        return scale;
    }

    public float getRotation() {
        return rotation;
    }

    public void setPosition(float x, float y) {
        position.set(x, y);
    }

    public void setScale(float x, float y) {
        scale.set(x, y);
    }

    public void setRotation(float rotation) {
        this.rotation = rotation;
    }

    public void translate(float dx, float dy) {
        position.add(dx, dy);
    }
}
