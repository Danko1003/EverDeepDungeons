package com.varcore.engine.entity;

import com.varcore.engine.component.Component;
import com.varcore.engine.component.ShapeRenderer;
import com.varcore.engine.component.SpriteRenderer;
import com.varcore.engine.scene.Scene;
import java.awt.Color;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/**
 * Fluent factory for {@link GameObject}s — name, transform, tag, components, then {@link #build()} or {@link #spawn()}.
 *
 * <pre>{@code
 * GameObject coin = GameObjectFabricator.create("Coin")
 *         .at(120, 200)
 *         .tag("pickup")
 *         .circle(12, Color.YELLOW)
 *         .into(scene)
 *         .spawn();
 * }</pre>
 */
public final class GameObjectFabricator {
    private String name = "GameObject";
    private String tag = "";
    private float x;
    private float y;
    private float scaleX = 1f;
    private float scaleY = 1f;
    private float rotation;
    private boolean active = true;
    private Scene scene;
    private final List<Consumer<GameObject>> customizers = new ArrayList<>();

    private GameObjectFabricator() {
    }

    public static GameObjectFabricator create() {
        return new GameObjectFabricator();
    }

    public static GameObjectFabricator create(String name) {
        return new GameObjectFabricator().name(name);
    }

    public GameObjectFabricator name(String name) {
        this.name = name == null || name.isBlank() ? "GameObject" : name;
        return this;
    }

    public GameObjectFabricator tag(String tag) {
        this.tag = tag == null ? "" : tag;
        return this;
    }

    public GameObjectFabricator at(float x, float y) {
        this.x = x;
        this.y = y;
        return this;
    }

    public GameObjectFabricator scale(float uniform) {
        return scale(uniform, uniform);
    }

    public GameObjectFabricator scale(float scaleX, float scaleY) {
        this.scaleX = scaleX;
        this.scaleY = scaleY;
        return this;
    }

    public GameObjectFabricator rotation(float degrees) {
        this.rotation = degrees;
        return this;
    }

    public GameObjectFabricator active(boolean active) {
        this.active = active;
        return this;
    }

    /** Target scene for {@link #spawn()}. */
    public GameObjectFabricator into(Scene scene) {
        this.scene = scene;
        return this;
    }

    public GameObjectFabricator with(Component component) {
        if (component != null) {
            customizers.add(go -> go.addComponent(component));
        }
        return this;
    }

    public GameObjectFabricator with(Consumer<GameObject> customizer) {
        if (customizer != null) {
            customizers.add(customizer);
        }
        return this;
    }

    public GameObjectFabricator sprite(BufferedImage image, float width, float height, int layer) {
        return with(go -> {
            SpriteRenderer sprite = go.addComponent(new SpriteRenderer());
            sprite.setImage(image);
            sprite.setSize(width, height);
            sprite.setLayer(layer);
        });
    }

    public GameObjectFabricator sprite(BufferedImage image, int layer) {
        return with(go -> {
            SpriteRenderer sprite = go.addComponent(new SpriteRenderer());
            sprite.setImage(image);
            sprite.setLayer(layer);
        });
    }

    public GameObjectFabricator rect(float width, float height, Color color, int layer) {
        return with(go -> go.addComponent(new ShapeRenderer().rect(width, height, color).setLayer(layer)));
    }

    public GameObjectFabricator rect(float width, float height, Color color) {
        return rect(width, height, color, 0);
    }

    public GameObjectFabricator circle(float radius, Color color, int layer) {
        return with(go -> go.addComponent(new ShapeRenderer().circle(radius, color).setLayer(layer)));
    }

    public GameObjectFabricator circle(float radius, Color color) {
        return circle(radius, color, 0);
    }

    /** Builds the object without adding it to a scene. */
    public GameObject build() {
        GameObject go = new GameObject(name);
        go.setTag(tag);
        go.setActive(active);
        go.getTransform().setPosition(x, y);
        go.getTransform().setScale(scaleX, scaleY);
        go.getTransform().setRotation(rotation);
        for (Consumer<GameObject> customizer : customizers) {
            customizer.accept(go);
        }
        return go;
    }

    /** Builds and adds to the scene from {@link #into(Scene)}. */
    public GameObject spawn() {
        if (scene == null) {
            throw new IllegalStateException("Call into(scene) before spawn(), or use build() and add manually");
        }
        return scene.add(build());
    }

    /** Builds and adds to the given scene (does not require {@link #into(Scene)}). */
    public GameObject spawn(Scene scene) {
        if (scene == null) {
            throw new IllegalArgumentException("scene is null");
        }
        return scene.add(build());
    }
}
